package rc55.mc.rfapi.item;

import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_2315;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_7923;
import net.minecraft.item.*;
import org.jetbrains.annotations.NotNull;
import rc55.mc.rfapi.fluid.FluidReference;

import java.util.function.Function;

public class BucketItemRegistry {
    protected static <T extends class_1792> T register(class_2960 id, Function<class_1792.class_1793, T> itemFactory, class_1792.class_1793 settings) {
        return class_2378.method_10230(class_7923.field_41178, id, itemFactory.apply(settings));
    }

    public static ExtendedBucketItem registerEmpty(class_2960 id, int maxTemperature, class_1792.class_1793 settings) {
        final ExtendedBucketItem item = register(id, s -> new ExtendedBucketItem(maxTemperature, s), settings);
        class_2315.method_10009(item, BucketItemDispenserBehavior.emptyBucketBehavior(item));
        return item;
    }

    public static ExtendedBucketItem registerVanilla(class_2960 id, FluidReference<?> fluid, class_1792.class_1793 settings) {
        final ExtendedBucketItem item = register(id, s -> ExtendedBucketItem.ofVanilla(fluid, s), settings);
        class_2315.method_10009(item, BucketItemDispenserBehavior.fluidBucketBehavior(item));
        return item;
    }

    public static ExtendedBucketItem register(class_2960 id, @NotNull class_1755 base, FluidReference<?> fluid, class_1792.class_1793 settings) {
        final ExtendedBucketItem item = register(id, s -> new ExtendedBucketItem(fluid, base, s), settings);
        class_2315.method_10009(item, BucketItemDispenserBehavior.fluidBucketBehavior(base));
        return item;
    }

    public static ExtendedBucketItem register(class_2960 id, @NotNull class_1755 base, class_3611 fluid, class_1792.class_1793 settings) {
        final ExtendedBucketItem item = register(id, s -> new ExtendedBucketItem(fluid, base, s), settings);
        class_2315.method_10009(item, BucketItemDispenserBehavior.fluidBucketBehavior(base));
        return item;
    }
}
