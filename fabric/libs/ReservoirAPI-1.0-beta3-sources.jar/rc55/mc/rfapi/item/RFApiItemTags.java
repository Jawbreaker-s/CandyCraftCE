package rc55.mc.rfapi.item;

import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class RFApiItemTags {
    public static final class_6862<class_1792> BUCKETS = ofConventional("buckets");
    public static final class_6862<class_1792> BUCKETS_FILLED = ofConventional("buckets/filled");
    public static final class_6862<class_1792> BUCKETS_EMPTY = ofConventional("buckets/empty");

    public static class_6862<class_1792> of(class_2960 id) {
        return class_6862.method_40092(class_7924.field_41197, id);
    }

    public static class_6862<class_1792> ofConventional(String id) {
        return of(class_2960.method_43902("c", id));
    }
}
