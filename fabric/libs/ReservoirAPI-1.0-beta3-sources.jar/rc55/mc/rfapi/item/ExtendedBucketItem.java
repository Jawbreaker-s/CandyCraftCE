package rc55.mc.rfapi.item;

import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_156;
import net.minecraft.class_1657;
import net.minecraft.class_174;
import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2398;
import net.minecraft.class_2402;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3468;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_5328;
import net.minecraft.class_5712;
import net.minecraft.item.*;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.fluid.*;

import java.util.HashMap;
import java.util.Map;

/**
 * FluidLib version of buckets
 * <ul>
 *     <li>Can have multiple type of buckets</li>
 *     <li>Stackable</li>
 *     <li>Placing water in the nether now depends on {@link FluidTags#DISAPPEAR_IN_ULTRAWARM #c:disappear_in_ultrawarm}</li>
 * </ul>
 * Use {@link BucketItemRegistry} to automatically handle extra stuff(e.g. dispenser behaviors)
 * @see class_1755
 */
public class ExtendedBucketItem extends class_1755 {

    /**
     * Map of different type of buckets
     * Note that vanilla bucket aren't included
     * Key： The empty bucket
     * Value： Map of fluid and their item with this type of bucket
     */
    public static final Map<class_1755, Map<class_3611, class_1755>> BUCKET_ITEM_MAP = new HashMap<>();

    /**
     * Empty factor of this bucket
     * null when the bucket is already empty
     */
    @Nullable
    private final class_1755 baseItem;
    private final int maxTemperature;

    @Nullable
    private String baseTranslationKey;

    @Nullable
    private String contextTranslationKey;

    /**
     * Create bucket with fluid
     * @param fluid Fluid in the bucket
     * @param base Empty factor of the fluid bucket
     */
    public ExtendedBucketItem(@NotNull class_3611 fluid, @NotNull class_1755 base, class_1793 settings) {
        super(FluidHelper.trim(fluid), settings.method_7896(base));
        if (base instanceof ExtendedBucketItem bucket && fluid.getSettings().getTemperature() > bucket.maxTemperature) {
            throw new IllegalArgumentException("Given fluid %s has temperature %d greater than its base item(max temperature %d)!"
                    .formatted(FluidRegistry.getId(fluid), fluid.getSettings().getTemperature(), bucket.maxTemperature));
        }
        this.maxTemperature = Integer.MAX_VALUE;
        this.baseItem = base;
        if (base != class_1802.field_8550) {
            if (!BUCKET_ITEM_MAP.containsKey(base)) {
                BUCKET_ITEM_MAP.put(base, class_156.method_654(new HashMap<>(), map -> map.put(fluid, this)));
            } else {
                BUCKET_ITEM_MAP.get(base).put(fluid, this);
            }
        }
    }

    /**
     * @see ExtendedBucketItem#ExtendedBucketItem(class_3611, class_1755, class_1793) ExtendedBucketItem
     */
    public ExtendedBucketItem(FluidReference<?> fluid, @NotNull class_1755 base, class_1793 settings) {
        this(fluid.getStill(), base, settings);
    }

    /**
     * Create empty bucket
     * @param maxTemperature Max temperature the bucket can hold
     */
    public ExtendedBucketItem(int maxTemperature, class_1793 settings) {
        super(class_3612.field_15906, settings);
        this.maxTemperature = maxTemperature;
        this.baseItem = null;
        if (!BUCKET_ITEM_MAP.containsKey(this)) {
            BUCKET_ITEM_MAP.put(this, new HashMap<>());
        }
    }

    /**
     * Creates a custom fluid bucket which use vanilla bucket as base
     */
    public static ExtendedBucketItem ofVanilla(FluidReference<?> fluid, class_1793 settings) {
        return new ExtendedBucketItem(fluid, (class_1755) class_1802.field_8550, settings);
    }

    /**
     * Check if the stack is an empty bucket
     */
    public static boolean isEmpty(class_1799 stack) {
        return isEmpty(stack.method_7909());
    }

    /**
     * Check if the item is an empty bucket
     */
    public static boolean isEmpty(class_1792 item) {
        return (item instanceof ExtendedBucketItem z && z.isEmpty()) || item == class_1802.field_8550;
    }

    public static int getMaxTemperature(class_1799 stack) {
        return getMaxTemperature(stack.method_7909());
    }

    public static int getMaxTemperature(class_1792 item) {
        if (item instanceof ExtendedBucketItem ) {
            return ((ExtendedBucketItem) item).getMaxTemperature();
        }
        return -1;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        class_3965 hitResult = method_7872(world, user, this.field_7905 == class_3612.field_15906 ? class_3959.class_242.field_1345 : class_3959.class_242.field_1348);
        // Miss
        if (hitResult.method_17783() == class_239.class_240.field_1333) {
            return class_1271.method_22430(stack);
        } else if (hitResult.method_17783() != class_239.class_240.field_1332) {
            return class_1271.method_22430(stack);
        }
        // Hit pos
        class_2338 hitPos = hitResult.method_17777();
        class_2350 hitSide = hitResult.method_17780();
        class_2338 hitSideOffsetPos = hitPos.method_10093(hitSide);
        if (!world.method_8505(user, hitPos) || !user.method_7343(hitSideOffsetPos, hitSide, stack)) {
            // Not placeable
            return class_1271.method_22431(stack);
        } else if (this.isEmpty()) {
            // Pick up
            class_2680 blockState = world.method_8320(hitPos);
            if (blockState.method_26204() instanceof class_2263 fluidDrainable) {
                class_3611 fluid = blockState.method_26227().method_15772();
                class_1755 bucketItem = BUCKET_ITEM_MAP.get(this).get(fluid);
                if (bucketItem == null || fluid.getSettings().getTemperature() > this.maxTemperature) {
                    return class_1271.method_22431(stack);
                }
                if (!fluidDrainable.method_9700(world, hitPos, blockState).method_7960()) {
                    user.method_7259(class_3468.field_15372.method_14956(this));
                    fluidDrainable.method_32351().ifPresent(sound -> user.method_5783(sound, 1f, 1f));
                    world.method_33596(user, class_5712.field_28167, hitPos);

                    class_1799 resultStack = new class_1799(bucketItem);
                    class_1799 itemStack = class_5328.method_30012(stack, user, resultStack);
                    if (!world.field_9236) {
                        class_174.field_1208.method_8932((class_3222)user, resultStack);
                    }

                    return class_1271.method_29237(itemStack, world.method_8608());
                }
            }
            return class_1271.method_22431(stack);
        } else {
            // Place
            class_2338 pos = world.method_8320(hitPos).method_26204() instanceof class_2402 && this.field_7905.method_15780(class_3612.field_15910) ? hitPos : hitSideOffsetPos;
            if (this.method_7731(user, world, pos, hitResult)) {
                this.method_7728(user, world, stack, pos);
                if (user instanceof class_3222) {
                    class_174.field_1191.method_23889((class_3222)user, pos, stack);
                }

                class_1799 resultStack = class_5328.method_30012(stack, user, new class_1799(this::getBaseItem));
                user.method_7259(class_3468.field_15372.method_14956(this));
                return class_1271.method_29237(resultStack, world.method_8608());
            } else {
                return class_1271.method_22431(stack);
            }
        }
    }

    @Override
    public boolean method_7731(@Nullable class_1657 player, class_1937 world, class_2338 pos, @Nullable class_3965 hitResult) {
        class_2680 state = world.method_8320(pos);
        class_2248 block = state.method_26204();
        boolean canPlaceHere = state.method_26215() || state.method_26188(this.field_7905) ||
                (block instanceof class_2402 fillable && fillable.method_10310(world, pos, state, this.field_7905));
        if (!canPlaceHere) {
            return hitResult != null && this.method_7731(player, world, hitResult.method_17777().method_10093(hitResult.method_17780()), null);
        } else if (world.method_8597().comp_644() && this.field_7905.method_15791(FluidTags.DISAPPEAR_IN_ULTRAWARM)) {
            // Not avail in ultrawarm, disappear
            final int x = pos.method_10263();
            final int y = pos.method_10264();
            final int z = pos.method_10260();
            // Sound
            world.method_8396(player, pos, class_3417.field_15102, class_3419.field_15245,
                    0.5f, 2.6f + (world.field_9229.method_43057() - world.field_9229.method_43057()) * 0.8f);
            // Particle
            for (int i = 0; i < 8; i++) {
                world.method_8406(class_2398.field_11237, x + Math.random(), y + Math.random(), z + Math.random(), 0.0, 0.0, 0.0);
            }
            return true;
        } else if (block instanceof class_2402 fillable && class_3612.field_15910.method_15780(this.field_7905)) {
            // Waterlog block
            fillable.method_10311(world, pos, state, ((class_3609)this.field_7905).method_15729(false));
            this.method_7727(player, world, pos);
            return true;
        } else {
            // Break block
            if (!world.field_9236 && state.method_26188(this.field_7905) && !state.method_51176()) {
                world.method_22352(pos, true);
            }
            // Place fluid block
            if (!world.method_8652(pos, this.field_7905.method_15785().method_15759(), class_2248.field_31036 | class_2248.field_31030)
                    && !state.method_26227().method_15771()
            ) {
                return false;
            } else {
                this.method_7727(player, world, pos);
                return true;
            }
        }
    }

    @Override
    public void method_7727(@Nullable class_1657 player, class_1936 world, class_2338 pos) {
        final class_3414 sound = FluidSettings.get(field_7905).getBucketEmptySound().orElse(class_3417.field_14834);
        world.method_8396(player, pos, sound, class_3419.field_15245, 1.0F, 1.0F);
        world.method_33596(player, class_5712.field_28166, pos);
    }

    @Override
    public class_2561 method_7848() {
        if (this.isEmpty()) {
            return super.method_7848();
        } else {
            return class_2561.method_43469(this.getBaseTranslationKey(), class_2561.method_43471(this.getContextTranslationKey()));
        }
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        return this.method_7848();
    }

    /**
     * For a non-empty bucket this will be its base translation key.
     * This will be formatted with its current context fluid's name.
     * @return The base translation key, or the original translation key if this bucket is empty
     * @see #method_7848() How the format works
     */
    public String getBaseTranslationKey() {
        if (this.baseTranslationKey == null) {
            if (this.isEmpty()) {
                this.baseTranslationKey = this.method_7876();
            } else {
                this.baseTranslationKey = this.getBaseItem().method_7876() + ".filled";
            }
        }
        return this.baseTranslationKey;
    }

    /**
     * Translation key for the fluid block that is inside this bucket.
     * For empty buckets this will be their filled format key.
     * @see #method_7848() How the format works
     */
    public String getContextTranslationKey() {
        if (this.contextTranslationKey == null) {
            if (this.isEmpty()) {
                this.contextTranslationKey = this.method_7876() + ".filled";
            } else {
                this.contextTranslationKey = this.field_7905.method_15785().method_15759().method_26204().method_9539();
            }
        }
        return this.contextTranslationKey;
    }

    /**
     * Get the empty factor of the bucket, will return self if the bucket is already empty
     */
    public class_1755 getBaseItem() {
        return this.baseItem == null ? this : this.baseItem;
    }

    /**
     * Max temperature this bucket can held, will return {@link Integer#MAX_VALUE} if this bucket is not empty
     */
    public int getMaxTemperature() {
        return maxTemperature;
    }

    /**
     * Fluid this bucket contains, {@link class_3612#field_15906} if this bucket is empty
     */
    public class_3611 getFluid() {
        return this.field_7905;
    }

    /**
     * Get fluid bucket for this bucket
     * @param fluid Fluid type
     * @return Bucket item contains the given fluid, null if this bucket can't hold given fluid
     * @throws UnsupportedOperationException If this is not called from an empty bucket
     */
    public @Nullable class_1755 getBucketFor(class_3611 fluid) {
        if (!this.isEmpty()) {
            throw new UnsupportedOperationException();
        }
        return BUCKET_ITEM_MAP.get(this).get(fluid);
    }

    /**
     * Whether this bucket is empty
     */
    public boolean isEmpty() {
        return this.baseItem == null || this.field_7905 == class_3612.field_15906;
    }
}
