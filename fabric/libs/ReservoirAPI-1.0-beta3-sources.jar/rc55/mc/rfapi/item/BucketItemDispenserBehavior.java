package rc55.mc.rfapi.item;

import net.minecraft.class_1755;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2263;
import net.minecraft.class_2315;
import net.minecraft.class_2338;
import net.minecraft.class_2342;
import net.minecraft.class_2347;
import net.minecraft.class_2357;
import net.minecraft.class_2601;
import net.minecraft.class_2680;
import net.minecraft.class_5633;
import net.minecraft.class_5712;
import net.minecraft.item.*;

public final class BucketItemDispenserBehavior {
    private BucketItemDispenserBehavior(){}

    public static final class_2347 FALLBACK_BEHAVIOR = new class_2347();

    public static class_2357 emptyBucketBehavior(class_1755 bucket) {
        return new class_2347() {
            @Override
            public class_1799 method_10135(class_2342 pointer, class_1799 stack) {
                final class_1936 world = pointer.method_10207();
                final class_2338 blockPos = pointer.method_10122().method_10093(pointer.method_10120().method_11654(class_2315.field_10918));
                final class_2680 blockState = world.method_8320(blockPos);
                final class_2248 block = blockState.method_26204();
                if (block instanceof class_2263) {
                    class_1792 item = null;
                    if (bucket instanceof ExtendedBucketItem) {
                        item = ((ExtendedBucketItem) bucket).getBucketFor(blockState.method_26227().method_15772());
                        if (item == null) {
                            return super.method_10135(pointer, stack);
                        }
                    }
                    final class_1799 vanillaBucketStack = ((class_2263)block).method_9700(world, blockPos, blockState);
                    if (vanillaBucketStack.method_7960()) {
                        return super.method_10135(pointer, stack);
                    } else {
                        if (item == null) {
                            item = vanillaBucketStack.method_7909();
                        }
                        world.method_33596(null, class_5712.field_28167, blockPos);
                        stack.method_7934(1);
                        if (stack.method_7960()) {
                            return new class_1799(item);
                        } else {
                            if (pointer.<class_2601>method_10121().method_11075(new class_1799(item)) < 0) {
                                FALLBACK_BEHAVIOR.dispense(pointer, new class_1799(item));
                            }

                            return stack;
                        }
                    }
                } else {
                    return super.method_10135(pointer, stack);
                }
            }
        };
    }

    public static class_2357 fluidBucketBehavior(class_1755 bucket) {
        return new class_2347() {
            @Override
            public class_1799 method_10135(class_2342 pointer, class_1799 stack) {
                class_5633 fluidModificationItem = (class_5633)stack.method_7909();
                class_2338 blockPos = pointer.method_10122().method_10093(pointer.method_10120().method_11654(class_2315.field_10918));
                class_1937 world = pointer.method_10207();
                final class_1792 base;
                if (bucket instanceof ExtendedBucketItem ex) {
                    base = ex.getBaseItem();
                } else {
                    base = class_1802.field_8550;
                }
                if (fluidModificationItem.method_7731(null, world, blockPos, null)) {
                    fluidModificationItem.method_7728(null, world, stack, blockPos);
                    if (stack.method_7947() > 1 && pointer.<class_2601>method_10121().method_11075(new class_1799(base)) == -1) {
                        FALLBACK_BEHAVIOR.dispense(pointer, new class_1799(base));
                    }
                    return stack.method_7947() > 1 ? stack.method_7971(stack.method_7947() - 1) : new class_1799(base);
                } else {
                    return FALLBACK_BEHAVIOR.dispense(pointer, stack);
                }
            }
        };
    }
}
