package rc55.mc.rfapi.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_3611;
import rc55.mc.rfapi.fluid.FluidHelper;

import java.util.function.Predicate;

@FunctionalInterface
public interface EndServerChunkTickEvent {
    EndServerChunkTickEvent DEFAULT_CALLBACK = (world, chunk, randomTickSpeed) -> {};

    Event<EndServerChunkTickEvent> EVENT = EventFactory.createArrayBacked(EndServerChunkTickEvent.class, DEFAULT_CALLBACK, listeners -> (world, chunk, randomTickSpeed) -> {
        for (EndServerChunkTickEvent event : listeners) {
            event.onChunkTickEnd(world, chunk, randomTickSpeed);
        }
    });

    void onChunkTickEnd(class_3218 world, class_2818 chunk, int randomTickSpeed);

    /**
     * Creates an evnet callback for changing fluids to ice like vanilla water.
     * @param predicate Check if the chosen fluid matches type of the ice.
     *                  Note that this should also include fluid height checks.
     *                  If you want it to act like vanilla water, consider
     *                  using {@link rc55.mc.rfapi.fluid.FluidReference#matchesAndStill(class_3611)}
     * @param result The ice state to place
     * @return The event callback
     */
    static EndServerChunkTickEvent setIce(Predicate<class_3611> predicate, class_2680 result) {
        return (world, chunk, randomTickSpeed) -> {
            world.method_16107().method_15405("rfapi_customIceLogics");
            if (world.method_8409().method_43048(16) != 0) return;
            class_2338 upPos = world.method_8598(class_2902.class_2903.field_13197, world.method_8536(chunk.method_12004().method_8326(), 0, chunk.method_12004().method_8328(), 15));
            class_2338 fluidPos = upPos.method_10074();
            if (FluidHelper.canSetIce(world, fluidPos, predicate, true)) {
                world.method_8501(fluidPos, result);
            }
        };
    }
}
