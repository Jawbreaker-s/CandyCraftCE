package rc55.mc.rfapi.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_4538;

@FunctionalInterface
public interface FluidScheduledTickEvent {
    FluidScheduledTickEvent DEFAULT_CALLBACK = (self, world, pos, state, levelDecreasePerBlock, nextTickDelay) -> false;

    Event<FluidScheduledTickEvent> EVENT = EventFactory.createArrayBacked(FluidScheduledTickEvent.class, DEFAULT_CALLBACK, listeners ->
            (self, world, pos, state, levelDecreasePerBlock, nextTickDelay) -> {
                for (final FluidScheduledTickEvent event : listeners) {
                    if (event.onScheduledTick(self, world, pos, state, levelDecreasePerBlock, nextTickDelay)) {
                        return true;
                    }
                }
                return false;
            }
    );

    /**
     * The event that will be triggered before fluid scheduled tick
     * @param self Fluid instance ticking
     * @param world Thw world
     * @param pos Pos to update
     * @param state Fluid state used to be in the pos
     * @param levelDecreasePerBlock See {@link class_3609#method_15739(class_4538)}
     * @param nextTickDelay See {@link class_3609#method_15753(class_1937, class_2338, class_3610, class_3610)} ,
     *                      note both {@link class_3610} paras are the old states
     * @return If any further actions should be cancelled
     */
    boolean onScheduledTick(class_3609 self, class_1937 world, class_2338 pos, class_3610 state, int levelDecreasePerBlock, int nextTickDelay);
}
