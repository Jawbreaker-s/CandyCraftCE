package rc55.mc.rfapi.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

@FunctionalInterface
public interface EntityTouchFluidEvent {
    EntityTouchFluidEvent DEFAULT_CALLBACK = (state, world, pos, entity) -> false;

    Event<EntityTouchFluidEvent> EVENT = EventFactory.createArrayBacked(EntityTouchFluidEvent.class, DEFAULT_CALLBACK, listeners ->
            (state, world, pos, entity) -> {
                for (EntityTouchFluidEvent event : listeners) {
                    if (event.onEntityCollision(state, world, pos, entity)) {
                        return true;
                    }
                }
                return false;
            }
    );

    /**
     * This event will be triggered when entity collides with a fluid block
     * @param state Block state the entity collides with
     * @param world The world
     * @param pos Pos of the block which the entity collides
     * @param entity The entity collides with the block
     * @return If any further actions should be cancelled
     */
    boolean onEntityCollision(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity);
}
