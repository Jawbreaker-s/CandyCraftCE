package rc55.mc.rfapi.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;

@FunctionalInterface
public interface FluidBlockNeighborUpdateEvent {
    FluidBlockNeighborUpdateEvent DEFAULT_CALLBACK = (self, state, world, pos, sourceBlock, sourcePos, notify) -> false;

    Event<FluidBlockNeighborUpdateEvent> EVENT = EventFactory.createArrayBacked(FluidBlockNeighborUpdateEvent.class, DEFAULT_CALLBACK, listeners ->
            (self, state, world, pos, sourceBlock, sourcePos, notify) -> {
                for (FluidBlockNeighborUpdateEvent event : listeners) {
                    if (event.onNeighborUpdate(self, state, world, pos, sourceBlock, sourcePos, notify)) {
                        return true;
                    }
                }
                return false;
            }
    );

    /**
     * This event will be triggered when a fluid block receives a
     * neighboring block update and before any action performs
     * @param self The fluid block instance to call from
     * @param state Original state
     * @param world The world
     * @param pos Pos to update
     * @param sourceBlock Block which triggers the update
     * @param sourcePos Where the update triggers from
     * @param notify Notify others
     * @return If any further actions should be cancelled
     * @see net.minecraft.class_4970.class_4971#method_26181(class_1937, class_2338, class_2248, class_2338, boolean)
     */
    boolean onNeighborUpdate(class_2404 self, class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify);
}
