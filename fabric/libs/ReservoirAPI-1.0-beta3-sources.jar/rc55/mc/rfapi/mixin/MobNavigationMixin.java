package rc55.mc.rfapi.mixin;

import net.minecraft.class_1409;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidSettings;

@Mixin(class_1409.class)
public abstract class MobNavigationMixin {
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;isOf(Lnet/minecraft/block/Block;)Z"),
            method = "getPathfindingY"
    )
    public boolean rfapi$fixNavigationInFluid(class_2680 instance, class_2248 block) {
        return FluidSettings.get(instance.method_26227()).canSwim();
    }
}
