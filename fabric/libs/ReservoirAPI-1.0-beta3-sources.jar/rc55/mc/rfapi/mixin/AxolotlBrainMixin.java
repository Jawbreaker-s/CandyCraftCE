package rc55.mc.rfapi.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidSettings;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_4115;
import net.minecraft.class_4140;
import net.minecraft.class_5768;
import net.minecraft.class_7894;
import net.minecraft.class_7898;

@Mixin(class_5768.class)
public abstract class AxolotlBrainMixin {
    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/ai/brain/task/TaskTriggerer;predicate(Ljava/util/function/Predicate;)Lnet/minecraft/entity/ai/brain/task/SingleTickTask;"
            ),
            method = "addIdleActivities"
    )
    private static <E extends class_1309> class_7894<E> rfapi$fixAxolotlSwimmingCheck(Predicate<E> predicate) {
        return class_7898.method_47225(AxolotlBrainMixin::isInsideWaterOrBubbleColumn);
    }

    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;isInsideWaterOrBubbleColumn()Z"
            ),
            method = {"getTargetApproachingSpeed", "getTargetApproachingSpeed", "getAdultFollowingSpeed"}
    )
    private static boolean rfapi$fixAxolotlSwimmingSpeed(class_1309 instance) {
        return isInsideWaterOrBubbleColumn(instance);
    }

    /**
     * @author redColmula55
     * @reason Fix axolotl navigation
     */
    @Overwrite
    private static boolean canGoToLookTarget(class_1309 entity) {
        class_1937 world = entity.method_37908();
        Optional<class_4115> optional = entity.method_18868().method_18904(class_4140.field_18446);
        if (optional.isPresent()) {
            class_2338 blockPos = optional.get().method_18989();
            return FluidSettings.get(world.method_8316(blockPos)).canSwim() == isInsideWaterOrBubbleColumn(entity);
        } else {
            return false;
        }
    }

    @Unique
    private static boolean isInsideWaterOrBubbleColumn(class_1297 entity) {
        return entity.method_5816() || entity.isTouchingFluid(fluid -> fluid.getSettings().canSwim());
    }
}
