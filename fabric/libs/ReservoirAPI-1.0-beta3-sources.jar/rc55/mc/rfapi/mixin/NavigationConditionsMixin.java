package rc55.mc.rfapi.mixin;

import net.minecraft.class_1314;
import net.minecraft.class_2338;
import net.minecraft.class_5493;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import rc55.mc.rfapi.fluid.FluidSettings;

@Mixin(class_5493.class)
public abstract class NavigationConditionsMixin {
    /**
     * @author redColmula55
     * @reason Fix entity navigation under water-like fluids
     */
    @Overwrite
    public static boolean isWaterAt(class_1314 entity, class_2338 pos) {
        return FluidSettings.get(entity.method_37908().method_8316(pos)).canSwim();
    }
}
