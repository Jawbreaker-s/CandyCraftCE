package rc55.mc.rfapi.mixin;

import net.minecraft.class_1755;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_1755.class)
public abstract class BucketItemMixin {
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/Fluid;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"),
            method = "placeFluid",
            slice = @Slice(
                    from = @At(value = "INVOKE", target = "Lnet/minecraft/world/dimension/DimensionType;ultrawarm()Z"),
                    to = @At(value = "INVOKE", target = "Lnet/minecraft/util/math/BlockPos;getX()I")
            )
    )
    public boolean rfapi$hookUltrawarmPlaceableCheck(class_3611 instance, class_6862<class_3611> tag) {
        return instance.method_15791(tag == net.minecraft.class_3486.field_15517 ? FluidTags.DISAPPEAR_IN_ULTRAWARM : tag);
    }
}
