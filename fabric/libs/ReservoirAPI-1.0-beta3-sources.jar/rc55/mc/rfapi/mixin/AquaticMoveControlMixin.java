package rc55.mc.rfapi.mixin;

import net.minecraft.class_1308;
import net.minecraft.class_5757;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_5757.class)
public abstract class AquaticMoveControlMixin {
    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/mob/MobEntity;isTouchingWater()Z"
            ),
            method = "tick"
    )
    public boolean rfapi$fixAquaticMobPathFinding(class_1308 entity) {
        return entity.isTouchingFluid(fluid -> fluid.getSettings().canSwim());
    }
}
