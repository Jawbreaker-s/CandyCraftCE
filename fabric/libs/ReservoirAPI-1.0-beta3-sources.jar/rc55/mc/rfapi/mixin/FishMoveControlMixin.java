package rc55.mc.rfapi.mixin;

import net.minecraft.class_1422;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(targets = "net.minecraft.entity.passive.FishEntity$FishMoveControl")
public abstract class FishMoveControlMixin {
    @SuppressWarnings("rawtypes")
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/passive/FishEntity;isSubmergedIn(Lnet/minecraft/registry/tag/TagKey;)Z"),
            method = "tick"
    )
    public boolean rfapi$fixFishMoveUnderwater(class_1422 instance, class_6862 tagKey) {
        return instance.method_5777(FluidTags.DUMMY_WATER_PHYSICS_TAG);
    }
}
