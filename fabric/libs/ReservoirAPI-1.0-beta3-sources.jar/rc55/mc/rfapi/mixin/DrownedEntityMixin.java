package rc55.mc.rfapi.mixin;

import net.minecraft.class_1309;
import net.minecraft.class_1551;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1551.class)
public abstract class DrownedEntityMixin {
    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/mob/DrownedEntity;isTouchingWater()Z"
            ),
            method = {"travel", "updateSwimming"}
    )
    public boolean rfapi$fixDrownedSwimming(class_1551 entity) {
        return entity.isTouchingFluid(fluid -> fluid.getSettings().canSwim());
    }

    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;isTouchingWater()Z"
            ),
            method = {"isTargetingUnderwater", "canDrownedAttackTarget"}
    )
    public boolean rfapi$fixDrownedAttackTargeting(class_1309 entity) {
        return entity.isTouchingFluid(fluid -> fluid.getSettings().canSwim());
    }
}
