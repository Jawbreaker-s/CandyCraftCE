package rc55.mc.rfapi.mixin;

import net.minecraft.class_12;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidHelper;

@Mixin(class_12.class)
public class WaterPathNodeMakerMixin {
    // Changes how entity seeks path inside fluid
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/FluidState;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"),
            method = "getNodeType"
    )
    public boolean rfapi$fixNavigationInFluid(class_3610 state, class_6862<class_3611> tag) {
        return FluidHelper.checkEntityMoveAction(state.method_15772(), tag);
    }
}
