package rc55.mc.rfapi.mixin;

import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4538;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rc55.mc.rfapi.fluid.FluidHelper;

@Mixin(class_3609.class)
public abstract class FlowableFluidMixin extends class_3611 {
    @Shadow protected abstract int getLevelDecreasePerBlock(class_4538 world);

    @Inject(at = @At("HEAD"), method = "getUpdatedState", cancellable = true)
    public void rfapi$hookCustomSourceConversion(class_1937 world, class_2338 pos, class_2680 state, CallbackInfoReturnable<class_3610> cir) {
        cir.setReturnValue(FluidHelper.getUpdatedState((class_3609)(Object) this, world, pos, state, this.getLevelDecreasePerBlock(world)));
    }

    @Override
    protected boolean method_15777(class_3610 state, class_1922 world, class_2338 pos, class_3611 fluid, class_2350 direction) {
        return FluidHelper.canBeReplacedWith(this, state, world, pos, fluid, direction);
    }

    @Override
    public void method_15778(class_1937 world, class_2338 pos, class_3610 state) {
        FluidHelper.onScheduledTick((class_3609)(Object) this, world, pos, state, this.getLevelDecreasePerBlock(world));
    }
}
