package rc55.mc.rfapi.mixin;

import net.minecraft.class_2298;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_2298.class)
public abstract class CoralBlockBlockMixin {
    // Only survives in fluids that has #c:coral_survives tag
    @Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/FluidState;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"), method = "isInWater")
    public boolean rfapi$checkCanSurvive(class_3610 instance, class_6862<class_3611> tag) {
        return instance.method_15767(FluidTags.CORAL_SURVIVES);
    }
}
