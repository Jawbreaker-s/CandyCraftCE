package rc55.mc.rfapi.mixin;

import net.minecraft.class_1308;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(targets = "net.minecraft.entity.passive.FrogEntity$FrogSwimPathNodeMaker")
public class FrogSwimPathNodeMakerMixin {
    @Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/MobEntity;isTouchingWater()Z"), method = "getStart")
    public boolean rfapi$fixFrogSwimmingPathFinding(class_1308 instance) {
        return instance.isTouchingFluid(fluid -> fluid.getSettings().canSwim());
    }
}
