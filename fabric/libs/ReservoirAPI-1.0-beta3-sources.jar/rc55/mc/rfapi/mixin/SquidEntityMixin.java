package rc55.mc.rfapi.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1299;
import net.minecraft.class_1477;
import net.minecraft.class_1480;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_1477.class)
public abstract class SquidEntityMixin extends class_1480 {
    protected SquidEntityMixin(class_1299<? extends class_1480> entityType, class_1937 world) {
        super(entityType, world);
    }

    @ModifyExpressionValue(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/passive/SquidEntity;isInsideWaterOrBubbleColumn()Z"),
            method = "tickMovement"
    )
    public boolean rfapi$fixMovementUnderwater(boolean original) {
        return original || this.method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > 0.;
    }
}
