package rc55.mc.rfapi.mixin;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3616;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rc55.mc.rfapi.fluid.FluidHelper;

@Mixin(class_3616.class)
public abstract class LavaFluidMixin extends class_3609 {
    @Inject(at = @At("HEAD"), method = "canBeReplacedWith", cancellable = true)
    public void rfapi$hookCustomFlowIntoLogic(
            class_3610 state, class_1922 world, class_2338 pos, class_3611 fluid, class_2350 direction, CallbackInfoReturnable<Boolean> cir
    ) {
        cir.setReturnValue(FluidHelper.canBeReplacedWith(this, state, world, pos, fluid, direction));
    }

    /**
     * Disables vanilla lava create stone
     */
    @Redirect(at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/FluidState;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"), method = "flow")
    public boolean rfapi$disableVanillaStoneCreation(class_3610 instance, class_6862<class_3611> tag) {
        return false;
    }
}
