package rc55.mc.rfapi.mixin;

import com.google.common.base.Predicates;
import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import it.unimi.dsi.fastutil.objects.Object2DoubleArrayMap;
import it.unimi.dsi.fastutil.objects.Object2DoubleMap;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rc55.mc.rfapi.entity.IFluidCollidable;
import rc55.mc.rfapi.fluid.FluidHelper;
import rc55.mc.rfapi.fluid.FluidTags;
import rc55.mc.rfapi.fluid.FluidSettings;

import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Stream;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;

@Mixin(class_1297.class)
public abstract class EntityMixin implements IFluidCollidable {
    @Shadow
    private @Final Set<class_6862<class_3611>> submergedFluidTag;

    @Shadow
    protected Object2DoubleMap<class_6862<class_3611>> fluidHeight;

    // Adds dummy tags in submergedFluidTag, in order to modify physics related submersion check
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/FluidState;streamTags()Ljava/util/stream/Stream;"),
            method = "updateSubmergedInWaterState"
    )
    public Stream<class_6862<class_3611>> rfapi$appendDummyFluidTags(class_3610 instance) {
        final FluidSettings.EntityMovementType type = instance.method_15772().getSettings().getMovementType();
        if (type == FluidSettings.EntityMovementType.WATER) {
            this.submergedFluidTag.add(FluidTags.DUMMY_WATER_PHYSICS_TAG);
        } else if (type == FluidSettings.EntityMovementType.LAVA) {
            this.submergedFluidTag.add(FluidTags.DUMMY_LAVA_PHYSICS_TAG);
        }
        if (!instance.method_15769() && !instance.method_15772().getSettings().canEntityBreath()) {
            this.submergedFluidTag.add(FluidTags.DUMMY_UNBREATHABLE_TAG);
        }
        return instance.method_40181();
    }

    @Inject(at = @At("HEAD"), method = "updateWaterState")
    public void rfapi$initCustomFluidHeightMap(CallbackInfoReturnable<Boolean> cir) {
        this.rfapi$fluidHeightMap.clear();
    }

    @ModifyReturnValue(method = "updateWaterState", at = @At("RETURN"))
    public boolean rfapi$hookTouchingFluidCheck(boolean original) {
        this.updateMovementInFluid(FluidSettings.EntityMovementType.HORIZONTAL, 0.014f);
        return original || this.isTouchingFluid(Predicates.alwaysTrue());
    }

    @Redirect(method = {"move", "isCrawling"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/Entity;isTouchingWater()Z"))
    public boolean rfapi$fixPlayerSwimmingSpeed(class_1297 instance) {
        return this.isTouchingFluid(fluid -> fluid.getSettings().canSwim());
    }

    @Inject(at = @At("TAIL"), method = "baseTick")
    public void rfapi$applyLavaLikeFluidEffects(CallbackInfo ci) {
        final class_1297 self = (class_1297)(Object) this;
        if (this.isTouchingFluid(fluid -> fluid.getSettings().getMovementType() == FluidSettings.EntityMovementType.LAVA)) {
            if (self.field_6017 > 0f) {
                self.field_6017 *= 0.5f;
            }
        }
        if (this.isTouchingFluid(fluid -> fluid.getSettings().canSetFire())) {
            self.method_5730();
            self.method_33572(self.method_20802() > 0);
        }
    }

    @ModifyReturnValue(at = @At("RETURN"), method = "shouldSpawnSprintingParticles")
    public boolean rfapi$fixSprintingParticle(boolean original) {
        final class_1297 self = (class_1297)(Object) this;
        return original && !self.method_20232() && !this.isTouchingFluid(Predicates.alwaysTrue());
    }

    /**
     * @author redColmula55
     * @reason Changes fluid check for entities
     */
    @Overwrite
    public double getFluidHeight(class_6862<class_3611> tag) {
        if (tag == FluidTags.WATER) {
            return this.fluidHeight.getDouble(FluidTags.DUMMY_WATER_PHYSICS_TAG);
        } else if (tag == FluidTags.LAVA) {
            return this.fluidHeight.getDouble(FluidTags.DUMMY_LAVA_PHYSICS_TAG);
        }
        return this.fluidHeight.getDouble(tag);
    }

    /**
     * @author redColmula55
     * @reason Make watery fluid(Movement type set to {@link rc55.mc.rfapi.fluid.FluidSettings.EntityMovementType#WATER}) swimmable
     */
    @Overwrite
    public void updateSwimming() {
        final class_1297 self = (class_1297)(Object) this;

        if (self.method_5681()) {
            self.method_5796(self.method_5624()
                    && this.isTouchingFluid(fluid -> fluid.getSettings().canSwim())
                    && !self.method_5765()
            );
        } else {
            self.method_5796(self.method_5624()
                    && this.submergedFluidTag.contains(FluidTags.DUMMY_WATER_PHYSICS_TAG)
                    && !self.method_5765()
                    && FluidSettings.get(self.method_37908().method_8316(self.method_24515())).canSwim()
            );
        }
    }

    /**
     * @author redColmula55
     * @reason Make fluids able to push entities
     */
    @Overwrite
    public boolean updateMovementInFluid(class_6862<class_3611> tag, double speed) {
        if (tag == FluidTags.WATER) {
            this.updateMovementInFluid(FluidSettings.EntityMovementType.WATER, speed);
        } else if (tag == FluidTags.LAVA) {
            this.updateMovementInFluid(FluidSettings.EntityMovementType.LAVA, speed);
        } else {
            this.updateMovementInFluid(FluidSettings.EntityMovementType.HORIZONTAL, speed);
            return false;
        }
        return this.fluidHeight.containsKey(tag);
    }

    @Unique
    private final Object2DoubleMap<class_3611> rfapi$fluidHeightMap = new Object2DoubleArrayMap<>();

    @Unique
    public void updateMovementInFluid(FluidSettings.EntityMovementType type, double speed) {
        final class_1297 self = (class_1297)(Object) this;
        if (self.method_33724()) {
            return;// false;
        }
        class_238 box = self.method_5829().method_1011(0.001);
        int minX = class_3532.method_15357(box.field_1323);
        int maxX = class_3532.method_15384(box.field_1320);
        int minY = class_3532.method_15357(box.field_1322);
        int maxY = class_3532.method_15384(box.field_1325);
        int minZ = class_3532.method_15357(box.field_1321);
        int maxZ = class_3532.method_15384(box.field_1324);
        double touchedFluidHeight = 0.0;
        boolean canPush = self.method_5675();
        boolean bl2 = false;
        class_243 motionVec = class_243.field_1353;
        int count = 0;
        class_2338.class_2339 mutable = new class_2338.class_2339();

        final List<class_3611> list = new ArrayList<>(2);
        for (int x = minX; x < maxX; x++) {
            for (int y = minY; y < maxY; y++) {
                for (int z = minZ; z < maxZ; z++) {
                    mutable.method_10103(x, y, z);
                    class_3610 fluidState = self.method_37908().method_8316(mutable);
                    FluidSettings settings = FluidSettings.get(fluidState);
                    if (!fluidState.method_15769() && settings.getMovementType() == type) {//fluidState.isIn(tag)
                        double fluidHeight = y + fluidState.method_15763(self.method_37908(), mutable);
                        if (fluidHeight >= box.field_1322) {
                            bl2 = true;
                            touchedFluidHeight = Math.max(fluidHeight - box.field_1322, touchedFluidHeight);
                            if (canPush) {
                                class_243 vec3d2 = fluidState.method_15758(self.method_37908(), mutable);
                                if (touchedFluidHeight < 0.4) {
                                    vec3d2 = vec3d2.method_1021(touchedFluidHeight);
                                }

                                motionVec = motionVec.method_1019(vec3d2);
                                count++;
                            }
                        }

                        list.add(FluidHelper.trim(fluidState.method_15772()));
                    }
                }
            }
        }

        if (motionVec.method_1033() > 0.0) {
            if (count > 0) {
                motionVec = motionVec.method_1021(1.0 / count);
            }

            if (!(self instanceof class_1657)) {
                motionVec = motionVec.method_1029();
            }

            class_243 vec3d3 = self.method_18798();
            motionVec = motionVec.method_1021(speed * 1.0);
            double f = 0.003;
            if (Math.abs(vec3d3.field_1352) < 0.003 && Math.abs(vec3d3.field_1350) < 0.003 && motionVec.method_1033() < 0.0045000000000000005) {
                motionVec = motionVec.method_1029().method_1021(0.0045000000000000005);
            }

            self.method_18799(self.method_18798().method_1019(motionVec));
        }

//            this.fluidHeight.put(tag, touchedFluidHeight);
//            return bl2;
        double finalTouchedFluidHeight = touchedFluidHeight;
        list.forEach(fluid -> {
            this.rfapi$fluidHeightMap.put(fluid, finalTouchedFluidHeight);

            final FluidSettings settings = fluid.getSettings();
            if (settings.getMovementType() == FluidSettings.EntityMovementType.WATER) {
                this.fluidHeight.put(FluidTags.DUMMY_WATER_PHYSICS_TAG, finalTouchedFluidHeight);
                // Reduce fall damage in watery fluid
                self.method_38785();
            } else if (settings.getMovementType() == FluidSettings.EntityMovementType.LAVA) {
                this.fluidHeight.put(FluidTags.DUMMY_LAVA_PHYSICS_TAG, finalTouchedFluidHeight);
            }

            if (fluid.method_15791(net.minecraft.class_3486.field_15517)) {
                this.fluidHeight.put(net.minecraft.class_3486.field_15517, finalTouchedFluidHeight);
            }
            if (fluid.method_15791(net.minecraft.class_3486.field_15518)) {
                this.fluidHeight.put(net.minecraft.class_3486.field_15518, finalTouchedFluidHeight);
            }
        });
    }

    @Override
    public boolean isTouchingFluid(Predicate<class_3611> predicate) {
        return this.rfapi$fluidHeightMap.object2DoubleEntrySet().stream().anyMatch(entry -> {
            final class_3611 fluid = entry.getKey();
            if (predicate.test(fluid)) {
                return entry.getDoubleValue() > 0.;
            }
            return false;
        });
    }
}
