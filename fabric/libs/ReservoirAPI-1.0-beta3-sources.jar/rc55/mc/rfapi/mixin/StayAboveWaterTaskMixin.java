package rc55.mc.rfapi.mixin;

import net.minecraft.class_1308;
import net.minecraft.class_3218;
import net.minecraft.class_4125;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import rc55.mc.rfapi.fluid.FluidHelper;

@Mixin(class_4125.class)
public class StayAboveWaterTaskMixin {
    /**
     * @author redColmula55
     * @reason Fix entity swimming in fluid without valid tags
     */
    @Overwrite
    public boolean shouldRun(class_3218 world, class_1308 mob) {
        return FluidHelper.checkCanMobSwim(mob);
    }
}
