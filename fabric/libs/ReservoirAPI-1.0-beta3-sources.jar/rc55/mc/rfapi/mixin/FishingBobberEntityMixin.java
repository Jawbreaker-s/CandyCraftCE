package rc55.mc.rfapi.mixin;

import net.minecraft.class_1536;
import net.minecraft.class_2338;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rc55.mc.rfapi.RFApiConfigs;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_1536.class)
public abstract class FishingBobberEntityMixin {
    // Only catch fish in fluids with #c:has_fishes
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/FluidState;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"), method = "tick"
    )
    public boolean rfapi$modifyBobberTickingPredicate(class_3610 instance, class_6862<class_3611> tag) {
        return instance.method_15767(FluidTags.HAS_FISHES);
    }

    @Inject(at = @At("HEAD"), method = "isOpenOrWaterAround", cancellable = true)
    public void rfapi$modifyOpenWaterCheck(class_2338 pos, CallbackInfoReturnable<Boolean> cir) {
        if (RFApiConfigs.getInstance().disableOpenWaterCheck) {
            cir.setReturnValue(true);
        }
    }
}
