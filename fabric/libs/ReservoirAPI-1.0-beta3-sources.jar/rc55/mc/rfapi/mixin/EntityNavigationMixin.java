package rc55.mc.rfapi.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1308;
import net.minecraft.class_1408;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_1408.class)
public abstract class EntityNavigationMixin {
    @Shadow
    protected @Final class_1308 entity;

    @ModifyReturnValue(at = @At("RETURN"), method = "isInLiquid")
    public boolean rfapi$fixNavigationInFluid(boolean original) {
        return original
                || this.entity.method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > 0
                || this.entity.method_5861(FluidTags.DUMMY_LAVA_PHYSICS_TAG) > 0;
    }
}
