package rc55.mc.rfapi.mixin;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidHelper;

@Mixin(class_3610.class)
public abstract class FluidStateMixin {
    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/fluid/Fluid;canBeReplacedWith(Lnet/minecraft/fluid/FluidState;Lnet/minecraft/world/BlockView;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/fluid/Fluid;Lnet/minecraft/util/math/Direction;)Z"
            ),
            method = "canBeReplacedWith"
    )
    public boolean rfapi$hookCustomFlowIntoLogic(class_3611 instance, class_3610 state, class_1922 blockView, class_2338 pos, class_3611 fluid, class_2350 direction) {
        return FluidHelper.canBeReplacedWith(instance, state, blockView, pos, fluid, direction);
    }
}
