package rc55.mc.rfapi.mixin;

import net.minecraft.class_1480;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_1480.class)
public class WaterCreatureEntityMixin {
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/WaterCreatureEntity;isInsideWaterOrBubbleColumn()Z"),
            method = "tickWaterBreathingAir"
    )
    public boolean rfapi$modifyWaterCreatureBreathing(class_1480 instance) {
        return instance.method_5777(FluidTags.DUMMY_UNBREATHABLE_TAG) || instance.method_5816();
    }
}
