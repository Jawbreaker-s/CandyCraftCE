package rc55.mc.rfapi.mixin;

import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.jetbrains.annotations.ApiStatus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@ApiStatus.Internal
@Mixin(class_3609.class)
public interface FlowableFluidAccessor {
    @Invoker("receivesFlow")
    boolean invoke_receivesFlow(class_2350 face, class_1922 world, class_2338 pos, class_2680 state, class_2338 fromPos, class_2680 fromState);

    @Invoker("canFill")
    boolean invoke_canFill(class_1922 world, class_2338 pos, class_2680 state, class_3611 fluid);

    @Invoker("getNextTickDelay")
    int invoke_getNextTickDelay(class_1937 world, class_2338 pos, class_3610 oldState, class_3610 newState);

    @Invoker("tryFlow")
    void invoke_tryFlow(class_1937 world, class_2338 fluidPos, class_3610 state);
}
