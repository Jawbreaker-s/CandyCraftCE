package rc55.mc.rfapi.mixin;

import net.minecraft.class_1308;
import net.minecraft.class_1347;
import org.jetbrains.annotations.ApiStatus;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@ApiStatus.Internal
@Mixin(class_1347.class)
public interface SwimGoalAccessor {
    @Accessor("mob")
    class_1308 rfapi$getGoalMob();
}
