package rc55.mc.rfapi.mixin;

import net.minecraft.class_1308;
import net.minecraft.class_14;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidHelper;
import rc55.mc.rfapi.fluid.FluidTags;
import rc55.mc.rfapi.fluid.FluidSettings;

@Mixin(class_14.class)
public abstract class LandPathNodeMakerMixin {
    // Changes how entity moves inside fluid
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/FluidState;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"),
            method = {"getCommonNodeType", "getNodeTypeFromNeighbors", "getFeetY(Lnet/minecraft/util/math/BlockPos;)D"}
    )
    private static boolean rfapi$fixNavigationInFluid(class_3610 state, class_6862<class_3611> tag) {
        return FluidHelper.checkEntityMoveAction(state.method_15772(), tag);
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/mob/MobEntity;isTouchingWater()Z"),
            method = "getStart()Lnet/minecraft/entity/ai/pathing/PathNode;"
    )
    public boolean rfapi$fixNavigationInFluid(class_1308 instance) {
        return instance.method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > 0.;
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;isOf(Lnet/minecraft/block/Block;)Z"),
            method = "getStart()Lnet/minecraft/entity/ai/pathing/PathNode;"
    )
    public boolean rfapi$fixNavigationInFluid(class_2680 instance, class_2248 block) {
        return FluidSettings.get(instance.method_26227()).canSwim();
    }
}
