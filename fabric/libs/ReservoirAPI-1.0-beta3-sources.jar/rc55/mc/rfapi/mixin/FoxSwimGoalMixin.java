package rc55.mc.rfapi.mixin;

import net.minecraft.class_1308;
import net.minecraft.class_1347;
import org.spongepowered.asm.mixin.Mixin;
import rc55.mc.rfapi.fluid.FluidSettings;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(targets = "net.minecraft.entity.passive.FoxEntity$FoxSwimGoal")
public abstract class FoxSwimGoalMixin extends class_1347 {
    private FoxSwimGoalMixin(class_1308 mob) {
        super(mob);
    }

    @Override
    public boolean method_6264() {
        return ((SwimGoalAccessor)this).rfapi$getGoalMob().method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > 0.25
                || ((SwimGoalAccessor)this).rfapi$getGoalMob().isTouchingFluid(fluid -> fluid.getSettings().getMovementType() == FluidSettings.EntityMovementType.LAVA);
    }
}
