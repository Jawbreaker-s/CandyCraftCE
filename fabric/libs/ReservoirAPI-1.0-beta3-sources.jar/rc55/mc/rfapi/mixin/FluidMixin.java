package rc55.mc.rfapi.mixin;

import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Mixin;
import rc55.mc.rfapi.fluid.IFluidWithSettings;

@Mixin(class_3611.class)
public class FluidMixin implements IFluidWithSettings {
}
