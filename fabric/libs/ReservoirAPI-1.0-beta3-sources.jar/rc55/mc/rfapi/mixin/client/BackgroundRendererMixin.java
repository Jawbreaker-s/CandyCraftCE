package rc55.mc.rfapi.mixin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_4184;
import net.minecraft.class_5636;
import net.minecraft.class_638;
import net.minecraft.class_758;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rc55.mc.rfapi.RFApiConfigs;
import rc55.mc.rfapi.client.FluidFogEvents;
import rc55.mc.rfapi.fluid.FluidSettings;

@Mixin(class_758.class)
public abstract class BackgroundRendererMixin {
    @Shadow
    private static float red, green, blue;

    @Inject(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/BackgroundRenderer;getFogModifier(Lnet/minecraft/entity/Entity;F)Lnet/minecraft/client/render/BackgroundRenderer$StatusEffectFogModifier;"
            ),
            method = "render"
    )
    private static void rfapi$modifyFluidFogColor(class_4184 camera, float tickDelta, class_638 world, int viewDistance, float skyDarkness, CallbackInfo ci) {
        if (camera.method_19334() != class_5636.field_27888 && !RFApiConfigs.getInstance().replaceVanillaFog) return;
        class_3610 state = world.method_8316(camera.method_19328());
        if (!state.method_15769()) {
            FluidSettings.ColorSettings settings = getCustomColor(world, camera.method_19328());
            // Vanilla water fog color depends on biome, so here we exclude it so vanilla logic can perform
            if (!state.method_39360(class_3612.field_15910) && settings != null && settings.shouldRenderFog()) {
                final int color = settings.fogColor();
                red = ((color >> 16) & 0xFF) / 255f;
                green = ((color >> 8) & 0xFF) / 255f;
                blue = (color & 0xFF) / 255f;
            }
            final int color = FluidFogEvents.COLOR.invoker().getFogColor(
                    camera, tickDelta, world, camera.method_19328(), state, viewDistance, skyDarkness
            );
            if (color != -1) {
                red = ((color >> 16) & 0xFF) / 255f;
                green = ((color >> 8) & 0xFF) / 255f;
                blue = (color & 0xFF) / 255f;
            }
        }
    }

    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/Camera;getSubmersionType()Lnet/minecraft/client/render/CameraSubmersionType;"
            ),
            method = "applyFog"
    )
    private static class_5636 rfapi$modifyFluidFogRenderDistance(class_4184 instance) {
        return getFogRenderType(class_310.method_1551().field_1687, instance);
    }

    @Inject(at = @At("TAIL"), method = "applyFog")
    private static void rfapi$clearFogOnConfig(class_4184 camera, class_758.class_4596 fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci) {
        class_5636 type = getFogRenderType(class_310.method_1551().field_1687, camera);
        if (type == class_5636.field_27885 && RFApiConfigs.getInstance().clearLavaFog) {
            RenderSystem.setShaderFogStart(-8f);
            RenderSystem.setShaderFogEnd(viewDistance * 0.1f);
        } else if (type == class_5636.field_27887 && RFApiConfigs.getInstance().clearSnowFog) {
            RenderSystem.setShaderFogStart(-8f);
            RenderSystem.setShaderFogEnd(viewDistance * 0.1f);
        }
        FluidFogEvents.DISTANCE.invoker().modifyFogDistance(
                camera, fogType, viewDistance, thickFog, tickDelta,
                RenderSystem::setShaderFogStart, RenderSystem::setShaderFogEnd, RenderSystem::setShaderFogShape
        );
    }

    @Unique
    private static @Nullable FluidSettings.ColorSettings getCustomColor(class_1922 world, class_2338 pos) {
        return world.method_8316(pos).method_15769() ? null : world.method_8316(pos).method_15772().getSettings().getColor();
    }

    @Unique
    private static class_5636 getFogRenderType(@Nullable class_638 world, class_4184 camera) {
        if (world != null) {
            FluidSettings.ColorSettings settings = getCustomColor(world, camera.method_19328());
            if (settings != null && settings.shouldRenderFog()) {
                return switch (settings.fogType()) {
                    case WATER -> class_5636.field_27886;
                    case LAVA -> class_5636.field_27885;
                    case SNOW -> class_5636.field_27887;
                    default -> camera.method_19334();
                };
            }
        }
        return camera.method_19334();
    }
}
