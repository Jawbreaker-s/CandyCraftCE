package rc55.mc.rfapi.mixin.client;

import net.minecraft.class_1431;
import net.minecraft.class_885;
import net.minecraft.client.render.entity.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_885.class)
public abstract class CodEntityRendererMixin {
    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/passive/CodEntity;isTouchingWater()Z"
            ),
            method = "setupTransforms(Lnet/minecraft/entity/passive/CodEntity;Lnet/minecraft/client/util/math/MatrixStack;FFF)V"
    )
    public boolean rfapi$fixFishRenderDirection(class_1431 entity) {
        return entity.isTouchingFluid(fluid -> fluid.getSettings().canSwim());
    }
}
