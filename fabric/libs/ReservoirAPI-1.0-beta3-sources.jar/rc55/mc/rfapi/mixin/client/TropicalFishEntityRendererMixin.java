package rc55.mc.rfapi.mixin.client;

import net.minecraft.class_1474;
import net.minecraft.class_959;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_959.class)
public abstract class TropicalFishEntityRendererMixin {
    @Redirect(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/passive/TropicalFishEntity;isTouchingWater()Z"
            ),
            method = "setupTransforms(Lnet/minecraft/entity/passive/TropicalFishEntity;Lnet/minecraft/client/util/math/MatrixStack;FFF)V"
    )
    public boolean rfapi$fixFishRenderDirection(class_1474 entity) {
        return entity.isTouchingFluid(fluid -> fluid.getSettings().canSwim());
    }
}
