package rc55.mc.rfapi.mixin.client;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_638;
import net.minecraft.class_742;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_746.class)
public abstract class ClientPlayerEntityMixin extends class_742 {
    public ClientPlayerEntityMixin(class_638 world, GameProfile profile) {
        super(world, profile);
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isSubmergedInWater()Z"),
            method = "tickMovement"
    )
    public boolean rfapi$hookCanSwimCheck(class_746 instance) {
        return instance.method_5777(FluidTags.DUMMY_WATER_PHYSICS_TAG);
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isTouchingWater()Z"),
            method = "tickMovement"
    )
    public boolean rfapi$hookCanSwimCheck2(class_746 instance) {
        return instance.method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > 0.;
    }
}
