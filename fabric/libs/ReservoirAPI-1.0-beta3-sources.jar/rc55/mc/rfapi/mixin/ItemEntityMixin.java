package rc55.mc.rfapi.mixin;

import net.minecraft.class_1542;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin {
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/ItemEntity;isTouchingWater()Z"),
            method = "tick"
    )
    public boolean rfapi$hookPhysicsInLavaLikeFluid(class_1542 instance) {
        return instance.method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > 0.;
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/ItemEntity;isInLava()Z"),
            method = "tick"
    )
    public boolean rfapi$hookPhysicsInWaterLikeFluid(class_1542 instance) {
        return instance.method_5861(FluidTags.DUMMY_LAVA_PHYSICS_TAG) > 0.;
    }
}
