package rc55.mc.rfapi.mixin;

import net.minecraft.class_2230;
import net.minecraft.class_2289;
import net.minecraft.class_2393;
import net.minecraft.class_2476;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin({class_2476.class, class_2393.class, class_2230.class, class_2289.class})
public class WaterloggablePlantBlocksMixin {
    /* Vanilla underwater plants etc. can be placed in any fluid with #minecraft:water tag
     * But Fabric mods will usually add fluids in #minecraft:water in order to make them has physics
     * Also when in vanilla or in most mods, blocks can only be waterlogged with actual vanilla water
     * Thus making mod fluids turns into water while Minecraft trying to waterlog these blocks
     * Therefor we need to Mixin them to make them only waterlog in vanilla water to prevent this
     */
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/FluidState;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"),
            method = "getPlacementState"
    )
    public boolean rfapi$checkWaterloggingPlacement(class_3610 instance, class_6862<class_3611> tag) {
        return instance.method_39360(class_3612.field_15910);
    }
}
