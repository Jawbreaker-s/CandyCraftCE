package rc55.mc.rfapi.mixin.compat.client;

import me.jellysquid.mods.sodium.client.model.color.ColorProvider;
import me.jellysquid.mods.sodium.client.model.light.LightMode;
import me.jellysquid.mods.sodium.client.model.light.LightPipeline;
import me.jellysquid.mods.sodium.client.model.light.LightPipelineProvider;
import me.jellysquid.mods.sodium.client.model.quad.ModelQuadView;
import me.jellysquid.mods.sodium.client.model.quad.ModelQuadViewMutable;
import me.jellysquid.mods.sodium.client.model.quad.properties.ModelQuadFacing;
import me.jellysquid.mods.sodium.client.render.chunk.compile.ChunkBuildBuffers;
import me.jellysquid.mods.sodium.client.render.chunk.compile.buffers.ChunkModelBuilder;
import me.jellysquid.mods.sodium.client.render.chunk.compile.pipeline.FluidRenderer;
import me.jellysquid.mods.sodium.client.render.chunk.terrain.material.DefaultMaterials;
import me.jellysquid.mods.sodium.client.render.chunk.terrain.material.Material;
import me.jellysquid.mods.sodium.client.world.WorldSlice;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.minecraft.class_1058;
import net.minecraft.class_1920;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rc55.mc.rfapi.client.FluidRenderRegistry;
import rc55.mc.rfapi.fluid.FluidSettings;

/**
 * Fluid renderer for RFAPI fluids
 * Sodium compatible
 * @author redColmula55
 */
@Mixin(FluidRenderer.class)
public abstract class FluidRendererMixin {
    @Shadow(remap = false)
    private @Final ModelQuadViewMutable quad;
    
    @Shadow(remap = false)
    private @Final LightPipelineProvider lighters;

    @Shadow(remap = false)
    private static boolean isAlignedEquals(float a, float b) {
        throw new UnsupportedOperationException();
    }

    @Shadow
    protected abstract void updateQuad(ModelQuadView quad, WorldSlice world, class_2338 pos, LightPipeline lighter, class_2350 dir, float brightness, ColorProvider<class_3610> colorProvider, class_3610 fluidState);

    @Shadow
    protected abstract void writeQuad(ChunkModelBuilder builder, Material material, class_2338 offset, ModelQuadView quad, ModelQuadFacing facing, boolean flip);

    @Shadow
    private static FluidRenderHandler getFluidRenderHandler(class_3610 fluidState) {
        throw new UnsupportedOperationException();
    }

    @Shadow
    protected abstract ColorProvider<class_3610> getColorProvider(class_3611 fluid, FluidRenderHandler handler);

    @Shadow(remap = false)
    private static void setVertex(ModelQuadViewMutable quad, int i, float x, float y, float z, float u, float v) {
        throw new UnsupportedOperationException();
    }

    @Inject(at = @At("HEAD"), method = "render", cancellable = true)
    public void rfapi$hookCustomFluidRender(WorldSlice world, class_3610 fluidState, class_2338 pos, class_2338 offset, ChunkBuildBuffers buffers, CallbackInfo ci) {
        final class_2680 blockState = world.method_8320(pos);
        final class_3611 fluid = fluidState.method_15772();

        if (!FluidRenderRegistry.hasCustomRenderer(fluid)) {
            return;
        }

        Material material = DefaultMaterials.forFluidState(fluidState);
        ChunkModelBuilder meshBuilder = buffers.get(material);
        
        final FluidSettings settings = fluid.getSettings();
        final boolean flowsUp = settings.flowsUp();

        //计算要渲染的面
        class_2680 blockStateDown = world.method_8320(pos.method_10093(class_2350.field_11033));
        class_3610 fluidStateDown = blockStateDown.method_26227();
        class_2680 blockStateUp = world.method_8320(pos.method_10093(class_2350.field_11036));
        class_3610 fluidStateUp = blockStateUp.method_26227();
        class_2680 blockStateNorth = world.method_8320(pos.method_10093(class_2350.field_11043));
        class_3610 fluidStateNorth = blockStateNorth.method_26227();
        class_2680 blockStateSouth = world.method_8320(pos.method_10093(class_2350.field_11035));
        class_3610 fluidStateSouth = blockStateSouth.method_26227();
        class_2680 blockStateWest = world.method_8320(pos.method_10093(class_2350.field_11039));
        class_3610 fluidStateWest = blockStateWest.method_26227();
        class_2680 blockStateEast = world.method_8320(pos.method_10093(class_2350.field_11034));
        class_3610 fluidStateEast = blockStateEast.method_26227();
        boolean hasSideUp, hasSideDown;
        if (flowsUp) {
            hasSideDown = !isSameFluid(fluidState, fluidStateDown);
            hasSideUp = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11036, fluidStateUp, flowsUp)
                    && !isSideCovered(world, pos, class_2350.field_11036, 0.8888889f, blockStateUp, flowsUp);
        } else {
            hasSideDown = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11033, fluidStateDown, flowsUp)
                    && !isSideCovered(world, pos, class_2350.field_11033, 0.8888889f, blockStateDown, flowsUp);
            hasSideUp = !isSameFluid(fluidState, fluidStateUp);
        }
        boolean hasSideN = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11043, fluidStateNorth, flowsUp);
        boolean hasSideS = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11035, fluidStateSouth, flowsUp);
        boolean hasSideW = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11039, fluidStateWest, flowsUp);
        boolean hasSideE = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11034, fluidStateEast, flowsUp);
        //渲染
        if (hasSideDown || hasSideUp || hasSideE || hasSideW || hasSideN || hasSideS) {
            FluidRenderHandler handler = getFluidRenderHandler(fluidState);
            ColorProvider<class_3610> colorProvider = this.getColorProvider(fluid, handler);
            class_1058[] sprites = handler.getFluidSprites(world, pos, fluidState);

            //渲染高度
            final float thisHeight = getFluidHeight(world, fluid, pos, blockState, fluidState, flowsUp);
            //计算方块顶点位置
            float cornerHeightNE, cornerHeightNW, cornerHeightSE, cornerHeightSW;
            if (thisHeight >= 1.0F) {
                //完整方块
                cornerHeightNE = 1.0F;
                cornerHeightNW = 1.0F;
                cornerHeightSE = 1.0F;
                cornerHeightSW = 1.0F;
            } else {
                //非完整方块
                float heightN = getFluidHeight(world, fluid, pos.method_10095(), blockStateNorth, fluidStateNorth, flowsUp);
                float heightS = getFluidHeight(world, fluid, pos.method_10072(), blockStateSouth, fluidStateSouth, flowsUp);
                float heightE = getFluidHeight(world, fluid, pos.method_10078(), blockStateEast, fluidStateEast, flowsUp);
                float heightW = getFluidHeight(world, fluid, pos.method_10067(), blockStateWest, fluidStateWest, flowsUp);
                cornerHeightNE = calculateFluidHeight(world, fluid, thisHeight, heightN, heightE, pos.method_10093(class_2350.field_11043).method_10093(class_2350.field_11034), flowsUp);
                cornerHeightNW = calculateFluidHeight(world, fluid, thisHeight, heightN, heightW, pos.method_10093(class_2350.field_11043).method_10093(class_2350.field_11039), flowsUp);
                cornerHeightSE = calculateFluidHeight(world, fluid, thisHeight, heightS, heightE, pos.method_10093(class_2350.field_11035).method_10093(class_2350.field_11034), flowsUp);
                cornerHeightSW = calculateFluidHeight(world, fluid, thisHeight, heightS, heightW, pos.method_10093(class_2350.field_11035).method_10093(class_2350.field_11039), flowsUp);
            }
            //坐标值
            float yOffset = (flowsUp ? hasSideUp : hasSideDown) ? 0.001F : 0.0F;

            ModelQuadViewMutable quad = this.quad;
            LightMode lightMode = class_310.method_1588() ? LightMode.SMOOTH : LightMode.FLAT;//isWater && 
            LightPipeline lighter = this.lighters.getLighter(lightMode);
            quad.setFlags(0);
            
            boolean shouldRenderTop;
            if (flowsUp) {
                shouldRenderTop = hasSideDown && !isSideCovered(world, pos, class_2350.field_11033, Math.min(Math.min(cornerHeightNW, cornerHeightSW), Math.min(cornerHeightSE, cornerHeightNE)), blockStateDown, flowsUp);
            } else {
                shouldRenderTop = hasSideUp && !isSideCovered(world, pos, class_2350.field_11036, Math.min(Math.min(cornerHeightNW, cornerHeightSW), Math.min(cornerHeightSE, cornerHeightNE)), blockStateUp, flowsUp);
            }
            //渲染顶面（与流动方向相反的面）
            if (shouldRenderTop) {
                cornerHeightNW -= 0.001F;
                cornerHeightSW -= 0.001F;
                cornerHeightSE -= 0.001F;
                cornerHeightNE -= 0.001F;
                //流动性
                class_243 flowVec = fluidState.method_15758(world, pos);
                //获取贴图帧位置
                float u1, u2, u3, u4, v1, v2, v3, v4;
                class_1058 sprite;
                ModelQuadFacing facing;
                if (flowVec.field_1352 == 0.0 && flowVec.field_1350 == 0.0) {
                    //静止
                    sprite = sprites[0];
                    facing = ModelQuadFacing.POS_Y;
                    u1 = sprite.method_4580(0.0);
                    v1 = sprite.method_4570(0.0);
                    u2 = u1;
                    v2 = sprite.method_4570(16.0);
                    u3 = sprite.method_4580(16.0);
                    v3 = v2;
                    u4 = u3;
                    v4 = v1;
                } else {
                    //流动
                    sprite = sprites[1];
                    facing = ModelQuadFacing.UNASSIGNED;
                    float ah = (float) class_3532.method_15349(flowVec.field_1350, flowVec.field_1352) - (float) (Math.PI / 2);
                    float ai = class_3532.method_15374(ah) * 0.25F;
                    float aj = class_3532.method_15362(ah) * 0.25F;
                    u1 = sprite.method_4580(8.0F + (-aj - ai) * 16.0F);
                    v1 = sprite.method_4570(8.0F + (-aj + ai) * 16.0F);
                    u2 = sprite.method_4580(8.0F + (-aj + ai) * 16.0F);
                    v2 = sprite.method_4570(8.0F + (aj + ai) * 16.0F);
                    u3 = sprite.method_4580(8.0F + (aj + ai) * 16.0F);
                    v3 = sprite.method_4570(8.0F + (aj - ai) * 16.0F);
                    u4 = sprite.method_4580(8.0F + (aj - ai) * 16.0F);
                    v4 = sprite.method_4570(8.0F + (-aj - ai) * 16.0F);
                }
                //计算材质顶点位置
                final float averageU = (u1 + u2 + u3 + u4) / 4.0F;
                final float averageV = (v1 + v2 + v3 + v4) / 4.0F;
                final float frameDelta = sprites[0].method_23842();
                u1 = class_3532.method_16439(frameDelta, u1, averageU);
                u2 = class_3532.method_16439(frameDelta, u2, averageU);
                u3 = class_3532.method_16439(frameDelta, u3, averageU);
                u4 = class_3532.method_16439(frameDelta, u4, averageU);
                v1 = class_3532.method_16439(frameDelta, v1, averageV);
                v2 = class_3532.method_16439(frameDelta, v2, averageV);
                v3 = class_3532.method_16439(frameDelta, v3, averageV);
                v4 = class_3532.method_16439(frameDelta, v4, averageV);
                //渲染
                quad.setSprite(sprite);

                boolean aligned = isAlignedEquals(cornerHeightNE, cornerHeightNW) 
                        && isAlignedEquals(cornerHeightNW, cornerHeightSE) 
                        && isAlignedEquals(cornerHeightSE, cornerHeightSW) 
                        && isAlignedEquals(cornerHeightSW, cornerHeightNE);
                boolean creaseNorthEastSouthWest = aligned 
                        || cornerHeightNE > cornerHeightNW && cornerHeightNE > cornerHeightSE 
                        || cornerHeightNE < cornerHeightNW && cornerHeightNE < cornerHeightSE 
                        || cornerHeightSW > cornerHeightNW && cornerHeightSW > cornerHeightSE 
                        || cornerHeightSW < cornerHeightNW && cornerHeightSW < cornerHeightSE;
                if (flowsUp) {
                    if (creaseNorthEastSouthWest) {
                        setVertex(quad, 1, 1.0F, 1 - cornerHeightNE, 0.0F, u4, v4);
                        setVertex(quad, 2, 1.0F, 1 - cornerHeightSE, 1.0F, u3, v3);
                        setVertex(quad, 3, 0.0F, 1 - cornerHeightSW, 1.0F, u2, v2);
                        setVertex(quad, 0, 0.0F, 1 - cornerHeightNW, 0.0F, u1, v1);
                    } else {
                        setVertex(quad, 0, 1.0F, 1 - cornerHeightNE, 0.0F, u4, v4);
                        setVertex(quad, 1, 1.0F, 1 - cornerHeightSE, 1.0F, u3, v3);
                        setVertex(quad, 2, 0.0F, 1 - cornerHeightSW, 1.0F, u2, v2);
                        setVertex(quad, 3, 0.0F, 1 - cornerHeightNW, 0.0F, u1, v1);
                    }
                } else {
                    if (creaseNorthEastSouthWest) {
                        setVertex(quad, 1, 0.0F, cornerHeightNW, 0.0F, u1, v1);
                        setVertex(quad, 2, 0.0F, cornerHeightSW, 1.0F, u2, v2);
                        setVertex(quad, 3, 1.0F, cornerHeightSE, 1.0F, u3, v3);
                        setVertex(quad, 0, 1.0F, cornerHeightNE, 0.0F, u4, v4);
                    } else {
                        setVertex(quad, 0, 0.0F, cornerHeightNW, 0.0F, u1, v1);
                        setVertex(quad, 1, 0.0F, cornerHeightSW, 1.0F, u2, v2);
                        setVertex(quad, 2, 1.0F, cornerHeightSE, 1.0F, u3, v3);
                        setVertex(quad, 3, 1.0F, cornerHeightNE, 0.0F, u4, v4);
                    }
                }

                this.updateQuad(quad, world, pos, lighter, flowsUp ? class_2350.field_11033 : class_2350.field_11036, 1.0F, colorProvider, fluidState);
                this.writeQuad(meshBuilder, material, offset, quad, facing, false);
                if (fluidState.method_15756(world, pos.method_10093(flowsUp ? class_2350.field_11033 : class_2350.field_11036))) {
                    this.writeQuad(meshBuilder, material, offset, quad, ModelQuadFacing.NEG_Y, true);
                }
            }
            //渲染底面（与流动方向相同的面）
            if (flowsUp ? hasSideUp : hasSideDown) {
                float minU = sprites[0].method_4594();
                float maxU = sprites[0].method_4577();
                float minV = sprites[0].method_4593();
                float maxV = sprites[0].method_4575();

                quad.setSprite(sprites[0]);
                if (flowsUp) {
                    setVertex(quad, 3, 1.0F, 1 - yOffset, 0.0F, minU, maxV);
                    setVertex(quad, 2, 1.0F, 1 - yOffset, 1.0F, minU, minV);
                    setVertex(quad, 1, 0.0F, 1 - yOffset, 1.0F, maxU, minV);
                    setVertex(quad, 0, 0.0F, 1 - yOffset, 0.0F, maxU, maxV);
                } else {
                    setVertex(quad, 0, 0.0F, yOffset, 1.0F, minU, maxV);
                    setVertex(quad, 1, 0.0F, yOffset, 0.0F, minU, minV);
                    setVertex(quad, 2, 1.0F, yOffset, 0.0F, maxU, minV);
                    setVertex(quad, 3, 1.0F, yOffset, 1.0F, maxU, maxV);
                }
                this.updateQuad(quad, world, pos, lighter, flowsUp ? class_2350.field_11036 : class_2350.field_11033, 1.0F, colorProvider, fluidState);
                this.writeQuad(meshBuilder, material, offset, quad, flowsUp ? ModelQuadFacing.POS_Y : ModelQuadFacing.NEG_Y, false);
            }

            quad.setFlags(6);

            //渲染侧面
            for (class_2350 direction : class_2350.class_2353.field_11062) {
                float height1;
                float height2;
                float x1, x2, z1, z2;
                boolean shouldSideRender;
                switch (direction) {
                    case field_11043:
                        height1 = cornerHeightNW;
                        height2 = cornerHeightNE;
                        x1 = 0.0F;
                        x2 = 0.0F + 1.0F;
                        z1 = 0.0F + 0.001F;
                        z2 = 0.0F + 0.001F;
                        shouldSideRender = hasSideN;
                        break;
                    case field_11035:
                        height1 = cornerHeightSE;
                        height2 = cornerHeightSW;
                        x1 = 0.0F + 1.0F;
                        x2 = 0.0F;
                        z1 = 0.0F + 1.0F - 0.001F;
                        z2 = 0.0F + 1.0F - 0.001F;
                        shouldSideRender = hasSideS;
                        break;
                    case field_11039:
                        height1 = cornerHeightSW;
                        height2 = cornerHeightNW;
                        x1 = 0.0F + 0.001F;
                        x2 = 0.0F + 0.001F;
                        z1 = 0.0F + 1.0F;
                        z2 = 0.0F;
                        shouldSideRender = hasSideW;
                        break;
                    default:
                        height1 = cornerHeightNE;
                        height2 = cornerHeightSE;
                        x1 = 0.0F + 1.0F - 0.001F;
                        x2 = 0.0F + 1.0F - 0.001F;
                        z1 = 0.0F;
                        z2 = 0.0F + 1.0F;
                        shouldSideRender = hasSideE;
                }

                if (shouldSideRender && !isSideCovered(world, pos, direction, Math.max(height1, height2), world.method_8320(pos.method_10093(direction)), flowsUp)) {
                    class_2338 blockPos = pos.method_10093(direction);
                    class_1058 sprite = sprites[1];
                    boolean isOverlay = false;
                    if (sprites.length > 2) {
                        class_2248 block = world.method_8320(blockPos).method_26204();
                        if (FluidRenderHandlerRegistry.INSTANCE.isBlockTransparent(block)) {
                            sprite = sprites[2];
                            isOverlay = true;
                        }
                    }

                    float u1 = sprite.method_4580(0.0);
                    float u2 = sprite.method_4580(8.0);
                    float v1 = sprite.method_4570((1.0F - height1) * 16.0F * 0.5F);
                    float v2 = sprite.method_4570((1.0F - height2) * 16.0F * 0.5F);
                    float v3 = sprite.method_4570(8.0);

                    quad.setSprite(sprite);

                    if (flowsUp) {
//                        setVertex(quad, 0, x2, Math.abs(1 - height2), z2, u2, v2);
//                        setVertex(quad, 1, x2, Math.abs(1 - yOffset), z2, u2, v3);
//                        setVertex(quad, 2, x1, Math.abs(1 - yOffset), z1, u1, v3);
//                        setVertex(quad, 3, x1, Math.abs(1 - height1), z1, u1, v1);
                        setVertex(quad, 0, x2, 1 - yOffset, z2, u2, v3);
                        setVertex(quad, 1, x1, 1 - yOffset, z1, u1, v3);
                        setVertex(quad, 2, x1, 1 - height1, z1, u1, v1);
                        setVertex(quad, 3, x2, 1 - height2, z2, u2, v2);
                    } else {
                        setVertex(quad, 0, x2, height2, z2, u2, v2);
                        setVertex(quad, 1, x2, yOffset, z2, u2, v3);
                        setVertex(quad, 2, x1, yOffset, z1, u1, v3);
                        setVertex(quad, 3, x1, height1, z1, u1, v1);
                    }

                    float br = direction.method_10166() == class_2350.class_2351.field_11051 ? 0.8F : 0.6F;

                    final class_2350 cullingDir = flowsUp ? direction.method_10153() : direction;
                    final ModelQuadFacing facing = ModelQuadFacing.fromDirection(cullingDir);

                    this.updateQuad(quad, world, pos, lighter, cullingDir, br, colorProvider, fluidState);
                    this.writeQuad(meshBuilder, material, offset, quad, facing, false);
                    if (!isOverlay) {
                        this.writeQuad(meshBuilder, material, offset, quad, facing.getOpposite(), true);
                    }
                }
            }
        }
        
        ci.cancel();
    }

    @Unique
    private static boolean isSameFluid(class_3610 a, class_3610 b) {
        return b.method_15772().method_15780(a.method_15772());
    }

    @Unique
    private static boolean isSideCovered(class_1922 world, class_2350 direction, float height, class_2338 pos, class_2680 state, boolean flowsUp) {
        if (state.method_26225()) {
            class_265 voxelShape = class_259.method_1081(0.0, flowsUp ? (1.0 - height) : 0.0, 0.0, 1.0, flowsUp ? 1.0 : height, 1.0);
            class_265 voxelShape2 = state.method_26201(world, pos);
            return class_259.method_1083(voxelShape, voxelShape2, direction);
        } else {
            return false;
        }
    }

    @Unique
    private static boolean isSideCovered(class_1922 world, class_2338 pos, class_2350 direction, float maxDeviation, class_2680 state, boolean flowsUp) {
        return isSideCovered(world, direction, maxDeviation, pos.method_10093(direction), state, flowsUp);
    }

    @Unique
    private static boolean isOppositeSideCovered(class_1922 world, class_2338 pos, class_2680 state, class_2350 direction, boolean flowsUp) {
        return isSideCovered(world, direction.method_10153(), 1.0F, pos, state, flowsUp);
    }

    @Unique
    private static boolean shouldRenderSide(
            class_1920 world, class_2338 pos, class_3610 fluidState, class_2680 blockState, class_2350 direction, class_3610 neighborFluidState, boolean flowsUp
    ) {
        return !isOppositeSideCovered(world, pos, blockState, direction, flowsUp) && !isSameFluid(fluidState, neighborFluidState);
    }

    @Unique
    private static float getFluidHeight(class_1920 world, class_3611 fluid, class_2338 sidePos, class_2680 sideState, class_3610 sideFluidState, boolean flowsUp) {
        if (fluid.method_15780(sideFluidState.method_15772())) {
            class_2680 blockState2 = world.method_8320(flowsUp ? sidePos.method_10074() : sidePos.method_10084());
            return fluid.method_15780(blockState2.method_26227().method_15772()) ? 1.0F : sideFluidState.method_20785();
        } else {
            return !sideState.method_51367() ? 0.0F : -1.0F;
        }
    }

    @Unique
    private static float getFluidHeight(class_1920 world, class_3611 fluid, class_2338 pos, boolean flowsUp) {
        class_2680 blockState = world.method_8320(pos);
        return getFluidHeight(world, fluid, pos, blockState, blockState.method_26227(), flowsUp);
    }

    @Unique
    private static float calculateFluidHeight(class_1920 world, class_3611 fluid, float originHeight, float northSouthHeight, float eastWestHeight, class_2338 pos, boolean flowsUp) {
        if (!(eastWestHeight >= 1.0F) && !(northSouthHeight >= 1.0F)) {
            float[] fs = new float[2];
            if (eastWestHeight > 0.0F || northSouthHeight > 0.0F) {
                float f = getFluidHeight(world, fluid, pos, flowsUp);
                if (f >= 1.0F) {
                    return 1.0F;
                }

                addHeight(fs, f);
            }

            addHeight(fs, originHeight);
            addHeight(fs, eastWestHeight);
            addHeight(fs, northSouthHeight);
            return fs[0] / fs[1];
        } else {
            return 1.0F;
        }
    }

    @Unique
    private static void addHeight(float[] weightedAverageHeight, float height) {
        if (height >= 0.8F) {
            weightedAverageHeight[0] += height * 10.0F;
            weightedAverageHeight[1] += 10.0F;
        } else if (height >= 0.0F) {
            weightedAverageHeight[0] += height;
            weightedAverageHeight[1]++;
        }
    }
}
