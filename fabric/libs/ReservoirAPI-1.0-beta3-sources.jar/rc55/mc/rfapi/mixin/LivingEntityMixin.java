package rc55.mc.rfapi.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import rc55.mc.rfapi.fluid.FluidTags;

@Mixin(class_1309.class)
public abstract class LivingEntityMixin extends class_1297 {
    protected LivingEntityMixin(class_1299<?> type, class_1937 world) {
        super(type, world);
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isInLava()Z"),
            slice = @Slice(
                    from = @At(value = "INVOKE_STRING", target = "Lnet/minecraft/util/profiler/Profiler;push(Ljava/lang/String;)V", args = "ldc=jump"),
                    to = @At(value = "INVOKE_STRING", target = "Lnet/minecraft/util/profiler/Profiler;push(Ljava/lang/String;)V", args = "ldc=travel")
            ),
            method = "tickMovement"
    )
    public boolean rfapi$modifyLavaPhysicsFluidCheck(class_1309 instance) {
        return instance.method_5861(FluidTags.DUMMY_LAVA_PHYSICS_TAG) > 0.;
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isTouchingWater()Z"),
            slice = @Slice(
                    from = @At(value = "INVOKE_STRING", target = "Lnet/minecraft/util/profiler/Profiler;push(Ljava/lang/String;)V", args = "ldc=jump"),
                    to = @At(value = "INVOKE_STRING", target = "Lnet/minecraft/util/profiler/Profiler;push(Ljava/lang/String;)V", args = "ldc=travel")
            ),
            method = "tickMovement"
    )
    public boolean rfapi$modifyWaterPhysicsFluidCheck(class_1309 instance) {
        return instance.method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > 0.;
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isInLava()Z"),
            method = "travel"
    )
    public boolean rfapi$hookPhysicsInLavaLikeFluid(class_1309 instance) {
        return instance.method_5861(FluidTags.DUMMY_LAVA_PHYSICS_TAG) > 0.;
    }

    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isTouchingWater()Z"),
            method = {"travel", "fall"}
    )
    public boolean rfapi$hookPhysicsInWaterLikeFluid(class_1309 instance) {
        return instance.method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > 0.;
    }

    @SuppressWarnings("rawtypes")
    @ModifyArg(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/LivingEntity;isSubmergedIn(Lnet/minecraft/registry/tag/TagKey;)Z"),
            method = "baseTick"
    )
    public class_6862 rfapi$modifyEntityBreathing(class_6862 par1) {
        return FluidTags.DUMMY_UNBREATHABLE_TAG;
    }
}
