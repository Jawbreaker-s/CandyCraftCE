package rc55.mc.rfapi.mixin;

import net.minecraft.class_2818;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import rc55.mc.rfapi.event.EndServerChunkTickEvent;

@Mixin(class_3218.class)
public abstract class ServerWorldMixin {
    @Inject(
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/util/profiler/Profiler;pop()V",
                    ordinal = 1,
                    shift = At.Shift.BEFORE
            ),
            method = "tickChunk"
    )
    public void rfapi$fireChunkTickEvent(class_2818 chunk, int randomTickSpeed, CallbackInfo ci) {
        EndServerChunkTickEvent.EVENT.invoker().onChunkTickEnd((class_3218)(Object) this, chunk, randomTickSpeed);
    }
}
