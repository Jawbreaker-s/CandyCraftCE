package rc55.mc.rfapi.mixin;

import net.minecraft.class_1690;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import rc55.mc.rfapi.fluid.FluidHelper;

@Mixin(class_1690.class)
public abstract class BoatEntityMixin {
    // Make boats float in water-like fluids
    @Redirect(
            at = @At(value = "INVOKE", target = "Lnet/minecraft/fluid/FluidState;isIn(Lnet/minecraft/registry/tag/TagKey;)Z"),
            method = {"checkBoatInWater", "getWaterHeightBelow", "getUnderWaterLocation"}
    )
    public boolean rfapi$hookInWaterCheck(class_3610 state, class_6862<class_3611> tag) {
        return FluidHelper.checkEntityMoveAction(state.method_15772(), tag);
    }
}
