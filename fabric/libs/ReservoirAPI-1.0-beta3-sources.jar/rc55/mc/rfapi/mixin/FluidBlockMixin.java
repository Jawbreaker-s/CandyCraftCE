package rc55.mc.rfapi.mixin;

import net.minecraft.class_1297;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rc55.mc.rfapi.RFApiConfigs;
import rc55.mc.rfapi.event.EntityTouchFluidEvent;
import rc55.mc.rfapi.event.FluidBlockNeighborUpdateEvent;
import rc55.mc.rfapi.fluid.reaction.FluidReactionType;
import rc55.mc.rfapi.fluid.reaction.IFluidReaction;

@Mixin(class_2404.class)
public abstract class FluidBlockMixin extends class_2248 {
    private FluidBlockMixin(class_2251 settings) {
        super(settings);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void method_9548(class_2680 state, class_1937 world, class_2338 pos, class_1297 entity) {
        EntityTouchFluidEvent.EVENT.invoker().onEntityCollision(state, world, pos, entity);
        super.method_9548(state, world, pos, entity);
    }

    @Inject(at = @At("HEAD"), method = "receiveNeighborFluids", cancellable = true)
    public void rfapi$hookFluidReaction(class_1937 world, class_2338 pos, class_2680 state, CallbackInfoReturnable<Boolean> cir) {
        if (IFluidReaction.triggerReaction(FluidReactionType.SIMPLE, world, pos, pos) != null) {
            cir.setReturnValue(false);
        } else if (IFluidReaction.triggerReaction(FluidReactionType.FLOWABLE, world, pos, pos) != null) {
            cir.setReturnValue(false);
        } else if (RFApiConfigs.getInstance().blockVanillaFluidReactions) {
            // Cancel this so vanilla fluid reactions won't happen
            cir.setReturnValue(true);
        }
    }

    @Inject(at = @At("HEAD"), method = "neighborUpdate", cancellable = true)
    public void rfapi$triggerFluidNeighborUpdateEvent(
            class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify, CallbackInfo ci
    ) {
        if (FluidBlockNeighborUpdateEvent.EVENT.invoker().onNeighborUpdate(
                (class_2404)(Object) this, state, world, pos, sourceBlock, sourcePos, notify
        )) {
            ci.cancel();
        }
    }
}
