package rc55.mc.rfapi.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1920;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4588;
import net.minecraft.class_761;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

/**
 * Renderer for RFAPI fluids
 * Modified from Forge fluid renderer
 * @see FluidRenderRegistry
 */
@SuppressWarnings("BooleanMethodIsAlwaysInverted")
@Environment(EnvType.CLIENT)
public class ExtendedFluidRenderHandler implements FluidRenderHandler {
    protected final boolean flowsUp;

    protected final class_2960 stillTexture;
    protected final class_2960 flowingTexture;
    protected final class_2960 overlayTexture;

    protected final class_1058[] sprites;

    /**
     * Creates a fluid renderer with an overlay texture
     * @param flowsUp If the fluid flows upwards
     * @param stillTexture Texture for still fluid
     * @param flowingTexture Texture for flowing/falling fluid
     * @param overlayTexture Texture behind {@linkplain FluidRenderHandlerRegistry#setBlockTransparency registered transparent blocks}(e.g. glass, leaves)
     */
    public ExtendedFluidRenderHandler(boolean flowsUp, class_2960 stillTexture, class_2960 flowingTexture, @Nullable class_2960 overlayTexture) {
        this.stillTexture = Objects.requireNonNull(stillTexture, "Still texture may not be null");
        this.flowingTexture = Objects.requireNonNull(flowingTexture, "Flowing texture may not be null");
        this.overlayTexture = overlayTexture;
        this.sprites = new class_1058[overlayTexture == null ? 2 : 3];
        this.flowsUp = flowsUp;
    }

    /**
     * Creates a fluid renderer without overlay textures
     * @param flowsUp If the fluid flows upwards
     * @param stillTexture Texture for still fluid
     * @param flowingTexture Texture for flowing/falling fluid
     */
    public ExtendedFluidRenderHandler(boolean flowsUp, class_2960 stillTexture, class_2960 flowingTexture) {
        this(flowsUp, stillTexture, flowingTexture, null);
    }

    /**
     * Creates a fluid renderer with water texture
     * @param flowsUp If the fluid flows upwards
     */
    public static ExtendedFluidRenderHandler coloredWater(boolean flowsUp) {
        return new ExtendedFluidRenderHandler(flowsUp, SimpleFluidRenderHandler.WATER_STILL, SimpleFluidRenderHandler.WATER_FLOWING, SimpleFluidRenderHandler.WATER_OVERLAY);
    }

    @Override
    public class_1058[] getFluidSprites(@Nullable class_1920 view, @Nullable class_2338 pos, class_3610 state) {
        return this.sprites;
    }

    @Override
    public void reloadTextures(class_1059 textureAtlas) {
        this.sprites[0] = textureAtlas.method_4608(this.stillTexture);
        this.sprites[1] = textureAtlas.method_4608(this.flowingTexture);

        if (this.overlayTexture != null) {
            this.sprites[2] = textureAtlas.method_4608(this.overlayTexture);
        }
    }

    @Override
    public int getFluidColor(@Nullable class_1920 world, @Nullable class_2338 pos, class_3610 state) {
        return state.method_15772().getSettings().getColor(world, pos);
    }

    @Override
    public void renderFluid(class_2338 pos, class_1920 world, class_4588 vertexConsumer, class_2680 blockState, class_3610 fluidState) {
        this.render(world, pos, vertexConsumer, blockState, fluidState);
    }

    public void render(class_1920 world, class_2338 pos, class_4588 vertexConsumer, class_2680 blockState, class_3610 fluidState) {
        //颜色
        final int color = this.getFluidColor(world, pos, fluidState);
        final float colorR = (color >> 16 & 0xFF) / 255.0f;
        final float colorG = (color >> 8 & 0xFF) / 255.0f;
        final float colorB = (color & 0xFF) / 255.0f;
        //计算要渲染的面
        class_2680 blockStateDown = world.method_8320(pos.method_10093(class_2350.field_11033));
        class_3610 fluidStateDown = blockStateDown.method_26227();
        class_2680 blockStateUp = world.method_8320(pos.method_10093(class_2350.field_11036));
        class_3610 fluidStateUp = blockStateUp.method_26227();
        class_2680 blockStateNorth = world.method_8320(pos.method_10093(class_2350.field_11043));
        class_3610 fluidStateNorth = blockStateNorth.method_26227();
        class_2680 blockStateSouth = world.method_8320(pos.method_10093(class_2350.field_11035));
        class_3610 fluidStateSouth = blockStateSouth.method_26227();
        class_2680 blockStateWest = world.method_8320(pos.method_10093(class_2350.field_11039));
        class_3610 fluidStateWest = blockStateWest.method_26227();
        class_2680 blockStateEast = world.method_8320(pos.method_10093(class_2350.field_11034));
        class_3610 fluidStateEast = blockStateEast.method_26227();
        boolean hasSideUp, hasSideDown;
        if (flowsUp) {
            hasSideDown = !isSameFluid(fluidState, fluidStateDown);
            hasSideUp = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11036, fluidStateUp)
                    && !isSideCovered(world, pos, class_2350.field_11036, 0.8888889f, blockStateUp);
        } else {
            hasSideDown = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11033, fluidStateDown)
                    && !isSideCovered(world, pos, class_2350.field_11033, 0.8888889f, blockStateDown);
            hasSideUp = !isSameFluid(fluidState, fluidStateUp);
        }
        boolean hasSideN = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11043, fluidStateNorth);
        boolean hasSideS = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11035, fluidStateSouth);
        boolean hasSideW = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11039, fluidStateWest);
        boolean hasSideE = shouldRenderSide(world, pos, fluidState, blockState, class_2350.field_11034, fluidStateEast);
        //渲染
        if (hasSideDown || hasSideUp || hasSideE || hasSideW || hasSideN || hasSideS) {
            //阴影强度
            final float shaderDown = world.method_24852(class_2350.field_11033, true);
            final float shaderUp = world.method_24852(class_2350.field_11036, true);
            final float shaderN = world.method_24852(class_2350.field_11043, true);
            final float shaderW = world.method_24852(class_2350.field_11039, true);
            //流体
            final class_3611 fluid = fluidState.method_15772();
            //渲染高度
            final float thisHeight = this.getFluidHeight(world, fluid, pos, blockState, fluidState);
            //计算方块顶点位置
            float cornerHeightNE, cornerHeightNW, cornerHeightSE, cornerHeightSW;
            if (thisHeight >= 1.0F) {
                //完整方块
                cornerHeightNE = 1.0F;
                cornerHeightNW = 1.0F;
                cornerHeightSE = 1.0F;
                cornerHeightSW = 1.0F;
            } else {
                //非完整方块
                float heightN = this.getFluidHeight(world, fluid, pos.method_10095(), blockStateNorth, fluidStateNorth);
                float heightS = this.getFluidHeight(world, fluid, pos.method_10072(), blockStateSouth, fluidStateSouth);
                float heightE = this.getFluidHeight(world, fluid, pos.method_10078(), blockStateEast, fluidStateEast);
                float heightW = this.getFluidHeight(world, fluid, pos.method_10067(), blockStateWest, fluidStateWest);
                cornerHeightNE = this.calculateFluidHeight(world, fluid, thisHeight, heightN, heightE, pos.method_10093(class_2350.field_11043).method_10093(class_2350.field_11034));
                cornerHeightNW = this.calculateFluidHeight(world, fluid, thisHeight, heightN, heightW, pos.method_10093(class_2350.field_11043).method_10093(class_2350.field_11039));
                cornerHeightSE = this.calculateFluidHeight(world, fluid, thisHeight, heightS, heightE, pos.method_10093(class_2350.field_11035).method_10093(class_2350.field_11034));
                cornerHeightSW = this.calculateFluidHeight(world, fluid, thisHeight, heightS, heightW, pos.method_10093(class_2350.field_11035).method_10093(class_2350.field_11039));
            }
            //坐标值
            final double chunkX = pos.method_10263() & 15;
            final double chunkY = pos.method_10264() & 15;
            final double chunkZ = pos.method_10260() & 15;
            float yOffset = (flowsUp ? hasSideUp : hasSideDown) ? 0.001F : 0.0F;
            boolean shouldRenderTop;
            if (flowsUp) {
                shouldRenderTop = hasSideDown && !isSideCovered(world, pos, class_2350.field_11033, Math.min(Math.min(cornerHeightNW, cornerHeightSW), Math.min(cornerHeightSE, cornerHeightNE)), blockStateDown);
            } else {
                shouldRenderTop = hasSideUp && !isSideCovered(world, pos, class_2350.field_11036, Math.min(Math.min(cornerHeightNW, cornerHeightSW), Math.min(cornerHeightSE, cornerHeightNE)), blockStateUp);
            }
            //渲染顶面（与流动方向相反的面）
            if (shouldRenderTop) {
                cornerHeightNW -= 0.001F;
                cornerHeightSW -= 0.001F;
                cornerHeightSE -= 0.001F;
                cornerHeightNE -= 0.001F;
                //流动性
                class_243 flowVec = fluidState.method_15758(world, pos);
                //获取贴图帧位置
                float u1, u2, u3, u4, v1, v2, v3, v4;
                if (flowVec.field_1352 == 0.0 && flowVec.field_1350 == 0.0) {
                    //静止
                    class_1058 sprite = this.sprites[0];
                    u1 = sprite.method_4580(0.0);
                    v1 = sprite.method_4570(0.0);
                    u2 = u1;
                    v2 = sprite.method_4570(16.0);
                    u3 = sprite.method_4580(16.0);
                    v3 = v2;
                    u4 = u3;
                    v4 = v1;
                } else {
                    //流动
                    class_1058 sprite = this.sprites[1];
                    float ah = (float) class_3532.method_15349(flowVec.field_1350, flowVec.field_1352) - (float) (Math.PI / 2);
                    float ai = class_3532.method_15374(ah) * 0.25F;
                    float aj = class_3532.method_15362(ah) * 0.25F;
                    u1 = sprite.method_4580(8.0F + (-aj - ai) * 16.0F);
                    v1 = sprite.method_4570(8.0F + (-aj + ai) * 16.0F);
                    u2 = sprite.method_4580(8.0F + (-aj + ai) * 16.0F);
                    v2 = sprite.method_4570(8.0F + (aj + ai) * 16.0F);
                    u3 = sprite.method_4580(8.0F + (aj + ai) * 16.0F);
                    v3 = sprite.method_4570(8.0F + (aj - ai) * 16.0F);
                    u4 = sprite.method_4580(8.0F + (aj - ai) * 16.0F);
                    v4 = sprite.method_4570(8.0F + (-aj - ai) * 16.0F);
                }
                //计算材质顶点位置
                final float averageU = (u1 + u2 + u3 + u4) / 4.0F;
                final float averageV = (v1 + v2 + v3 + v4) / 4.0F;
                final float frameDelta = this.sprites[0].method_23842();
                u1 = class_3532.method_16439(frameDelta, u1, averageU);
                u2 = class_3532.method_16439(frameDelta, u2, averageU);
                u3 = class_3532.method_16439(frameDelta, u3, averageU);
                u4 = class_3532.method_16439(frameDelta, u4, averageU);
                v1 = class_3532.method_16439(frameDelta, v1, averageV);
                v2 = class_3532.method_16439(frameDelta, v2, averageV);
                v3 = class_3532.method_16439(frameDelta, v3, averageV);
                v4 = class_3532.method_16439(frameDelta, v4, averageV);
                //颜色
                int light = this.getLight(world, pos);
                float r = shaderUp * colorR;
                float g = shaderUp * colorG;
                float b = shaderUp * colorB;
                //渲染
                if (flowsUp) {
                    this.vertex(vertexConsumer, chunkX + 1.0, chunkY + 1 - cornerHeightNE, chunkZ + 0.0, r, g, b, u4, v4, light);
                    this.vertex(vertexConsumer, chunkX + 1.0, chunkY + 1 - cornerHeightSE, chunkZ + 1.0, r, g, b, u3, v3, light);
                    this.vertex(vertexConsumer, chunkX + 0.0, chunkY + 1 - cornerHeightSW, chunkZ + 1.0, r, g, b, u2, v2, light);
                    this.vertex(vertexConsumer, chunkX + 0.0, chunkY + 1 - cornerHeightNW, chunkZ + 0.0, r, g, b, u1, v1, light);
                    if (fluidState.method_15756(world, pos.method_10074())) {
                        this.vertex(vertexConsumer, chunkX + 1.0, chunkY + 1 - cornerHeightNE, chunkZ + 0.0, r, g, b, u4, v4, light);
                        this.vertex(vertexConsumer, chunkX + 0.0, chunkY + 1 - cornerHeightNW, chunkZ + 0.0, r, g, b, u1, v1, light);
                        this.vertex(vertexConsumer, chunkX + 0.0, chunkY + 1 - cornerHeightSW, chunkZ + 1.0, r, g, b, u2, v2, light);
                        this.vertex(vertexConsumer, chunkX + 1.0, chunkY + 1 - cornerHeightSE, chunkZ + 1.0, r, g, b, u3, v3, light);
                    }
                } else {
                    this.vertex(vertexConsumer, chunkX + 0.0, chunkY + cornerHeightNW, chunkZ + 0.0, r, g, b, u1, v1, light);
                    this.vertex(vertexConsumer, chunkX + 0.0, chunkY + cornerHeightSW, chunkZ + 1.0, r, g, b, u2, v2, light);
                    this.vertex(vertexConsumer, chunkX + 1.0, chunkY + cornerHeightSE, chunkZ + 1.0, r, g, b, u3, v3, light);
                    this.vertex(vertexConsumer, chunkX + 1.0, chunkY + cornerHeightNE, chunkZ + 0.0, r, g, b, u4, v4, light);
                    if (fluidState.method_15756(world, pos.method_10084())) {
                        this.vertex(vertexConsumer, chunkX + 0.0, chunkY + cornerHeightNW, chunkZ + 0.0, r, g, b, u1, v1, light);
                        this.vertex(vertexConsumer, chunkX + 1.0, chunkY + cornerHeightNE, chunkZ + 0.0, r, g, b, u4, v4, light);
                        this.vertex(vertexConsumer, chunkX + 1.0, chunkY + cornerHeightSE, chunkZ + 1.0, r, g, b, u3, v3, light);
                        this.vertex(vertexConsumer, chunkX + 0.0, chunkY + cornerHeightSW, chunkZ + 1.0, r, g, b, u2, v2, light);
                    }
                }
            }
            //渲染底面（与流动方向相同的面）
            if (this.flowsUp ? hasSideUp : hasSideDown) {
                float minU = this.sprites[0].method_4594();
                float maxU = this.sprites[0].method_4577();
                float minV = this.sprites[0].method_4593();
                float maxV = this.sprites[0].method_4575();
                int light = this.getLight(world, flowsUp ? pos.method_10084() : pos.method_10074());
                float r = shaderDown * colorR;
                float g = shaderDown * colorG;
                float b = shaderDown * colorB;
                if (flowsUp) {
                    this.vertex(vertexConsumer, chunkX + 1.0, chunkY + 1 - yOffset, chunkZ + 1.0, r, g, b, minU, maxV, light);
                    this.vertex(vertexConsumer, chunkX + 1.0, chunkY + 1 - yOffset, chunkZ + 0.0, r, g, b, minU, minV, light);
                    this.vertex(vertexConsumer, chunkX + 0.0, chunkY + 1 - yOffset, chunkZ + 0.0, r, g, b, maxU, minV, light);
                    this.vertex(vertexConsumer, chunkX + 0.0, chunkY + 1 - yOffset, chunkZ + 1.0, r, g, b, maxU, maxV, light);
                } else {
                    this.vertex(vertexConsumer, chunkX + 0.0, chunkY + yOffset, chunkZ + 1.0, r, g, b, minU, maxV, light);
                    this.vertex(vertexConsumer, chunkX + 0.0, chunkY + yOffset, chunkZ + 0.0, r, g, b, minU, minV, light);
                    this.vertex(vertexConsumer, chunkX + 1.0, chunkY + yOffset, chunkZ + 0.0, r, g, b, maxU, minV, light);
                    this.vertex(vertexConsumer, chunkX + 1.0, chunkY + yOffset, chunkZ + 1.0, r, g, b, maxU, maxV, light);
                }
            }
            //渲染侧面
            final int light = this.getLight(world, pos);
            for (class_2350 direction : class_2350.class_2353.field_11062) {
                float height1;
                float height2;
                double x1, x2, z1, z2;
                boolean shouldSideRender;
                switch (direction) {
                    case field_11043:
                        height1 = cornerHeightNW;
                        height2 = cornerHeightNE;
                        x1 = chunkX;
                        x2 = chunkX + 1.0;
                        z1 = chunkZ + 0.001F;
                        z2 = chunkZ + 0.001F;
                        shouldSideRender = hasSideN;
                        break;
                    case field_11035:
                        height1 = cornerHeightSE;
                        height2 = cornerHeightSW;
                        x1 = chunkX + 1.0;
                        x2 = chunkX;
                        z1 = chunkZ + 1.0 - 0.001F;
                        z2 = chunkZ + 1.0 - 0.001F;
                        shouldSideRender = hasSideS;
                        break;
                    case field_11039:
                        height1 = cornerHeightSW;
                        height2 = cornerHeightNW;
                        x1 = chunkX + 0.001F;
                        x2 = chunkX + 0.001F;
                        z1 = chunkZ + 1.0;
                        z2 = chunkZ;
                        shouldSideRender = hasSideW;
                        break;
                    default:
                        height1 = cornerHeightNE;
                        height2 = cornerHeightSE;
                        x1 = chunkX + 1.0 - 0.001F;
                        x2 = chunkX + 1.0 - 0.001F;
                        z1 = chunkZ;
                        z2 = chunkZ + 1.0;
                        shouldSideRender = hasSideE;
                }

                if (shouldSideRender && !isSideCovered(world, pos, direction, Math.max(height1, height2), world.method_8320(pos.method_10093(direction)))) {
                    class_2338 blockPos = pos.method_10093(direction);
                    class_1058 sprite = this.sprites[1];
                    if (this.overlayTexture != null) {
                        class_2248 block = world.method_8320(blockPos).method_26204();
                        if (FluidRenderHandlerRegistry.INSTANCE.isBlockTransparent(block)) {
                            sprite = this.sprites[2];
                        }
                    }

                    float u1 = sprite.method_4580(0.0);
                    float u2 = sprite.method_4580(8.0);
                    float v1 = sprite.method_4570((1.0F - height1) * 16.0F * 0.5F);
                    float v2 = sprite.method_4570((1.0F - height2) * 16.0F * 0.5F);
                    float v3 = sprite.method_4570(8.0);
                    float shaderSide = direction.method_10166() == class_2350.class_2351.field_11051 ? shaderN : shaderW;
                    float r = shaderUp * shaderSide * colorR;
                    float g = shaderUp * shaderSide * colorG;
                    float b = shaderUp * shaderSide * colorB;
                    if (flowsUp) {
                        this.vertex(vertexConsumer, x1, chunkY + 1 - height1, z1, r, g, b, u1, v1, light);
                        this.vertex(vertexConsumer, x2, chunkY + 1 - height2, z2, r, g, b, u2, v2, light);
                        this.vertex(vertexConsumer, x2, chunkY + 1 - yOffset, z2, r, g, b, u2, v3, light);
                        this.vertex(vertexConsumer, x1, chunkY + 1 - yOffset, z1, r, g, b, u1, v3, light);
                        if (sprite.method_45852() != this.overlayTexture) {
                            this.vertex(vertexConsumer, x1, chunkY + 1 - yOffset, z1, r, g, b, u1, v3, light);
                            this.vertex(vertexConsumer, x2, chunkY + 1 - yOffset, z2, r, g, b, u2, v3, light);
                            this.vertex(vertexConsumer, x2, chunkY + 1 - height2, z2, r, g, b, u2, v2, light);
                            this.vertex(vertexConsumer, x1, chunkY + 1 - height1, z1, r, g, b, u1, v1, light);
                        }
                    } else {
                        this.vertex(vertexConsumer, x1, chunkY + height1, z1, r, g, b, u1, v1, light);
                        this.vertex(vertexConsumer, x2, chunkY + height2, z2, r, g, b, u2, v2, light);
                        this.vertex(vertexConsumer, x2, chunkY + yOffset, z2, r, g, b, u2, v3, light);
                        this.vertex(vertexConsumer, x1, chunkY + yOffset, z1, r, g, b, u1, v3, light);
                        if (sprite.method_45852() != this.overlayTexture) {
                            this.vertex(vertexConsumer, x1, chunkY + yOffset, z1, r, g, b, u1, v3, light);
                            this.vertex(vertexConsumer, x2, chunkY + yOffset, z2, r, g, b, u2, v3, light);
                            this.vertex(vertexConsumer, x2, chunkY + height2, z2, r, g, b, u2, v2, light);
                            this.vertex(vertexConsumer, x1, chunkY + height1, z1, r, g, b, u1, v1, light);
                        }
                    }
                }
            }
        }
    }

    protected float calculateFluidHeight(class_1920 world, class_3611 fluid, float originHeight, float northSouthHeight, float eastWestHeight, class_2338 pos) {
        if (!(eastWestHeight >= 1.0F) && !(northSouthHeight >= 1.0F)) {
            float[] fs = new float[2];
            if (eastWestHeight > 0.0F || northSouthHeight > 0.0F) {
                float f = this.getFluidHeight(world, fluid, pos);
                if (f >= 1.0F) {
                    return 1.0F;
                }

                this.addHeight(fs, f);
            }

            this.addHeight(fs, originHeight);
            this.addHeight(fs, eastWestHeight);
            this.addHeight(fs, northSouthHeight);
            return fs[0] / fs[1];
        } else {
            return 1.0F;
        }
    }

    protected void addHeight(float[] weightedAverageHeight, float height) {
        if (height >= 0.8F) {
            weightedAverageHeight[0] += height * 10.0F;
            weightedAverageHeight[1] += 10.0F;
        } else if (height >= 0.0F) {
            weightedAverageHeight[0] += height;
            weightedAverageHeight[1]++;
        }
    }

    protected float getFluidHeight(class_1920 world, class_3611 fluid, class_2338 pos) {
        class_2680 blockState = world.method_8320(pos);
        return this.getFluidHeight(world, fluid, pos, blockState, blockState.method_26227());
    }

    protected float getFluidHeight(class_1920 world, class_3611 fluid, class_2338 sidePos, class_2680 sideState, class_3610 sideFluidState) {
        if (fluid.method_15780(sideFluidState.method_15772())) {
            class_2680 blockState2 = world.method_8320(this.flowsUp ? sidePos.method_10074() : sidePos.method_10084());
            return fluid.method_15780(blockState2.method_26227().method_15772()) ? 1.0F : sideFluidState.method_20785();
        } else {
            return !sideState.method_51367() ? 0.0F : -1.0F;
        }
    }

    protected void vertex(class_4588 vertexConsumer, double x, double y, double z, float red, float green, float blue, float u, float v, int light) {
        vertexConsumer.method_22912(x, y, z).method_22915(red, green, blue, 1.0F).method_22913(u, v).method_22916(light).method_22914(0.0F, 1.0F, 0.0F).method_1344();
    }

    protected int getLight(class_1920 world, class_2338 pos) {
        int i = class_761.method_23794(world, pos);
        int j = class_761.method_23794(world, pos.method_10084());
        int k = i & 255;
        int l = j & 255;
        int m = i >> 16 & 255;
        int n = j >> 16 & 255;
        return (Math.max(k, l)) | (Math.max(m, n)) << 16;
    }

    protected static boolean isSameFluid(class_3610 a, class_3610 b) {
        return b.method_15772().method_15780(a.method_15772());
    }

    protected boolean isSideCovered(class_1922 world, class_2350 direction, float height, class_2338 pos, class_2680 state) {
        if (state.method_26225()) {
            class_265 voxelShape = class_259.method_1081(0.0, this.flowsUp ? (1.0 - height) : 0.0, 0.0, 1.0, this.flowsUp ? 1.0 : height, 1.0);
            class_265 voxelShape2 = state.method_26201(world, pos);
            return class_259.method_1083(voxelShape, voxelShape2, direction);
        } else {
            return false;
        }
    }

    protected boolean isSideCovered(class_1922 world, class_2338 pos, class_2350 direction, float maxDeviation, class_2680 state) {
        return isSideCovered(world, direction, maxDeviation, pos.method_10093(direction), state);
    }

    protected boolean isOppositeSideCovered(class_1922 world, class_2338 pos, class_2680 state, class_2350 direction) {
        return isSideCovered(world, direction.method_10153(), 1.0F, pos, state);
    }

    protected boolean shouldRenderSide(
            class_1920 world, class_2338 pos, class_3610 fluidState, class_2680 blockState, class_2350 direction, class_3610 neighborFluidState
    ) {
        return !isOppositeSideCovered(world, pos, blockState, direction) && !isSameFluid(fluidState, neighborFluidState);
    }
}
