package rc55.mc.rfapi.fluid;

import com.google.common.base.Suppliers;
import net.fabricmc.fabric.api.lookup.v1.custom.ApiProviderMap;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributeHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_1163;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1920;
import net.minecraft.class_1928;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2394;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3616;
import net.minecraft.class_3620;
import net.minecraft.class_3621;
import net.minecraft.class_4538;
import net.minecraft.fluid.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.RFApiMain;

import java.util.Optional;
import java.util.function.*;

/**
 * Determines properties for a certain fluid
 * Note that the flowing and the still factor shares the same FluidSettings
 * Use {@link Builder} to create an instance
 */
@SuppressWarnings({"UnstableApiUsage", "OptionalUsedAsFieldOrParameterType"})
public class FluidSettings implements FluidVariantAttributeHandler {
    private final Supplier<class_2248> fluidBlockSupplier;
    private final Supplier<@Nullable class_1792> bucketItemSupplier;
    private final ToIntFunction<class_4538> flowSpeedGetter, tickRateGetter, levelDecrPerBlockGetter;
    private final Optional<class_3414> bucketFillSound, bucketEmptySound;
    private final @Nullable class_2394 drippingParticle;
    private final boolean setsFire, randomTick, flowsUp, retainsAir;
    private final ToIntFunction<class_2680> luminanceGetter;
    private final ColorSettings color;
    private final int temperature;
    private final Predicate<class_1937> infinite;
    private final EntityMovementType movementType;

    private FluidSettings(
            Supplier<class_2248> fluidBlockSupplier,
            Supplier<@Nullable class_1792> bucketItemSupplier,
            ToIntFunction<class_4538> flowSpeedGetter,
            ToIntFunction<class_4538> tickRateGetter,
            ToIntFunction<class_4538> levelDecrPerBlockGetter,
            Optional<class_3414> bucketEmptySound,
            Optional<class_3414> bucketFillSound,
            @Nullable class_2394 drippingParticle,
            boolean setsFire,
            boolean randomTick,
            boolean flowsUp,
            ToIntFunction<class_2680> luminanceGetter,
            ColorSettings color,
            Predicate<class_1937> infinite,
            int temperature,
            boolean retainsAir,
            EntityMovementType movementType
    ) {
        this.fluidBlockSupplier = fluidBlockSupplier;
        this.bucketItemSupplier = bucketItemSupplier;
        this.flowSpeedGetter = flowSpeedGetter;
        this.tickRateGetter = tickRateGetter;
        this.levelDecrPerBlockGetter = levelDecrPerBlockGetter;
        this.bucketEmptySound = bucketEmptySound;
        this.bucketFillSound = bucketFillSound;
        this.drippingParticle = drippingParticle;
        this.setsFire = setsFire;
        this.randomTick = randomTick;
        this.flowsUp = flowsUp;
        this.luminanceGetter = luminanceGetter;
        this.color = color;
        this.infinite = infinite;
        this.temperature = temperature;
        this.retainsAir = retainsAir;
        this.movementType = movementType;
    }

    private static FluidSettings fromFabricVariant(FluidVariant fluidVariant) {
        final class_3611 fluid = fluidVariant.getFluid();
        final FluidVariantAttributeHandler fabricAttribute = FluidVariantAttributes.getHandler(fluid);
        final Builder builder;
        if (fluid.method_15791(class_3486.field_15517) || fluid instanceof class_3621) {
            builder = waterLike();
        } else if (fluid.method_15791(class_3486.field_15518) || fluid instanceof class_3616) {
            builder = lavaLike();
        } else {
            builder = builder();
        }
        if (fabricAttribute == null) {
            RFApiMain.LOGGER.error("Fluid {} has neither fabric/rfapi settings(aka property) defined!", FluidRegistry.getId(fluid));
            return builder.bucket(fluid::method_15774)
                    .block(() -> fluid.method_15785().method_15759().method_26204())
                    .build();
        }
        if (fabricAttribute.isLighterThanAir(fluidVariant)) {
            builder.flowsUp();
        }
        return builder.pourSound(fabricAttribute.getEmptySound(fluidVariant))
                .pickUpSound(fabricAttribute.getEmptySound(fluidVariant))
                .luminance(fabricAttribute.getLuminance(fluidVariant))
                .temperature(fabricAttribute.getTemperature(fluidVariant))
                .flowSpeed(fabricAttribute.getViscosity(fluidVariant, null) / FluidConstants.VISCOSITY_RATIO)
                .bucket(fluid::method_15774)
                .block(() -> fluid.method_15785().method_15759().method_26204())
                .build();
    }

    public static final int WATER_TEMPERATURE = FluidConstants.WATER_TEMPERATURE, LAVA_TEMPERATURE = FluidConstants.LAVA_TEMPERATURE;

    public static final class_2350[] FLOW_DIRECTIONS = {class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, class_2350.field_11033};
    public static final class_2350[] AIR_FLOW_DIRECTIONS = {class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034, class_2350.field_11036};

    protected static final ApiProviderMap<class_3611, FluidSettings> REGISTRY = ApiProviderMap.create();

    /**
     * Creates a builder for FluidSettings
     * @return The {@link Builder}
     */
    public static Builder builder() {
        return new Builder();
    }

    /**
     * Creates a FluidSettings builder which by default acts like vanilla water
     */
    public static Builder waterLike() {
        return builder().temperature(WATER_TEMPERATURE)
                .particle(class_2398.field_11232)
                .movementType(EntityMovementType.WATER)
                .color(ColorSettings.builder()
                        .defaultColor(0x3F76E4)
                        .renderColor(class_1163::method_4961)
                        // Currently no biome based fog color for water, so we use default color here
                        .fog(ColorSettings.FogType.WATER, 0x050533)
                )
                .infiniteWhen(world -> world.method_8450().method_8355(class_1928.field_40884));
    }

    /**
     * Creates a FluidSettings builder which by default acts like vanilla lava
     */
    public static Builder lavaLike() {
        return builder().ticksRandomly()
                .setsFire()
                // I know its funny, but players can regain air in lava(yes its a vanilla feature)
                .canBreath()
                .temperature(LAVA_TEMPERATURE)
                .movementType(EntityMovementType.LAVA)
                .luminance(15)
                .color(ColorSettings.builder().fixedColor(0xFFFFFF).mapColor(class_3620.field_16002).fog(ColorSettings.FogType.LAVA, 10033408))
                .pickUpSound(class_3417.field_15202)
                .pourSound(class_3417.field_15010)
                .particle(class_2398.field_11223)
                .flowSpeed(world -> world.method_8597().comp_644() ? 4 : 2)
                .levelDecreasePerBlock(world -> world.method_8597().comp_644() ? 1 : 2)
                .tickRate(world -> world.method_8597().comp_644() ? 10 : 30)
                .infiniteWhen(world -> world.method_8450().method_8355(class_1928.field_40885));
    }

    public static void register(class_3611 fluid, FluidSettings settings) {
        fluid = FluidHelper.trim(fluid);
        if (REGISTRY.putIfAbsent(fluid, settings) != null) {
            throw new IllegalStateException("Duplicate settings registration for fluid " + FluidRegistry.getId(fluid));
        }
        FluidVariantAttributes.register(fluid, settings);
    }

    public static void register(FluidReference<?> fluid) {
        register(fluid.getStill(), fluid.getSettings());
    }

    static {
        REGISTRY.putIfAbsent(class_3612.field_15906, FluidSettings.builder().canBreath().color(ColorSettings.ofFixedColor(0xFFFFFF, class_3620.field_16022, ColorSettings.FogType.NONE)).build());
        REGISTRY.putIfAbsent(class_3612.field_15910, FluidSettings.waterLike().bucket(() -> class_1802.field_8705).block(() -> class_2246.field_10382).build());
        REGISTRY.putIfAbsent(class_3612.field_15908, FluidSettings.lavaLike().bucket(() -> class_1802.field_8187).block(() -> class_2246.field_10164).build());
    }

    public static FluidSettings get(class_3611 fluid) {
        fluid = FluidHelper.trim(fluid);
        FluidSettings settings = REGISTRY.get(fluid);
        if (settings == null) {
            // Try to create settings from FabricAPI if no settings is registered
            settings = fromFabricVariant(FluidVariant.of(fluid));
            //register(fluid, settings);
            REGISTRY.putIfAbsent(fluid, settings);
        }
        return settings;
    }

    public static FluidSettings get(FluidReference<?> fluid) {
        return REGISTRY.get(fluid.getStill());
    }

    public static FluidSettings get(class_3610 state) {
        return get(state.method_15772());
    }

    /// @deprecated Use {@link FluidReference#getBlock()}
    @Deprecated
    public class_2248 getFluidBlock() {
        return fluidBlockSupplier.get();
    }

    public class_1792 getBucketItem() {
        return Optional.ofNullable(this.bucketItemSupplier).map(Supplier::get).orElse(class_1802.field_8162);
    }
    public int getFlowSpeed(class_4538 world) {
        return this.flowSpeedGetter.applyAsInt(world);
    }
    public int getTickRate(class_4538 world) {
        return this.tickRateGetter.applyAsInt(world);
    }
    public int getLevelDecreasePerBlock(class_4538 world) {
        return this.levelDecrPerBlockGetter.applyAsInt(world);
    }
    public Optional<class_3414> getBucketFillSound() {
        return bucketFillSound;
    }

    public Optional<class_3414> getBucketEmptySound() {
        return bucketEmptySound;
    }

    @Nullable
    public class_2394 getDrippingParticle() {
        return drippingParticle;
    }
    public boolean canSetFire() {
        return this.setsFire;
    }
    public boolean hasRandomTick() {
        return this.randomTick;
    }
    public int getLight(class_2680 state) {
        return this.luminanceGetter == null ? 0 : this.luminanceGetter.applyAsInt(state);
    }
    public ColorSettings getColor() {
        return this.color;
    }
    public class_3620 getMapColor() {
        return this.color.mapColor();
    }
    public int getColor(@Nullable class_1920 world, @Nullable class_2338 pos) {
        return this.color.getColorInWorld(world, pos);
    }
    public int getDefaultColor() {
        return this.color.defaultColor;
    }

    public boolean isInfinite(class_1937 world) {
        return this.infinite.test(world);
    }
    public int getTemperature() {
        return temperature;
    }

    public boolean flowsUp() {
        return flowsUp;
    }

    public boolean canEntityBreath() {
        return this.retainsAir;
    }

    public boolean canSwim() {
        return this.getMovementType() == EntityMovementType.WATER;
    }

    public EntityMovementType getMovementType() {
        return this.movementType;
    }

    public class_2350[] getFlowDirections() {
        return this.flowsUp ? AIR_FLOW_DIRECTIONS : FLOW_DIRECTIONS;
    }

    @Override
    public class_2561 getName(FluidVariant fluidVariant) {
        return FluidVariantAttributeHandler.super.getName(fluidVariant);
    }

    @Override
    public Optional<class_3414> getFillSound(FluidVariant variant) {
        return this.getBucketFillSound();
    }

    @Override
    public Optional<class_3414> getEmptySound(FluidVariant variant) {
        return this.getBucketEmptySound();
    }

    @Override
    public int getLuminance(FluidVariant variant) {
        return this.getLight(variant.getFluid().method_15785().method_15759());
    }

    @Override
    public int getTemperature(FluidVariant variant) {
        return this.getTemperature();
    }

    @Override
    public int getViscosity(FluidVariant variant, @Nullable class_1937 world) {
        if (world == null) {
            return FluidVariantAttributeHandler.super.getViscosity(variant, world);
        } else {
            return FluidConstants.VISCOSITY_RATIO * this.getFlowSpeed(world);
        }
    }

    @Override
    public boolean isLighterThanAir(FluidVariant variant) {
        return this.flowsUp();
    }

    /**
     * Builder for FluidSettings
     * @see FluidSettings#builder()
     */
    public static class Builder {
        private Supplier<class_2248> fluidBlockSupplier;
        private Supplier<@Nullable class_1792> bucketItemSupplier = () -> null;
        private ToIntFunction<class_4538> flowSpeedGetter, tickRateGetter, levelDecrPerBlockGetter;
        private Optional<class_3414> bucketFillSound, bucketEmptySound;
        private @Nullable class_2394 drippingParticle;
        private boolean setsFire, randomTick, flowsUp, entityBreath;
        private ToIntFunction<class_2680> luminanceGetter;
        private ColorSettings color = ColorSettings.ofFixedColor(0x3F76E4, class_3620.field_16019, ColorSettings.FogType.WATER);
        private Predicate<class_1937> infinite = w -> false;
        private int temperature = 300;
        private EntityMovementType movementType = EntityMovementType.AIR;

        protected Builder() {
            this.flowSpeed(4).tickRate(5).levelDecreasePerBlock(1).luminance(0);
            this.pickUpSound(class_3417.field_15126).pourSound(class_3417.field_14834);
        }

        /**
         * Creates the FluidSettings
         */
        public FluidSettings build() {
            return new FluidSettings(
                    fluidBlockSupplier,
                    bucketItemSupplier,
                    flowSpeedGetter,
                    tickRateGetter,
                    levelDecrPerBlockGetter,
                    bucketEmptySound,
                    bucketFillSound,
                    drippingParticle,
                    setsFire,
                    randomTick,
                    flowsUp,
                    luminanceGetter,
                    color,
                    infinite,
                    temperature,
                    entityBreath,
                    movementType
            );
        }

        /**
         * Sets the block factor for this fluid
         * Do nat call this directly, as this is automatically applied
         * for fluids
         * @deprecated {@link FluidReference#getBlock()}
         */
        @ApiStatus.Internal
        @Deprecated
        public Builder block(Supplier<@NotNull class_2248> fluidBlockSupplier) {
            this.fluidBlockSupplier = Suppliers.memoize(fluidBlockSupplier::get);
            return this;
        }

        /**
         * Sets the default bucket item for this fluid
         * null if there is no bucket item
         */
        public Builder bucket(@Nullable Supplier<@NotNull class_1792> itemSupplier) {
            if (itemSupplier != null) {
                this.bucketItemSupplier = Suppliers.memoize(itemSupplier::get);
            } else {
                this.bucketItemSupplier = () -> class_1802.field_8162;
            }
            return this;
        }

        public Builder flowSpeed(ToIntFunction<class_4538> flowSpeedGetter) {
            this.flowSpeedGetter = flowSpeedGetter;
            return this;
        }

        public Builder flowSpeed(int i) {
            return this.flowSpeed(w -> i);
        }

        public Builder tickRate(ToIntFunction<class_4538> tickRateGetter) {
            this.tickRateGetter = tickRateGetter;
            return this;
        }

        public Builder tickRate(int i) {
            return this.tickRate(w -> i);
        }

        public Builder levelDecreasePerBlock(ToIntFunction<class_4538> levelDecrPerBlockGetter) {
            this.levelDecrPerBlockGetter = levelDecrPerBlockGetter;
            return this;
        }

        public Builder levelDecreasePerBlock(int i) {
            return this.levelDecreasePerBlock(w -> i);
        }

        /**
         * Sets the sound when the fluid was picked up by players through buckets
         */
        public Builder pickUpSound(Optional<@Nullable class_3414> bucketFillSound) {
            this.bucketFillSound = bucketFillSound;
            return this;
        }

        /// @see #pickUpSound(Optional)
        public Builder pickUpSound(class_3414 fillSound) {
            return this.pickUpSound(Optional.of(fillSound));
        }

        /**
         * Sets the sound when the fluid was placed through buckets
         */
        public Builder pourSound(Optional<@Nullable class_3414> bucketEmptySound) {
            this.bucketEmptySound = bucketEmptySound;
            return this;
        }

        /// @see #pourSound(Optional)
        public Builder pourSound(class_3414 bucketEmptySound) {
            return this.pourSound(Optional.of(bucketEmptySound));
        }

        /**
         * Sets the dripping particle effect when there is <=1 block below the fluid
         */
        public Builder particle(@Nullable class_2394 particle) {
            this.drippingParticle = particle;
            return this;
        }

        /**
         * Determines if the fluid can set blocks on fire like vanilla lava
         * Note that this will also make the fluid to have random ticks
         */
        public Builder setsFire(boolean bl) {
            this.setsFire = bl;
            if (bl) {
                return this.ticksRandomly(bl);
            }
            return this;
        }

        public Builder setsFire() {
            return this.setsFire(true);
        }

        public Builder ticksRandomly(boolean bl) {
            this.randomTick = bl;
            return this;
        }

        public Builder ticksRandomly() {
            return this.ticksRandomly(true);
        }

        public Builder luminance(ToIntFunction<class_2680> luminance) {
            this.luminanceGetter = luminance;
            return this;
        }

        public Builder luminance(int i) {
            return this.luminance(s -> i);
        }

        public Builder color(ColorSettings color) {
            this.color = color;
            return this;
        }

        public Builder color(ColorSettings.Builder color) {
            return this.color(color.build());
        }

        /**
         * Sets the color of the fluid
         * @param defaultColor The default color value
         * @param color Color in different place in world(like vanilla water)
         */
        public Builder color(int defaultColor, ToIntBiFunction<class_1920, class_2338> color, class_3620 mapColor) {
            return this.color(ColorSettings.builder().defaultColor(defaultColor).renderColor(color).mapColor(mapColor));
        }

        /**
         * Sets the fluid always has the same color
         * @see ColorSettings#ofFixedColor(int, class_3620, ColorSettings.FogType)
         */
        public Builder color(int color, class_3620 mapColor) {
            return this.color(ColorSettings.ofFixedColor(color, mapColor, ColorSettings.FogType.NONE));
        }

        /**
         * Marks when the fluid should be infinite(creates new source while 2 sources matches)
         */
        public Builder infiniteWhen(Predicate<class_1937> infinite) {
            this.infinite = infinite;
            return this;
        }

        /// @see #infiniteWhen(Predicate)
        public Builder isInfinite(boolean bl) {
            this.infinite = w -> bl;
            return this;
        }

        /**
         * Sets temperature for this fluid
         * @param i Temperature, in Kelvin
         * @throws IllegalArgumentException When temperature is negative
         */
        public Builder temperature(int i) {
            if (i < 0) {
                throw new IllegalArgumentException("This should be in Kelvin, which shall never be negative!");
            }
            this.temperature = i;
            return this;
        }

        /**
         * Mark this fluid lighter than air(which typically flows upward, otherwise flows downward)
         */
        public Builder flowsUp() {
            this.flowsUp = true;
            return this;
        }

        /**
         * Determines if entities can regenerate air in this fluid
         * Note that aquatic mobs will invert this value(drown in "breathable" fluids)
         * @param bl Whether entities can breathe in the fluid
         */
        public Builder canBreath(boolean bl) {
            this.entityBreath = bl;
            return this;
        }

        /**
         * Make normal entities breathable in the fluid
         * @see #canBreath(boolean)
         */
        public Builder canBreath() {
            return this.canBreath(true);
        }

        /**
         * Sets how the fluid affects entity moves
         */
        public Builder movementType(EntityMovementType type) {
            this.movementType = type;
            return this;
        }
    }

    /**
     * How entities move when in this fluid
     * @see rc55.mc.rfapi.mixin.EntityMixin
     */
    public enum EntityMovementType {
        /**
         * Same action as in the air(default action while in neither tags)
         */
        AIR,
        /**
         * Same action as in water(action while in tag #minecraft:water)
         */
        WATER,
        /**
         * Same actions as in lava(action while in tag #minecraft:lava)
         */
        LAVA,
        /**
         * Will push entities horizontally, but has no buoyancy(which means entities will take fall damage in it)
         */
        HORIZONTAL,
    }

    /**
     * Color settings for the fluid
     * All colors are in RGB format!
     * @param defaultColor Default color when world or pos is null
     * @param renderColor Fluid color in different place in the world
     * @param itemColor Color for item layer 1, set to -1 to disable
     * @param mapColor Color for fluid blocks on map
     * @param fogType How the fog will be rendered when the camera is
     *                submerged in the fluid, see {@link FogType}
     * @param fogColor Color for the fog
     */
    public record ColorSettings(
            int defaultColor,
            ToIntBiFunction<class_1920, class_2338> renderColor,
            int itemColor,
            class_3620 mapColor,
            FogType fogType,
            int fogColor
    ) implements ToIntBiFunction<@Nullable class_1920, @Nullable class_2338> {
        /**
         * @apiNote Do <strong>**NOT**</strong> call this, call the {@linkplain #getColorInWorld(class_1920, class_2338) null safe version} instead!
         */
        @Deprecated
        public ToIntBiFunction<class_1920, class_2338> renderColor() {
            throw new AssertionError("You should call #getColorInWorld(BlockRenderView, BlockPos) instead of this!");
        }

        @Override
        public int applyAsInt(@Nullable class_1920 world, @Nullable class_2338 pos) {
            if (world == null || pos == null) {
                return this.defaultColor();
            } else {
                return this.renderColor.applyAsInt(world, pos);
            }
        }

        public int getColorInWorld(@Nullable class_1920 world, @Nullable class_2338 pos) {
            return this.applyAsInt(world, pos);
        }

        /**
         * If the custom fog render should be used
         * Applied via {@linkplain rc55.mc.rfapi.mixin.client.BackgroundRendererMixin mixins}
         */
        public boolean shouldRenderFog() {
            return this.fogType != FogType.NONE && this.fogColor != -1;
        }

        public static rc55.mc.rfapi.fluid.FluidSettings.ColorSettings.Builder builder() {
            return new rc55.mc.rfapi.fluid.FluidSettings.ColorSettings.Builder();
        }

        public static ColorSettings ofFixedColor(int color, class_3620 mapColor, FogType fogType) {
            int fixed = color & 0xFFFFFF;
            return new ColorSettings(
                    fixed,
                    (w, p) -> fixed,
                    fixed,
                    mapColor,
                    fogType,
                    fogType == FogType.NONE ? -1 : fixed
            );
        }
        
        public static int toRgb(int r, int g, int b) {
            return (((r & 0xFF) << 16) | ((g & 0xFF) << 8) | (b & 0xFF)) & 0xFFFFFF;
        }
        
        public static int toRgb(float r, float g, float b) {
            return toRgb((int) (r * 255f), (int) (g * 255f), (int) (b * 255f));
        }

        public static class Builder {
            private int defaultColor = 0xFFFFFF;
            private int itemColor = -1;
            private FogType fogType = FogType.NONE;
            private int fogColor = -1;
            private class_3620 mapColor = class_3620.field_16019;
            private ToIntBiFunction<class_1920, class_2338> renderColor = (world, pos) -> 0xFFFFFF;

            /**
             * Set default, render, fog color for the fluid
             */
            public rc55.mc.rfapi.fluid.FluidSettings.ColorSettings.Builder fixedColor(int color) {
                this.fogColor = color & 0xFFFFFF;
                return this.defaultColor(fogColor).renderColor((w, p) -> fogColor).itemColor(fogColor);
            }

            /**
             * Sets the default color for the fluid
             * Will fallback if the color getter called with null values
             */
            public rc55.mc.rfapi.fluid.FluidSettings.ColorSettings.Builder defaultColor(int color) {
                this.defaultColor = color & 0xFFFFFF;
                return this;
            }

            /**
             * Sets the color of the fluid
             * @param color Color in different place in world(like vanilla water)
             */
            public rc55.mc.rfapi.fluid.FluidSettings.ColorSettings.Builder renderColor(ToIntBiFunction<@NotNull class_1920, @NotNull class_2338> color) {
                this.renderColor = color;
                return this;
            }

            /**
             * Sets color for the bucket items, will be applied to layer with tintIndex=1
             * @param color Item render color, set to -1 to disable item color
             */
            public rc55.mc.rfapi.fluid.FluidSettings.ColorSettings.Builder itemColor(int color) {
                this.itemColor = color == -1 ? -1 : (color & 0xFFFFFF);
                return this;
            }

            public rc55.mc.rfapi.fluid.FluidSettings.ColorSettings.Builder mapColor(class_3620 color) {
                this.mapColor = color;
                return this;
            }

            /**
             * Sets the underwater fog
             * Note that currently only fixed color are supported
             * If you want your fluid to act like vanilla water, add it to {@code #minecraft:water} tag instead
             * @param type How the fog appears
             * @param color The fog color
             */
            public rc55.mc.rfapi.fluid.FluidSettings.ColorSettings.Builder fog(FogType type, int color) {
                this.fogType = type;
                this.fogColor = color & 0xFFFFFF;
                return this;
            }

            public ColorSettings build() {
                return new ColorSettings(
                        defaultColor,
                        renderColor,
                        itemColor,
                        mapColor,
                        fogType,
                        fogColor
                );
            }
        }

        /**
         * How the fog will be rendered when the camera is submerged in the fluid
         */
        public enum FogType {
            /**
             * No fog, set to this if you want to disable underwater fog
             */
            NONE,
            /**
             * Fog visibility like vanilla water
             */
            WATER,
            /**
             * Fog visibility like vanilla lava
             */
            LAVA,
            /**
             * Fog visibility like submerging in vanilla powder snow
             */
            SNOW
        }
    }
}
