package rc55.mc.rfapi.fluid.reaction;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.data.CodecHelper;
import rc55.mc.rfapi.data.FluidIngredient;

public class SourceConversionReaction implements IFluidReaction<FluidReactionType<SourceConversionReaction>> {
    private final FluidIngredient source, ingredient;
    private final float chance;
    private final class_2680 result;

    public SourceConversionReaction(
            FluidIngredient source,
            float chance,
            FluidIngredient ingredient,
            class_2680 result
    ) {
        this.source = source;
        this.chance = chance;
        this.ingredient = ingredient;
        this.result = result;
    }

    public static final Codec<SourceConversionReaction> CODEC = RecordCodecBuilder.create(i -> i.group(
            FluidIngredient.CODEC.fieldOf("source").forGetter(r -> r.source),
            CodecHelper.CHANCE.optionalFieldOf("chance", 1f).forGetter(r -> r.chance),
            FluidIngredient.CODEC.fieldOf("ingredient").forGetter(r -> r.ingredient),
            CodecHelper.BLOCK_STATE.fieldOf("result").forGetter(r -> r.result)
    ).apply(i, SourceConversionReaction::new));

    @Override
    public FluidReactionType<SourceConversionReaction> getType() {
        return FluidReactionType.SOURCE_CONVERSION;
    }

    @Override
    public FluidIngredient getSource() {
        return source;
    }

    @Override
    public float getChance() {
        return chance;
    }

    @Override
    public class_2680 getResult() {
        return result;
    }

    @Override
    public boolean checkReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        for (final class_2350 direction : class_2350.class_2353.field_11062) {
            if (this.ingredient.test(world.method_8316(targetPos.method_10093(direction)))) {
                return this.source.test(world.method_8316(sourcePos));
            }
        }
        return this.checkRandom(world) && world.method_8320(targetPos).method_26215();
    }

    @Override
    public @Nullable class_2680 performReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        return world.method_8652(targetPos, this.getResult(), class_2248.field_31036) ? this.getResult() : null;
    }
}
