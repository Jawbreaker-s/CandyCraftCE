package rc55.mc.rfapi.fluid.reaction;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2769;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_7923;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.data.CodecHelper;
import rc55.mc.rfapi.data.FluidIngredient;
import rc55.mc.rfapi.fluid.FluidHelper;

public class InfectionReaction implements IFluidReaction<FluidReactionType<InfectionReaction>> {
    private final class_3611 source;
    private final FluidIngredient sourceIngredient, target;
    private final float chance;

    public InfectionReaction(
            class_3611 source,
            FluidIngredient target,
            float chance
    ) {
        this.source = FluidHelper.trim(source);
        this.target = target;
        this.chance = chance;

        if (source instanceof class_3609) {
            this.sourceIngredient = FluidIngredient.of(this.source, ((class_3609) source).method_15750());
        } else {
            this.sourceIngredient = FluidIngredient.of(source);
        }
    }

    public static final Codec<InfectionReaction> CODEC = RecordCodecBuilder.create(i -> i.group(
            class_7923.field_41173.method_39673().fieldOf("source").forGetter(r -> r.source),
            FluidIngredient.CODEC.fieldOf("target").forGetter(r -> r.target),
            CodecHelper.CHANCE.optionalFieldOf("chance", 1f).forGetter(r -> r.chance)
    ).apply(i, InfectionReaction::new));

    @Override
    public FluidReactionType<InfectionReaction> getType() {
        return FluidReactionType.INFECTION;
    }

    @Override
    public FluidIngredient getSource() {
        return sourceIngredient;
    }

    @Override
    public float getChance() {
        return chance;
    }

    @Override
    public class_2680 getResult() {
        return source.method_15785().method_15759();
    }

    @Override
    public boolean checkReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        return this.checkRandom(world)
                && IFluidReaction.validateFluidBlock(world, targetPos, false)
                && this.getSource().test(world.method_8316(sourcePos))
                && this.target.test(world.method_8316(targetPos));
    }

    @Override
    public @Nullable class_2680 performReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        final class_2680 result = copyProperty(world.method_8320(targetPos), this.getResult());
        return world.method_8652(targetPos, result, class_2248.field_31031 | class_2248.field_31028 | class_2248.field_31030) ? result : null;
    }

    @SuppressWarnings("unchecked")
    protected static <T extends Comparable<T>> class_2680 copyProperty(class_2680 originalState, class_2680 newState) {
        for (class_2769<?> value : originalState.method_28501()) {
            class_2769<T> property = (class_2769<T>) value;
            newState = newState.method_47968(property, originalState.method_11654(property));
        }
        return newState;
    }
}
