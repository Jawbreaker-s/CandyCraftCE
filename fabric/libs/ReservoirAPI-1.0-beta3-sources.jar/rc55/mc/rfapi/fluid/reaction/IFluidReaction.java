package rc55.mc.rfapi.fluid.reaction;

import com.google.common.collect.ImmutableSet;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.RFApiMain;
import rc55.mc.rfapi.data.FluidIngredient;
import rc55.mc.rfapi.data.ResourceMap;
import rc55.mc.rfapi.data.ResourceReloadListenerImpl;
import rc55.mc.rfapi.fluid.FluidHelper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2338;
import net.minecraft.class_2404;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3611;

/**
 * This is a data-driven system which determines how fluids behave when they match certain block/fluid
 * <p>
 *     To add a new reaction type, first register it through {@link FluidReactionType#register(class_2960, FluidReactionType)}.
 *     After that, pick a random pos and trigger your new reaction type
 *     manually by {@link #triggerReaction(FluidReactionType, class_1936, class_2338, class_2338)}.
 * </p>
 * @param <T> The type of this reaction
 */
public interface IFluidReaction<T extends FluidReactionType<?>> {
    Codec<IFluidReaction<?>> BASE_CODEC = new Codec<>() {
        @Override
        public <P> DataResult<Pair<IFluidReaction<?>, P>> decode(DynamicOps<P> ops, P prefix) {
            return ops.get(prefix, "type")
                    .flatMap(p -> FluidReactionType.REGISTRY.method_39673().parse(ops, p))
                    .flatMap(type -> type.codec().parse(ops, prefix))
                    .map(reaction -> Pair.of(reaction, prefix));
        }

        @SuppressWarnings("unchecked")
        @Override
        public <P> DataResult<P> encode(IFluidReaction<? extends FluidReactionType> reaction, DynamicOps<P> ops, P prefix) {
            return FluidReactionType.REGISTRY.method_39673().encodeStart(ops, reaction.getType())
                    .map(p -> ops.set(prefix, "type", p))
                    .flatMap(p -> ((Codec<IFluidReaction<?>>)reaction.getType().codec()).encode(reaction, ops, p));
        }
    };

    ResourceMap<class_3611, IFluidReaction<?>> CACHE = new ResourceMap<>(true, r -> r.getSource().stream()
            .flatMap(FluidIngredient.Entry::stream).collect(Collectors.toList())
    );

    ResourceReloadListenerImpl<IFluidReaction<?>> RELOAD_LISTENER = ResourceReloadListenerImpl.ofServer(
            class_2960.method_43902(RFApiMain.MODID, "fluid_reaction"), IFluidReaction.BASE_CODEC, IFluidReaction.CACHE
    );

    @ApiStatus.Internal
    static void initDataListener() {
    }

    /**
     * Triggers fluid reaction
     * @param type Type of reaction to trigger, {@code null} to dismiss type check
     * @param world The world
     * @param sourcePos Where the fluid triggers it from
     * @param targetPos Where the result will be placed
     * @return The result of the reaction, {@code null} for no reaction performed
     */
    static @Nullable class_2680 triggerReaction(@Nullable FluidReactionType<?> type, class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        final class_3611 fluid = world.method_8316(sourcePos).method_15772();
        for (final IFluidReaction<?> reaction : CACHE.get(fluid)) {
            if (type == null || reaction.getType() == type) {
                if (reaction.checkReaction(world, sourcePos, targetPos)) {
                    final class_2680 result = reaction.performReaction(world, sourcePos, targetPos);
                    if (result == null) {
                        continue;
                    }
                    if (fluid.getSettings().canSetFire()) {
                        FluidHelper.playExtinguishEvent(world, sourcePos);
                    } else if (world.method_8316(targetPos).method_15772().getSettings().canSetFire()) {
                        FluidHelper.playExtinguishEvent(world, targetPos);
                    }
                    return result;
                }
            }
        }
        return null;
    }

    static <T extends IFluidReaction<?>> Collection<T> allFor(@Nullable FluidReactionType<T> type, class_3611 fluid) {
        if (type == null) {
            return (Collection<T>) ImmutableSet.copyOf(CACHE.get(fluid));
        }
        List<T> list = new ArrayList<>(5);
        for (final IFluidReaction<?> reaction : CACHE.get(fluid)) {
            if (reaction.getType() == type) {
                list.add((T) reaction);
            }
        }
        return ImmutableSet.copyOf(list);
    }

    /**
     * Check if the fluid to reaction with is not a waterlogged block
     * @param world The world
     * @param pos Pos to perform reaction
     * @param allowEmpty Whether allow the pos to be air
     */
    static boolean validateFluidBlock(class_1922 world, class_2338 pos, boolean allowEmpty) {
        return (allowEmpty && world.method_8320(pos).method_26215()) || world.method_8320(pos).method_26204() instanceof class_2404;
    }

    T getType();

    /**
     * Fluids able to trigger this reaction
     */
    FluidIngredient getSource();

    /**
     * Chance of this reaction happens, within {@code [0,1]}
     * Set to 1 for always, 0 for never
     */
    float getChance();

    /**
     * What this reaction produces
     */
    class_2680 getResult();

    /**
     * Checks the chance for this reaction to happen
     * @param world The world
     */
    default boolean checkRandom(class_1936 world) {
        return world.method_8409().method_43057() < this.getChance();
    }

    /**
     * Check if this reaction can happen
     * This is also responsible for {@linkplain #checkRandom(class_1936) checking the random}
     * @param world The world
     * @param sourcePos Where the reaction was triggered
     * @param targetPos Where the result will be placed
     */
    boolean checkReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos);

    /**
     * Performs the reaction
     * Call {@link #checkReaction(class_1936, class_2338, class_2338)} before calling this!
     * @param world The world
     * @param sourcePos Where the reaction was triggered
     * @param targetPos Where the result will be placed
     * @return The result, {@code null} for not performed
     * @see #triggerReaction(FluidReactionType, class_1936, class_2338, class_2338)
     */
    @Nullable
    class_2680 performReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos);
}
