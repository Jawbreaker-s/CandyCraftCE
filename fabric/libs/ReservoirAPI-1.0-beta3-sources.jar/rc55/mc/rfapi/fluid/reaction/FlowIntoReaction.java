package rc55.mc.rfapi.fluid.reaction;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.data.CodecHelper;
import rc55.mc.rfapi.data.FluidIngredient;

public class FlowIntoReaction implements IFluidReaction<FluidReactionType<FlowIntoReaction>> {
    protected final FluidIngredient source, ingredient;
    protected final class_2680 result;
    protected final float chance;

    public FlowIntoReaction(
            FluidIngredient source,
            float chance,
            FluidIngredient ingredient,
            class_2680 result
    ) {
        this.ingredient = ingredient;
        this.chance = chance;
        this.source = source;
        this.result = result;
    }

    public static final Codec<FlowIntoReaction> CODEC = RecordCodecBuilder.create(i -> i.group(
            FluidIngredient.CODEC.fieldOf("source").forGetter(r -> r.source),
            CodecHelper.CHANCE.optionalFieldOf("chance", 1f).forGetter(r -> r.chance),
            FluidIngredient.CODEC.fieldOf("ingredient").forGetter(r -> r.ingredient),
            CodecHelper.BLOCK_STATE.fieldOf("result").forGetter(r -> r.result)
    ).apply(i, FlowIntoReaction::new));

    @Override
    public FluidReactionType<FlowIntoReaction> getType() {
        return FluidReactionType.FLOW_INTO;
    }

    @Override
    public FluidIngredient getSource() {
        return source;
    }

    @Override
    public float getChance() {
        return chance;
    }

    @Override
    public class_2680 getResult() {
        return result;
    }

    @Override
    public boolean checkReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        return this.checkRandom(world)
                //&& IFluidReaction.validateFluidBlock(world, targetPos, true)
                && ingredient.test(world.method_8316(targetPos))
                && source.test(world.method_8316(sourcePos));
    }

    @Override
    public @Nullable class_2680 performReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        return world.method_8652(targetPos, result, class_2248.field_31036) ? result : null;
    }
}
