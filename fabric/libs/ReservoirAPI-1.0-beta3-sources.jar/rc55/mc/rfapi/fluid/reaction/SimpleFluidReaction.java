package rc55.mc.rfapi.fluid.reaction;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.data.CodecHelper;
import rc55.mc.rfapi.data.FluidIngredient;
import rc55.mc.rfapi.data.StateIngredient;
import rc55.mc.rfapi.fluid.FluidSettings;

import java.util.Optional;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2680;

public class SimpleFluidReaction implements IFluidReaction<FluidReactionType<? extends SimpleFluidReaction>> {
    protected final FluidIngredient source;
    protected final Optional<@Nullable StateIngredient> surroundingIngredient, verticalIngredient;
    protected final class_2680 result;
    protected final float chance;

    public SimpleFluidReaction(
            FluidIngredient source,
            float chance,
            Optional<@Nullable StateIngredient> surroundingIngredient,
            Optional<@Nullable StateIngredient> verticalIngredient,
            class_2680 result
    ) {
        this.source = source;
        this.chance = chance;
        this.surroundingIngredient = surroundingIngredient;
        this.verticalIngredient = verticalIngredient;
        this.result = result;
        if (verticalIngredient.isEmpty() && surroundingIngredient.isEmpty()) {
            throw new IllegalArgumentException("Must exist at least one type of material!");
        }
    }

    public static final Codec<SimpleFluidReaction> CODEC = RecordCodecBuilder.create(i -> i.group(
            FluidIngredient.CODEC.fieldOf("source").forGetter(r -> r.source),
            CodecHelper.CHANCE.optionalFieldOf("chance", 1f).forGetter(r -> r.chance),
            StateIngredient.CODEC.optionalFieldOf("surrounding_ingredient").forGetter(r -> r.surroundingIngredient),
            StateIngredient.CODEC.optionalFieldOf("vertical_ingredient").forGetter(r -> r.verticalIngredient),
            CodecHelper.BLOCK_STATE.fieldOf("result").forGetter(r -> r.result)
    ).apply(i, SimpleFluidReaction::new));

    @Override
    public FluidReactionType<? extends SimpleFluidReaction> getType() {
        return FluidReactionType.SIMPLE;
    }

    @Override
    public FluidIngredient getSource() {
        return source;
    }

    @Override
    public float getChance() {
        return chance;
    }

    @Override
    public class_2680 getResult() {
        return result;
    }

    @Override
    public boolean checkReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        return this.checkRandom(world) && this.checkSurrounding(world, sourcePos, targetPos) && this.checkVertical(world, sourcePos, targetPos);
    }

    @Override
    public @Nullable class_2680 performReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        return world.method_8652(targetPos, this.result, class_2248.field_31036) ? this.getResult() : null;
    }


    protected boolean checkSurrounding(class_1922 world, class_2338 sourcePos, class_2338 pos) {
        final FluidSettings settings = world.method_8316(sourcePos).method_15772().getSettings();
        if (this.surroundingIngredient.isPresent()) {
            for (final class_2350 direction : settings.flowsUp() ? FluidSettings.FLOW_DIRECTIONS : FluidSettings.AIR_FLOW_DIRECTIONS) {
                final class_2338 sidePos = pos.method_10093(direction);
                if (this.surroundingIngredient.get().test(world.method_8320(sidePos))) {
                    return true;
                }
            }
        } else {
            return true;
        }
        return false;
    }

    protected boolean checkVertical(class_1922 world, class_2338 sourcePos, class_2338 pos) {
        final FluidSettings settings = world.method_8316(sourcePos).method_15772().getSettings();
        if (this.verticalIngredient.isPresent()) {
            final class_2338 verticalPos = pos.method_10093(settings.flowsUp() ? class_2350.field_11036 : class_2350.field_11033);
            return this.verticalIngredient.get().test(world.method_8320(verticalPos));
        } else {
            return true;
        }
    }
}
