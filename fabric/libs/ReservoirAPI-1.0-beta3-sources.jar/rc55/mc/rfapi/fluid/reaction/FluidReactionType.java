package rc55.mc.rfapi.fluid.reaction;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.event.registry.FabricRegistryBuilder;
import net.fabricmc.fabric.api.event.registry.RegistryAttribute;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import org.jetbrains.annotations.ApiStatus;
import rc55.mc.rfapi.RFApiMain;

/**
 * Type for a fluid reaction
 * @param codec Codec for data files
 * @param <T> The reaction class
 * @see IFluidReaction
 */
public record FluidReactionType<T extends IFluidReaction<?>>(Codec<T> codec) {
    public static final class_2378<FluidReactionType<?>> REGISTRY = FabricRegistryBuilder.<FluidReactionType<?>>createDefaulted(
            class_5321.method_29180(new class_2960(RFApiMain.MODID, "fluid_reaction_type")), new class_2960("simple")
    ).attribute(RegistryAttribute.SYNCED).attribute(RegistryAttribute.MODDED).buildAndRegister();

    /**
     * Normal fluid reactions(e.g. vanilla basalt generator)
     */
    public static final FluidReactionType<SimpleFluidReaction> SIMPLE = register(
            new class_2960("simple"), new FluidReactionType<>(SimpleFluidReaction.CODEC)
    );

    /**
     * Normal fluid reactions, but creates different block when the source is still/flowing
     * (e.g. in vanilla, when flowing/still lava mets water creates cobblestone/obsidian)
     */
    public static final FluidReactionType<SimpleFlowableFluidReaction> FLOWABLE = register(
            new class_2960("flowable"), new FluidReactionType<>(SimpleFlowableFluidReaction.CODEC)
    );

    /**
     * Happens when a fluid flows into another fluid(e.g. vanilla stone generator)
     */
    public static final FluidReactionType<FlowIntoReaction> FLOW_INTO = register(
            new class_2960("flow_into"), new FluidReactionType<>(FlowIntoReaction.CODEC)
    );

    /**
     * Happens when 2 fluid source blocks try to create a new source block
     */
    public static final FluidReactionType<SourceConversionReaction> SOURCE_CONVERSION = register(
            new class_2960(RFApiMain.MODID, "source_conversion"), new FluidReactionType<>(SourceConversionReaction.CODEC)
    );

    /**
     * Turns the target fluid into the source fluid when they met each other
     */
    public static final FluidReactionType<InfectionReaction> INFECTION = register(
            new class_2960(RFApiMain.MODID, "infection"), new FluidReactionType<>(InfectionReaction.CODEC)
    );

    public static <T extends IFluidReaction<?>> FluidReactionType<T> register(class_2960 id, FluidReactionType<T> type) {
        return class_2378.method_10230(REGISTRY, id, type);
    }

    @ApiStatus.Internal
    public static void init() {
        RFApiMain.LOGGER.info("Loaded {} internal reaction types.", REGISTRY.method_42021().size());
        IFluidReaction.initDataListener();
    }
}
