package rc55.mc.rfapi.fluid.reaction;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.data.CodecHelper;
import rc55.mc.rfapi.data.FluidIngredient;
import rc55.mc.rfapi.data.StateIngredient;

import java.util.Optional;
import net.minecraft.class_1936;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public class SimpleFlowableFluidReaction extends SimpleFluidReaction {
    protected final class_2680 flowingResult;

    public SimpleFlowableFluidReaction(
            FluidIngredient source, float chance, Optional<@Nullable StateIngredient> surroundingIngredient,
            Optional<@Nullable StateIngredient> verticalIngredient, class_2680 stillResult, class_2680 flowingResult
    ) {
        super(source, chance, surroundingIngredient, verticalIngredient, stillResult);
        this.flowingResult = flowingResult;
    }

    public static final Codec<SimpleFlowableFluidReaction> CODEC = RecordCodecBuilder.create(i -> i.group(
            FluidIngredient.CODEC.fieldOf("source").forGetter(r -> r.source),
            CodecHelper.CHANCE.optionalFieldOf("chance", 1f).forGetter(r -> r.chance),
            StateIngredient.CODEC.optionalFieldOf("surrounding_ingredient").forGetter(r -> r.surroundingIngredient),
            StateIngredient.CODEC.optionalFieldOf("vertical_ingredient").forGetter(r -> r.verticalIngredient),
            CodecHelper.BLOCK_STATE.fieldOf("still_result").forGetter(r -> r.result),
            CodecHelper.BLOCK_STATE.fieldOf("flowing_result").forGetter(r -> r.flowingResult)
    ).apply(i, SimpleFlowableFluidReaction::new));

    @Override
    public FluidReactionType<? extends SimpleFlowableFluidReaction> getType() {
        return FluidReactionType.FLOWABLE;
    }

    @Override
    public @Nullable class_2680 performReaction(class_1936 world, class_2338 sourcePos, class_2338 targetPos) {
        class_2680 result = world.method_8316(sourcePos).method_15771() ? this.result : this.flowingResult;
        return world.method_8652(targetPos, result, class_2248.field_31036) ? result : null;
    }
}
