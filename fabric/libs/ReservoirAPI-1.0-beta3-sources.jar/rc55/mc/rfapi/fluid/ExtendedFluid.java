package rc55.mc.rfapi.fluid;

import com.google.common.collect.Maps;
import com.mojang.datafixers.util.Pair;
import it.unimi.dsi.fastutil.shorts.*;
import net.minecraft.block.*;
import net.minecraft.class_1792;
import net.minecraft.class_1922;
import net.minecraft.class_1928;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2386;
import net.minecraft.class_2394;
import net.minecraft.class_2404;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_3486;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3616;
import net.minecraft.class_3621;
import net.minecraft.class_4538;
import net.minecraft.class_4770;
import net.minecraft.class_5819;
import net.minecraft.class_6088;
import net.minecraft.fluid.*;
import net.minecraft.world.*;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.mixin.FlowableFluidAccessor;

import java.util.Map;

/**
 * ReservoirAPI version of {@link class_3609}
 * Supports fluids that flows upward
 */
public class ExtendedFluid extends class_3609 implements IFluidWithSettings {

    private final FluidSettings settings;
    private final FluidReference<? extends ExtendedFluid> reference;
    private final boolean still;
    private final class_2350 verticalFlowDirection;
    private final Map<class_3610, class_265> shapeCache;

    /**
     * Creates an instance for ExtendedFluid
     * @param settings Properties for this fluid, Should be the same for still/flow factor
     * @param reference Reference for this fluid
     * @param still Whether this represents a source block
     */
    public ExtendedFluid(FluidSettings settings, FluidReference<? extends ExtendedFluid> reference, boolean still) {
        this.settings = settings;
        this.reference = reference;
        this.still = still;
        this.verticalFlowDirection = this.getSettings().flowsUp() ? class_2350.field_11036 : class_2350.field_11033;
        this.shapeCache = Maps.newIdentityHashMap();
    }

    public static ExtendedFluid ofStill(FluidSettings settings, FluidReference<ExtendedFluid> reference) {
        return new ExtendedFluid(settings, reference, true);
    }

    public static ExtendedFluid ofFlowing(FluidSettings settings, FluidReference<ExtendedFluid> reference) {
        return new ExtendedFluid(settings, reference, false);
    }

    public boolean flowsUp() {
        return this.verticalFlowDirection == class_2350.field_11036;
    }

    public class_2350 getVerticalFlowDirection() {
        return verticalFlowDirection;
    }

    @Override
    public FluidSettings getSettings() {
        return this.settings;
    }

    @Override
    protected void method_15775(class_2689.class_2690<class_3611, class_3610> builder) {
        super.method_15775(builder);
        if (!this.still) {
            builder.method_11667(field_15900);
        }
    }

    @Override
    public int method_15779(class_3610 state) {
        return this.method_15793(state) ? 8 : state.method_11654(field_15900);
    }

    @Override
    public boolean method_15793(class_3610 state) {
        return this.still;
    }

    @Override
    public class_3611 method_15750() {
        return this.reference.getFlowing();
    }

    @Override
    public class_3611 method_15751() {
        return this.reference.getStill();
    }

    @Override
    public boolean method_15780(class_3611 fluid) {
        return fluid == this.method_15751() || fluid == this.method_15750();
    }

    @Override
    protected int method_15733(class_4538 world) {
        return this.settings.getFlowSpeed(world);
    }

    @Override
    protected int method_15739(class_4538 world) {
        return this.settings.getLevelDecreasePerBlock(world);
    }

    @Override
    public class_1792 method_15774() {
        return this.settings.getBucketItem();
    }

    @Override
    public int method_15789(class_4538 world) {
        return this.settings.getTickRate(world);
    }

    @Override
    protected float method_15784() {
        return 100f;
    }

    @Override
    protected boolean method_15737(class_1937 world) {
        return this.settings.isInfinite(world);
    }

    @Override
    protected boolean method_15795() {
        return this.settings.hasRandomTick();
    }

    @Override
    protected @Nullable class_2394 method_15787() {
        return this.settings.getDrippingParticle();
    }

    @Override
    public class_265 method_17775(class_3610 state, class_1922 world, class_2338 pos) {
        return state.method_15761() == 9 && state.method_15772().method_15780(world.method_8316(this.flowsUp() ? pos.method_10074() : pos.method_10084()).method_15772())
                ? class_259.method_1077()
                : this.shapeCache.computeIfAbsent(state, state2 -> this.calculateShape(state2, world, pos));
    }

    private class_265 calculateShape(class_3610 state, class_1922 world, class_2338 pos) {
        return this.flowsUp()
                ? class_259.method_1081(0.0, 1.0 - state.method_15763(world, pos), 0.0, 1.0, 1.0, 1.0)
                : class_259.method_1081(0.0, 0.0, 0.0, 1.0, state.method_15763(world, pos), 1.0);
    }

    @Override
    public float method_15788(class_3610 state, class_1922 world, class_2338 pos) {
        return state.method_15772().method_15780(world.method_8316(this.flowsUp() ? pos.method_10074() : pos.method_10084()).method_15772()) ? 1.0f : state.method_20785();
    }

    @Override
    protected void method_15730(class_1936 world, class_2338 pos, class_2680 state) {
        class_2586 blockEntity = state.method_31709() ? world.method_8321(pos) : null;
        class_2248.method_9610(state, world, pos, blockEntity);
        if (this.settings.canSetFire()) {
            this.playExtinguishEvent(world, pos);
        }
    }

    @Override
    protected boolean method_15777(class_3610 state, class_1922 world, class_2338 pos, class_3611 fluid, class_2350 direction) {
        return FluidHelper.canBeReplacedWith(this, state, world, pos, fluid, direction);
    }

    @Override
    protected class_2680 method_15790(class_3610 state) {
        return this.reference.getBlock().method_9564().method_11657(class_2404.field_11278, method_15741(state));
    }

    @Override
    protected class_3610 method_15727(class_1937 world, class_2338 pos, class_2680 state) {
        return FluidHelper.getUpdatedState(this, world, pos, state, this.method_15739(world));
    }

    @Override
    protected void method_15725(class_1937 world, class_2338 pos, class_3610 state) {
        if (!state.method_15769()) {
            final class_2680 blockState = world.method_8320(pos);
            final class_2338 posDown = this.flowsUp() ? pos.method_10084() : pos.method_10074();
            final class_2680 stateDown = world.method_8320(posDown);

            // 向下流动
            final class_3610 downNewFluidState = this.method_15727(world, posDown, stateDown);
            // 检查是否能够向下流动
            if (this.method_15738(world, pos, blockState, this.getVerticalFlowDirection(), posDown, stateDown, world.method_8316(posDown), downNewFluidState.method_15772())) {
                // 向下流动
                this.method_15745(world, posDown, stateDown, this.getVerticalFlowDirection(), downNewFluidState);

                // 四周有超过3个水源方块时向四周流动（？
                if (this.method_15740(world, pos) >= 3) {
                    this.method_15744(world, pos, state, blockState);
                }
            } else if (state.method_15771() || !this.canFlowVertical(world, downNewFluidState.method_15772(), pos, blockState, posDown, stateDown)) {
                // 无法向下流动时向四周流动
                // 水源在向下流动的1tick后向四周扩散
                // 水流则无法在向下流动的同时向四周扩散
                this.method_15744(world, pos, state, blockState);
            }
        }
    }

    @Override
    protected int method_15742(
            class_4538 world,
            class_2338 pos,
            int i,
            class_2350 direction,
            class_2680 state,
            class_2338 fromPos,
            Short2ObjectMap<Pair<class_2680, class_3610>> stateCache,
            Short2BooleanMap flowDownCache
    ) {
        int j = 1000;

        for (class_2350 direction2 : class_2350.class_2353.field_11062) {
            if (direction2 != direction) {
                class_2338 blockPos = pos.method_10093(direction2);
                short s = method_15747(fromPos, blockPos);
                Pair<class_2680, class_3610> pair = stateCache.computeIfAbsent(s, (Short2ObjectFunction<? extends Pair<class_2680, class_3610>>)(sx -> {
                    class_2680 blockStatex = world.method_8320(blockPos);
                    return Pair.of(blockStatex, blockStatex.method_26227());
                }));
                class_2680 blockState = pair.getFirst();
                class_3610 fluidState = pair.getSecond();
                if (this.method_15746(world, this.method_15750(), pos, state, direction2, blockPos, blockState, fluidState)) {
                    boolean bl = flowDownCache.computeIfAbsent(s, sx -> {
                        class_2338 blockPos2 = this.flowsUp() ? blockPos.method_10084() : blockPos.method_10074();
                        class_2680 blockState2 = world.method_8320(blockPos2);
                        return this.canFlowVertical(world, this.method_15750(), blockPos, blockState, blockPos2, blockState2);
                    });
                    if (bl) {
                        return i;
                    }

                    if (i < this.method_15733(world)) {
                        int k = this.method_15742(world, blockPos, i + 1, direction2.method_10153(), blockState, fromPos, stateCache, flowDownCache);
                        if (k < j) {
                            j = k;
                        }
                    }
                }
            }
        }

        return j;
    }

    @Override
    protected Map<class_2350, class_3610> method_15726(class_1937 world, class_2338 pos, class_2680 state) {
        int i = 1000;
        Map<class_2350, class_3610> map = Maps.newEnumMap(class_2350.class);
        Short2ObjectMap<Pair<class_2680, class_3610>> short2ObjectMap = new Short2ObjectOpenHashMap<>();
        Short2BooleanMap short2BooleanMap = new Short2BooleanOpenHashMap();

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 blockPos = pos.method_10093(direction);
            short s = method_15747(pos, blockPos);
            Pair<class_2680, class_3610> pair = short2ObjectMap.computeIfAbsent(s, (Short2ObjectFunction<? extends Pair<class_2680, class_3610>>)(sx -> {
                class_2680 blockStatex = world.method_8320(blockPos);
                return Pair.of(blockStatex, blockStatex.method_26227());
            }));
            class_2680 blockState = pair.getFirst();
            class_3610 fluidState = pair.getSecond();
            class_3610 fluidState2 = this.method_15727(world, blockPos, blockState);
            if (this.method_15746(world, fluidState2.method_15772(), pos, state, direction, blockPos, blockState, fluidState)) {
                class_2338 blockPos2 = this.flowsUp() ? blockPos.method_10084() : blockPos.method_10074();
                boolean bl = short2BooleanMap.computeIfAbsent(s, sx -> {
                    class_2680 blockState2 = world.method_8320(blockPos2);
                    return this.canFlowVertical(world, this.method_15750(), blockPos, blockState, blockPos2, blockState2);
                });
                int j;
                if (bl) {
                    j = 0;
                } else {
                    j = this.method_15742(world, blockPos, 1, direction.method_10153(), blockState, pos, short2ObjectMap, short2BooleanMap);
                }

                if (j < i) {
                    map.clear();
                }

                if (j <= i) {
                    map.put(direction, fluidState2);
                    i = j;
                }
            }
        }

        return map;
    }

    private boolean method_15746(
            class_1922 world, class_3611 fluid, class_2338 pos, class_2680 state, class_2350 face, class_2338 fromPos, class_2680 fromState, class_3610 fluidState
    ) {
        return !(this.method_15780(fluidState.method_15772()) && fluidState.method_15771())
                && ((FlowableFluidAccessor)this).invoke_receivesFlow(face, world, pos, state, fromPos, fromState)
                && ((FlowableFluidAccessor)this).invoke_canFill(world, fromPos, fromState, fluid);
    }
    private static short method_15747(class_2338 from, class_2338 to) {
        int i = to.method_10263() - from.method_10263();
        int j = to.method_10260() - from.method_10260();
        return (short)((i + 128 & 0xFF) << 8 | j + 128 & 0xFF);
    }

    @Override
    protected boolean method_15749(class_1922 world, class_2338 pos, class_2350 direction) {
        class_2680 blockState = world.method_8320(pos);
        class_3610 fluidState = world.method_8316(pos);
        if (fluidState.method_15772().method_15780(this)) {
            return false;
        } else if (direction == this.getVerticalFlowDirection().method_10153()) {
            return true;
        } else {
            return !(blockState.method_26204() instanceof class_2386) && blockState.method_26206(world, pos, direction);
        }
    }

    @Override
    public void method_15778(class_1937 world, class_2338 pos, class_3610 state) {
        FluidHelper.onScheduledTick(this, world, pos, state, this.method_15739(world));
    }

    @Override
    protected void method_15776(class_1937 world, class_2338 pos, class_3610 state, class_5819 random) {
        if (this.method_15791(class_3486.field_15518)) {
            ((class_3616)class_3612.field_15908).method_15776(world, pos, state, random);
        } else if (this.method_15791(class_3486.field_15517)) {
            ((class_3621)class_3612.field_15910).method_15776(world, pos, state, random);
        }
    }

    @Override
    public void method_15792(class_1937 world, class_2338 pos, class_3610 state, class_5819 random) {
        //着火
        if (this.settings.canSetFire() && world.method_8450().method_8355(class_1928.field_19387)) {
            int i = random.method_43048(3);
            if (i > 0) {
                class_2338 blockPos = pos;

                for (int j = 0; j < i; j++) {
                    blockPos = blockPos.method_10069(random.method_43048(3) - 1, 1, random.method_43048(3) - 1);
                    if (!world.method_8477(blockPos)) {
                        return;
                    }

                    class_2680 blockState = world.method_8320(blockPos);
                    if (blockState.method_26215()) {
                        if (this.canLightFire(world, blockPos)) {
                            world.method_8501(blockPos, class_4770.method_24416(world, blockPos));
                            return;
                        }
                    } else if (blockState.method_51366()) {
                        return;
                    }
                }
            } else {
                for (int k = 0; k < 3; k++) {
                    class_2338 blockPos2 = pos.method_10069(random.method_43048(3) - 1, 0, random.method_43048(3) - 1);
                    if (!world.method_8477(blockPos2)) {
                        return;
                    }

                    if (world.method_22347(blockPos2.method_10084()) && this.hasBurnableBlock(world, blockPos2)) {
                        world.method_8501(blockPos2.method_10084(), class_4770.method_24416(world, blockPos2));
                    }
                }
            }
        }
    }

    private boolean canLightFire(class_4538 world, class_2338 pos) {
        for (class_2350 direction : class_2350.values()) {
            if (this.hasBurnableBlock(world, pos.method_10093(direction))) {
                return true;
            }
        }

        return false;
    }

    private boolean hasBurnableBlock(class_4538 world, class_2338 pos) {
        return (pos.method_10264() < world.method_31607() || pos.method_10264() >= world.method_31600() || world.method_22340(pos)) && world.method_8320(pos).method_50011();
    }

    private void playExtinguishEvent(class_1936 world, class_2338 pos) {
        world.method_20290(class_6088.field_31138, pos, 0);
    }

    /**
     * Check how many source blocks are neighboring
     * @see class_3609#method_15740(class_4538, class_2338) 
     */
    public int method_15740(class_4538 world, class_2338 pos) {
        int adjacentSources = 0;
        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 adjacentPos = pos.method_10093(direction);
            class_3610 adjacentFluid = world.method_8316(adjacentPos);
            if (this.method_15752(adjacentFluid)) {
                adjacentSources++;
            }
        }
        return adjacentSources;
    }

    /**
     * If the fluid state is of this fluid and is still
     * @see class_3609#method_15752(class_3610)
     */
    public boolean method_15752(class_3610 state) {
        return state.method_15772().method_15780(this) && state.method_15771();
    }

    /**
     * @see class_3609#method_15744(class_1937, class_2338, class_3610, class_2680)
     */
    public void method_15744(class_1937 world, class_2338 pos, class_3610 sourceFluid, class_2680 sourceState) {
        int adjacentAmount = sourceFluid.method_15761() - this.method_15739(world);
        if (sourceFluid.method_11654(field_15902)) {
            // 从上方流下，可向周围扩散
            adjacentAmount = 7;
        }
        if (adjacentAmount > 0) {
            // 计算向周围流动
            final Map<class_2350, class_3610> map = this.method_15726(world, pos, sourceState);
            for (Map.Entry<class_2350, class_3610> entry : map.entrySet()) {
                final class_2350 direction = entry.getKey();
                final class_3610 spreadFluid = entry.getValue();
                final class_2338 destPos = pos.method_10093(direction);
                final class_2680 destState = world.method_8320(destPos);
                if (this.method_15738(world, pos, sourceState, direction, destPos, destState, world.method_8316(destPos), spreadFluid.method_15772())) {
                    this.method_15745(world, destPos, destState, direction, spreadFluid);
                }
            }
        }
    }

    /**
     * @see class_3609#method_15736(class_1922, class_3611, class_2338, class_2680, class_2338, class_2680)
     */
    private boolean canFlowVertical(class_1922 world, class_3611 fluid, class_2338 pos, class_2680 state, class_2338 fromPos, class_2680 fromState) {
        if (!((FlowableFluidAccessor)this).invoke_receivesFlow(this.getVerticalFlowDirection(), world, pos, state, fromPos, fromState)) {
            return false;
        } else {
            return fromState.method_26227().method_15772().method_15780(this) || ((FlowableFluidAccessor)this).invoke_canFill(world, fromPos, fromState, fluid);
        }
    }
}
