package rc55.mc.rfapi.fluid;

import net.minecraft.class_1308;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_1959;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_4538;
import net.minecraft.class_6088;
import net.minecraft.class_6862;
import net.minecraft.world.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import rc55.mc.rfapi.RFApiConfigs;
import rc55.mc.rfapi.event.FluidReplacementEvent;
import rc55.mc.rfapi.event.FluidScheduledTickEvent;
import rc55.mc.rfapi.fluid.reaction.FluidReactionType;
import rc55.mc.rfapi.fluid.reaction.IFluidReaction;
import rc55.mc.rfapi.mixin.FlowableFluidAccessor;

import java.util.function.Predicate;

/**
 * This holds some methods used for triggering fluid reactions
 * Do not call them outside of fluid flowing logics
 */
public class FluidHelper {
    /**
     * Calculates if a fluid can flow "into" another fluid(treat that fluid like air and flow through)
     * This handles {@link FluidReactionType#FLOW_INTO} logics so it needs to be hooked to vanilla fluids
     * Here we extract it into a static method so we can perform the hook with {@linkplain rc55.mc.rfapi.mixin.FluidStateMixin#fluidlib$hookCustomFlowIntoLogic(Fluid, FluidState, BlockView, BlockPos, Fluid, Direction) mixins}
     * @param self The fluid instance which tries to call this method
     * @param state Fluid state to flow into
     * @param world World instance
     * @param pos Pos to flow into
     * @param fluid The fluid type to flow into
     * @param direction Flowing direction of the fluid
     * @return Whether the fluid to flow into can be replaced
     * @see class_3609#method_15777(class_3610, class_1922, class_2338, class_3611, class_2350) 
     */
    @ApiStatus.Internal
    public static boolean canBeReplacedWith(class_3611 self, class_3610 state, class_1922 world, class_2338 pos, class_3611 fluid, class_2350 direction) {
        // Set the result on event
        switch (FluidReplacementEvent.EVENT.invoker().onFluidReplacement(self, state, world, pos, fluid, direction)) {
            case TRUE: return true;
            case FALSE: return false;
        }

        if (state.method_15769()) return true;
        if (self.method_15780(fluid)) return false;
        if (world instanceof class_1936) {
            IFluidReaction.triggerReaction(FluidReactionType.FLOW_INTO, (class_1936) world, pos.method_10093(direction.method_10153()), pos);
        }
        return false;
    }

    /**
     * Calculates new fluid state while fluids tries to flow to another position
     * This also handles custom source conversion logics so it needs to be hooked to vanilla fluids
     * Here we extract it into a static method so we can perform the hook with {@linkplain rc55.mc.rfapi.mixin.FlowableFluidMixin#fluidlib$hookCustomSourceConversion(World, BlockPos, BlockState, CallbackInfoReturnable) mixins}
     * @param self The fluid instance which tries to call this method
     * @param world World instance
     * @param pos Pos to flow into
     * @param state Block state used to be there in the pos to flow into
     * @param levelDecreasePerBlock See {@link class_3609#method_15739(class_4538)}
     * @return New fluid state
     * @see class_3609#method_15727(class_1937, class_2338, class_2680)
     */
    @ApiStatus.Internal
    public static class_3610 getUpdatedState(class_3609 self, class_1937 world, class_2338 pos, class_2680 state, int levelDecreasePerBlock) {
        final FluidSettings settings = FluidSettings.get(self);
        int i = 0;
        int neighboringSourceCount = 0;

        for (class_2350 direction : class_2350.class_2353.field_11062) {
            class_2338 sidePos = pos.method_10093(direction);
            class_2680 sideState = world.method_8320(sidePos);
            class_3610 sideFluidState = sideState.method_26227();
            if (((FlowableFluidAccessor) self).invoke_receivesFlow(direction, world, pos, state, sidePos, sideState)) {
                if (sideFluidState.method_15772().method_15780(self)) {
                    if (sideFluidState.method_15771()) {
                        neighboringSourceCount++;
                    }

                    i = Math.max(i, sideFluidState.method_15761());
                } else if (self.method_15793(state.method_26227()) && sideFluidState.method_15771()) {
                    class_2680 conversionResult = IFluidReaction.triggerReaction(FluidReactionType.SOURCE_CONVERSION, world, sidePos, pos);
                    if (conversionResult != null) {
                        return conversionResult.method_26227();
                    }
                }
            }
        }

        if (settings.isInfinite(world) && neighboringSourceCount >= 2) {
            class_2680 bottomState = world.method_8320(settings.flowsUp() ? pos.method_10084() : pos.method_10074());
            class_3610 bottomFluidState = bottomState.method_26227();
            if (bottomState.method_51367() || (self.method_15780(bottomFluidState.method_15772()) && bottomFluidState.method_15771())) {
                //新水源方块（无限水）
                return self.method_15729(false);
            }
        }

        class_2338 upPos = settings.flowsUp() ? pos.method_10074() : pos.method_10084();
        class_2680 topState = world.method_8320(upPos);
        class_3610 topFluidState = topState.method_26227();

        if (!topFluidState.method_15769()
                && topFluidState.method_15772().method_15780(self)
                && ((FlowableFluidAccessor) self).invoke_receivesFlow(settings.flowsUp() ? class_2350.field_11033 : class_2350.field_11036, world, pos, state, upPos, topState)
        ) {
            //向下
            return self.method_15728(8, true);
        } else {
            //向四周
            int k = i - levelDecreasePerBlock;
            return k <= 0 ? class_3612.field_15906.method_15785() : self.method_15728(k, false);
        }
    }

    /**
     * Called when the fluid receives a scheduled tick
     * This handles {@link FluidReactionType#INFECTION} logics so it needs to be hooked to vanilla fluids
     * Here we extract it into a static method so we can perform the hook with {@linkplain rc55.mc.rfapi.mixin.FlowableFluidMixin#method_15778(class_1937, class_2338, class_3610) mixins}
     * @param self The fluid instance which tries to call this method
     * @param world World instance
     * @param pos Pos to update
     * @param state Fluid state used to be in the pos
     * @param levelDecreasePerBlock See {@link class_3609#method_15739(class_4538)}
     * @see class_3611#method_15778(class_1937, class_2338, class_3610)
     */
    @ApiStatus.Internal
    public static void onScheduledTick(class_3609 self, class_1937 world, class_2338 pos, class_3610 state, int levelDecreasePerBlock) {
        // Do nothing if fluid updates are not allowed
        if (!RFApiConfigs.getInstance().fluidUpdates) {
            return;
        }

        // Cancel further actions on event
        if (FluidScheduledTickEvent.EVENT.invoker().onScheduledTick(
                self, world, pos, state, levelDecreasePerBlock, ((FlowableFluidAccessor)self).invoke_getNextTickDelay(world, pos, state, state))
        ) {
            return;
        }

        boolean infection = false;
        for (class_2350 direction : class_2350.values()) {
            final class_2338 targetPos = pos.method_10093(direction);
            class_2680 infected = IFluidReaction.triggerReaction(FluidReactionType.INFECTION, world, pos, targetPos);
            if (infected != null) {
                infection = true;
                world.method_39281(targetPos, infected.method_26227().method_15772(), ((FlowableFluidAccessor)self).invoke_getNextTickDelay(world, targetPos, state, infected.method_26227()));
                world.method_8452(targetPos, infected.method_26204());
            }
        }
        if (infection) return;

        // Vanilla tick
        if (!state.method_15771()) {
            class_3610 fluidState = getUpdatedState(self, world, pos, world.method_8320(pos), levelDecreasePerBlock);
            int i = ((FlowableFluidAccessor)self).invoke_getNextTickDelay(world, pos, state, fluidState);
            if (fluidState.method_15769()) {
                state = fluidState;
                world.method_8652(pos, class_2246.field_10124.method_9564(), class_2248.field_31036);
            } else if (!fluidState.equals(state)) {
                state = fluidState;
                class_2680 blockState = fluidState.method_15759();
                world.method_8652(pos, blockState, class_2248.field_31028);
                world.method_39281(pos, fluidState.method_15772(), i);
                world.method_8452(pos, blockState.method_26204());
            }
        }

        ((FlowableFluidAccessor)self).invoke_tryFlow(world, pos, state);
    }

    public static void playExtinguishEvent(class_1936 world, class_2338 pos) {
        world.method_20290(class_6088.field_31138, pos, 0);
    }

    /**
     * Applied to entity movement/navigation checks
     * @param fluid The fluid
     * @param tag What vanilla tag should be applied by where it's called from
     * @return If the check is success
     */
    @ApiStatus.Internal
    public static boolean checkEntityMoveAction(class_3611 fluid, class_6862<class_3611> tag) {
        final FluidSettings settings = fluid.getSettings();
        if (tag == net.minecraft.class_3486.field_15517 || tag == FluidTags.DUMMY_WATER_PHYSICS_TAG) {
            return settings.getMovementType() == FluidSettings.EntityMovementType.WATER;
        } else if (tag == net.minecraft.class_3486.field_15518 || tag == FluidTags.DUMMY_LAVA_PHYSICS_TAG) {
            return settings.getMovementType() == FluidSettings.EntityMovementType.LAVA;
        }
        return fluid.method_15791(tag);
    }

    public static boolean checkCanMobSwim(class_1308 mob) {
        return mob.method_5861(FluidTags.DUMMY_WATER_PHYSICS_TAG) > mob.method_29241()
                || mob.method_5861(FluidTags.DUMMY_LAVA_PHYSICS_TAG) > 0.;
    }

    /**
     * Gets the still form of the given fluid
     */
    public static class_3611 trim(class_3611 fluid) {
        if (fluid instanceof class_3609) {
            return ((class_3609) fluid).method_15751();
        }
        return fluid;
    }

    public static boolean canSetIce(class_4538 world, class_2338 pos, Predicate<class_3611> predicate, boolean doWaterCheck) {
        class_1959 biome = world.method_23753(pos).comp_349();
        if (!biome.method_39927(pos)) {
            if (pos.method_10264() >= world.method_31607() && pos.method_10264() < world.method_31600() && world.method_8314(class_1944.field_9282, pos) < 10) {
                class_2680 blockState = world.method_8320(pos);
                if (blockState.method_26204() instanceof class_2404 && predicate.test(blockState.method_26227().method_15772())) {
                    if (!doWaterCheck) {
                        return true;
                    }

                    for (final class_2350 direction : class_2350.class_2353.field_11062) {
                        if (!predicate.test(world.method_8316(pos.method_10093(direction)).method_15772())) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    public static class_2248 getBlockForFluid(@Nullable class_3611 fluid) {
        return fluid == null ? class_2246.field_10124 : fluid.method_15785().method_15759().method_26204();
    }

    public static String getTranslationKey(@Nullable class_3611 fluid) {
        return getBlockForFluid(fluid).method_9539();
    }

    public static String getTranslationKey(@Nullable FluidReference<?> fluid) {
        return fluid == null ? class_2246.field_10124.method_9539() : fluid.getTranslationKey();
    }

    public static class_2561 getName(@Nullable class_3611 fluid) {
        return getBlockForFluid(fluid).method_9518();
    }

    public static class_2561 getName(@Nullable FluidReference<?> fluid) {
        return fluid == null ? class_2246.field_10124.method_9518() : class_2561.method_43471(getTranslationKey(fluid));
    }
}
