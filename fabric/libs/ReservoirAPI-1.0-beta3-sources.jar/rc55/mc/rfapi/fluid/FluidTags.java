package rc55.mc.rfapi.fluid;

import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_7924;
import org.jetbrains.annotations.ApiStatus;
import rc55.mc.rfapi.RFApiMain;

public class FluidTags {
    /**
     * The vanilla water tag
     */
    public static final class_6862<class_3611> WATER = net.minecraft.class_3486.field_15517;

    /**
     * The vanilla lava tag
     */
    public static final class_6862<class_3611> LAVA = net.minecraft.class_3486.field_15518;

    /**
     * Whether corals can keep alive in these fluids
     */
    public static final class_6862<class_3611> CORAL_SURVIVES = ofConventional("coral_survives");

    /**
     * Whether players can catch fish in these fluids
     */
    public static final class_6862<class_3611> HAS_FISHES = ofConventional("has_fishes");

    /**
     * Marks fluids that cannot be placed in ultrawarm worlds(e.g. vanilla nether)
     */
    public static final class_6862<class_3611> DISAPPEAR_IN_ULTRAWARM = ofConventional("disappear_in_ultrawarm");

    /**
     * Still factor of the fluid
     */
    public static final class_6862<class_3611> STILL = ofConventional("still");

    /**
     * Flowing factor of the fluid
     */
    public static final class_6862<class_3611> FLOWING = ofConventional("flowing");

    public static class_6862<class_3611> of(class_2960 id) {
        return class_6862.method_40092(class_7924.field_41270, id);
    }

    public static class_6862<class_3611> ofConventional(String id) {
        return of(class_2960.method_43902("c", id));
    }

    private static class_6862<class_3611> ofDummy(String name) {
        return of(class_2960.method_43902(RFApiMain.MODID, "dummy/" + name));
    }

    @ApiStatus.Internal
    public static final class_6862<class_3611> DUMMY_WATER_PHYSICS_TAG = ofDummy("water_physics");

    @ApiStatus.Internal
    public static final class_6862<class_3611> DUMMY_LAVA_PHYSICS_TAG = ofDummy("lava_physics");

    @ApiStatus.Internal
    public static final class_6862<class_3611> DUMMY_UNBREATHABLE_TAG = ofDummy("unbreathable");
}
