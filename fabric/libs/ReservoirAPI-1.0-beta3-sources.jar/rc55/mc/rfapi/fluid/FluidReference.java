package rc55.mc.rfapi.fluid;

import com.google.common.collect.Interner;
import com.google.common.collect.Interners;
import net.minecraft.class_2248;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_3616;
import net.minecraft.class_3619;
import net.minecraft.class_3621;
import net.minecraft.class_4970;
import net.minecraft.class_7923;
import net.minecraft.fluid.*;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.function.Function;

/**
 * Reference of a specific type of fluid
 * This will hold it's still, flowing, block factor
 * @param <T> Class type of the fluid
 */
public class FluidReference<T extends class_3609> {
    private static final Interner<FluidReference<?>> INTERNER = Interners.newWeakInterner();

    private final class_2960 stillId, flowId, blockId;
    private T still, flowing;
    private class_2248 block;
    private final FluidSettings settings;

    public FluidReference(class_2960 stillId, class_2960 flowId, class_2960 blockId, Function<FluidReference<T>, FluidSettings.Builder> settingsProvider) {
        this.stillId = stillId;
        this.flowId = flowId;
        this.blockId = blockId;
        this.settings = settingsProvider.apply(this).block(this::getBlock).build();
    }

    @ApiStatus.Internal
    @SuppressWarnings("unchecked")
    protected FluidReference(@NotNull T fluid) {
        this.still = (T) fluid.method_15751();
        this.stillId = FluidRegistry.getId(this.still);
        this.flowing = (T) fluid.method_15750();
        this.flowId = FluidRegistry.getId(this.flowing);
        this.block = fluid.method_15785().method_15759().method_26204();
        this.blockId = class_7923.field_41175.method_10221(this.block);
        this.settings = FluidSettings.get(fluid);
    }

    /**
     * Create a reference for an existing fluid
     * @param fluid Fluid instance, can be either still or flow
     */
    @SuppressWarnings("unchecked")
    public static <T extends class_3609> FluidReference<T> of(T fluid) {
        return (FluidReference<T>) INTERNER.intern(new FluidReference<>(fluid));
    }

    /**
     * Reference for {@linkplain class_3612#field_15910 vanilla water}
     */
    public static final FluidReference<class_3621> VANILLA_WATER = of((class_3621) class_3612.field_15910);

    /**
     * Reference for {@linkplain class_3612#field_15908 vanilla lava}
     */
    public static final FluidReference<class_3616> VANILLA_LAVA = of((class_3616) class_3612.field_15908);

    void onRegister(T still, T flowing, class_2248 block) {
        this.still = still;
        this.flowing = flowing;
        this.block = block;
        INTERNER.intern(this);
    }

    @SuppressWarnings("unchecked")
    public T getStill() {
        return this.still == null ? (this.still = (T) FluidRegistry.get(this.stillId)) : this.still;
    }

    public class_2960 getStillId() {
        return this.stillId;
    }

    @SuppressWarnings("unchecked")
    public T getFlowing() {
        return this.flowing == null ? (this.flowing = (T) FluidRegistry.get(this.flowId)) : this.flowing;
    }

    public class_2960 getFlowingId() {
        return this.flowId;
    }

    public class_2248 getBlock() {
        return this.block == null ? (this.block = class_7923.field_41175.method_10223(this.blockId)) : this.block;
    }

    public class_2960 getBlockId() {
        return blockId;
    }

    public String getTranslationKey() {
        return this.getBlock().method_9539();
    }

    public FluidSettings getSettings() {
        return settings;
    }

    @ApiStatus.Internal
    class_4970.class_2251 createBlockSettings() {
        class_4970.class_2251 settings = class_4970.class_2251.method_9637()
                .method_51371()
                .method_9634()
                .method_9632(100.0F)
                .method_50012(class_3619.field_15971)
                .method_42327()
                .method_51177()
                .method_9626(class_2498.field_44608)
                .method_9631(this.settings::getLight)
                .method_31710(this.settings.getMapColor());
        if (this.settings.hasRandomTick()) {
            settings.method_9640();
        }
        return settings;
    }

    public boolean isOf(@Nullable class_3611 fluid) {
        return fluid != null && (fluid == this.getStill() || fluid == this.getFlowing());
    }

    public boolean isOf(@Nullable FluidReference<?> fluid) {
        return fluid != null && fluid.getStillId().equals(this.getStillId()) && fluid.getFlowingId().equals(this.getFlowingId());
    }

    /**
     * Checks if the given fluid is of this type and is still
     */
    public boolean matchesAndStill(@Nullable class_3611 fluid) {
        return fluid != null && this.isOf(fluid) && fluid == FluidHelper.trim(fluid);
    }

    @Override
    public int hashCode() {
        return FluidRegistry.getRawId(this.getStill());
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (obj == null) {
            return false;
        } else if (obj instanceof FluidReference<?>) {
            return this.isOf((FluidReference<?>) obj);
        } else {
            return false;
        }
    }
}
