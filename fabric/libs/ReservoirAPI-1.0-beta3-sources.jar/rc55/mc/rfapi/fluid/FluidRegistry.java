package rc55.mc.rfapi.fluid;

import net.fabricmc.fabric.api.registry.LandPathNodeTypesRegistry;
import net.minecraft.class_2378;
import net.minecraft.class_2404;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_3611;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * <h1>Fluid registry helper</h1>
 * <p>
 * Reservoir API provides its own way to register/manage fluids.
 * </p>
 * <p>
 * In vanilla, you should override some methods in
 * {@link class_3611} to determine certain property for the fluid.
 * Normally it's acceptable if your mod only has a few simple fluids,
 * but may be tricky when your mod needs to register a lot of fluids,
 * or your fluids has custom logics in multiple ways.
 * </p>
 * <p>
 * So in Reservoir, we will instead use our own {@link ExtendedFluid}
 * and pass in a {@link FluidSettings} which will automatically determine
 * properties for the fluid and handles both still/flowing factor.
 * <br/>
 * Here we use a {@link FluidReference} to evaluate fluids lazily by caching their id and get
 * them from the registry when necessary.
 * </p>
 * <p>
 * Here is a simple example for registering a fluid with custom fluid block and given name:
 * <pre>{@code
 * // In your common init code
 * FluidReference<ExtendedFluid> TEST_FLUID = FluidRegistry.register(
 *     new Identifier(MODID, "test_fluid"),
 *     ExtendedFluid::ofStill,
 *     ExtendedFluid::ofFlowing,
 *     CustomFluidBlock::new,
 *     ref -> FluidSettings.waterLike().bucketItem(() -> TEST_FLUID_BUCKET)
 * );
 *
 * // In your client init code
 * // In this case still texture will be assets/modid/textures/block/test_fluid_still.png
 * TEST_STILL_TEX_ID = new Identifier(MODID, "block/test_fluid_still");
 * TEST_FLOW_TEX_ID = new Identifier(MODID, "blocks/test_fluid_flowing");
 * FluidRenderRegistry.register(TEST_FLUID, TEST_STILL_TEX_ID, TEST_FLOW_TEX_ID, null);
 * }</pre>
 * </p>
 * @see FluidSettings
 */
public final class FluidRegistry {
    private FluidRegistry() {
    }

    public static FluidReference<ExtendedFluid> registerSimple(class_2960 id, FluidSettings.Builder settings) {
        return register(id, ExtendedFluid::ofStill, ExtendedFluid::ofFlowing, ref -> settings);
    }

    public static <T extends class_3609> FluidReference<T> register(
            class_2960 id,
            BiFunction<FluidSettings, FluidReference<T>, T> stillFactory,
            BiFunction<FluidSettings, FluidReference<T>, T> flowingFactory,
            Function<FluidReference<T>, FluidSettings.Builder> settings
    ) {
        return register(id, stillFactory, flowingFactory, class_2404::new, settings);
    }

    public static <F extends class_3609, B extends class_2404> FluidReference<F> register(
            class_2960 id,
            BiFunction<FluidSettings, FluidReference<F>, F> stillFactory,
            BiFunction<FluidSettings, FluidReference<F>, F> flowingFactory,
            BiFunction<F, class_4970.class_2251, B> blockFactory,
            Function<FluidReference<F>, FluidSettings.Builder> settings
    ) {
        final class_2960 stillId = class_2960.method_43902(id.method_12836(), id.method_12832() + "/still");
        final class_2960 flowId = class_2960.method_43902(id.method_12836(), id.method_12832() + "/flowing");
        return register(stillId, flowId, id, stillFactory, flowingFactory, blockFactory, settings);
    }

    public static <F extends class_3609, B extends class_2404> FluidReference<F> register(
            class_2960 stillId,
            class_2960 flowId,
            class_2960 blockId,
            BiFunction<FluidSettings, FluidReference<F>, F> stillFactory,
            BiFunction<FluidSettings, FluidReference<F>, F> flowingFactory,
            BiFunction<F, class_4970.class_2251, B> blockFactory,
            Function<FluidReference<F>, FluidSettings.Builder> settings
    ) {
        return register(stillId, flowId, blockId, stillFactory, flowingFactory, blockFactory, settings, Function.identity());
    }

    /**
     * Register a fluid with a customized block, still, flowing factor and block settings
     * @param stillId ID for the still factor
     * @param flowId ID for the flowing factor
     * @param blockId ID for the fluid block
     * @param stillFactory Object factory used to create customized still fluid object
     * @param flowingFactory Object factory used to create customized flowing fluid object
     * @param blockFactory Object factory used to create customized fluid block
     * @param settings The fluid settings builder
     * @param blockSettingsAdapter A function that allows you to customize some
     *                             block settings on top of the automatically
     *                             created one, see {@linkplain FluidReference#createBlockSettings() how the settings was created}
     * @return The fluid reference
     * @param <F> The fluid type
     * @param <B> The fluid block type
     */
    public static <F extends class_3609, B extends class_2404> FluidReference<F> register(
            class_2960 stillId,
            class_2960 flowId,
            class_2960 blockId,
            BiFunction<FluidSettings, FluidReference<F>, F> stillFactory,
            BiFunction<FluidSettings, FluidReference<F>, F> flowingFactory,
            BiFunction<F, class_4970.class_2251, B> blockFactory,
            Function<FluidReference<F>, FluidSettings.Builder> settings,
            Function<class_4970.class_2251, ? extends class_4970.class_2251> blockSettingsAdapter
    ) {
        final FluidReference<F> reference = new FluidReference<>(stillId, flowId, blockId, settings);
        F still = register(stillId, stillFactory.apply(reference.getSettings(), reference));
        F flow = register(flowId, flowingFactory.apply(reference.getSettings(), reference));
        FluidSettings.register(reference);
        B block = registerFluidBlock(blockId, reference, blockFactory, blockSettingsAdapter);

        reference.onRegister(still, flow, block);

        LandPathNodeTypesRegistry.register(block, (state, neighbor) -> switch (reference.getSettings().getMovementType()) {
            case WATER -> class_7.field_18;
            case LAVA -> class_7.field_14;
            default -> class_7.field_7;
        });

        return reference;
    }

    private static <T extends class_3611> T register(class_2960 id, T fluid) {
        return class_2378.method_10230(class_7923.field_41173, id, fluid);
    }

    private static <F extends class_3609, B extends class_2404> B registerFluidBlock(
            class_2960 id,
            FluidReference<F> fluid,
            BiFunction<F, class_4970.class_2251, B> blockFactory,
            Function<class_4970.class_2251, ? extends class_4970.class_2251> settingsAdapter
    ) {
        return class_2378.method_10230(class_7923.field_41175, id, blockFactory.apply(fluid.getStill(), settingsAdapter.apply(fluid.createBlockSettings())));
    }

    public static class_5321<class_3611> keyFor(class_2960 id) {
        return class_5321.method_29179(class_7924.field_41270, id);
    }

    public static class_3611 get(class_2960 id) {
        return class_7923.field_41173.method_10223(id);
    }

    public static class_3611 get(String id) {
        return get(class_2960.method_12829(id));
    }

    public static class_3611 get(int rawId) {
        return class_7923.field_41173.method_10200(rawId);
    }

    public static class_3611 get(class_5321<class_3611> key) {
        return class_7923.field_41173.method_29107(key);
    }

    public static class_2960 getId(class_3611 fluid) {
        return class_7923.field_41173.method_10221(fluid);
    }

    public static int getRawId(class_3611 fluid) {
        return class_7923.field_41173.method_10206(fluid);
    }

    public static Stream<class_3611> stream() {
        return class_7923.field_41173.method_10220();
    }

    public static Stream<class_3611> stream(Predicate<? super class_3611> predicate) {
        return stream().filter(predicate);
    }
}
