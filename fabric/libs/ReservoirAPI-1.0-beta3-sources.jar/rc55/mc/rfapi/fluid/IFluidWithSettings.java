package rc55.mc.rfapi.fluid;

import net.minecraft.class_3611;
import org.jetbrains.annotations.ApiStatus;

/**
 * Provides settings for the fluid
 * Will be injected to {@link net.minecraft.class_3611}
 */
@ApiStatus.NonExtendable
public interface IFluidWithSettings {
    default FluidSettings getSettings() {
        return FluidSettings.get((class_3611) this);
    }
}
