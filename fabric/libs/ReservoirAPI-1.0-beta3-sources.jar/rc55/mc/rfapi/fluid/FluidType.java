package rc55.mc.rfapi.fluid;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;
import java.util.function.Predicate;

/**
 * Represents a certain amount of fluid. This works similar to vanilla {@link class_1799}
 * Use {@link #equals(Object)} to compare them, and use {@link #isOf(FluidType)} to only compare type of the fluid
 */
public class FluidType implements Comparable<FluidType> {
    private final class_3611 fluid;
    private int amount;

    public FluidType(@NotNull class_3611 fluid, int amount) {
        this.fluid = FluidHelper.trim(fluid);
        this.amount = amount;
    }
    public FluidType(FluidReference<?> fluid, int amount) {
        this(fluid.getStill(), amount);
    }
    public FluidType(@NotNull String fluid, int amount) {
        this(FluidRegistry.get(fluid), amount);
    }
    public FluidType(@NotNull class_2960 fluid, int amount) {
        this(FluidRegistry.get(fluid), amount);
    }
    public FluidType(int fluid, int amount) {
        this(FluidRegistry.get(fluid), amount);
    }

    /**
     * Create from NBT
     */
    public static FluidType fromNbt(class_2487 nbt) {
        String id = nbt.method_10558("id");
        int amount = nbt.method_10550("amount");
        return nbt.method_33133() || id.isEmpty() || amount <= 0 ? EMPTY : new FluidType(id, amount);
    }

    /// Empty
    public static final FluidType EMPTY = new FluidType(class_3612.field_15906, 0);

    public static final Codec<FluidType> CODEC = RecordCodecBuilder.create(i -> i.group(
            class_7923.field_41173.method_39673().fieldOf("id").forGetter(t -> t.fluid),
            Codec.INT.fieldOf("amount").forGetter(t -> t.amount)
    ).apply(i, FluidType::new));

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        } else if (obj == null) {
            return false;
        } else if (obj instanceof FluidType type) {
            if (type.fluid == this.fluid && type.amount == this.amount) {
                return true;
            }
        }
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.fluid, this.amount);
    }

    @Override
    public String toString() {
        return this.isEmpty() ? "FluidType[EMPTY]" : String.format("FluidType[Fluid=%s,Amount=%d]", this.getFluidId(), this.amount);
    }

    @Override
    public int compareTo(@NotNull FluidType fluidType) {
        return this.getAmount() - fluidType.getAmount();
    }

    /// If it is empty
    public boolean isEmpty() {
        return this.fluid == null || this.fluid == class_3612.field_15906 || this.amount <= 0;
    }
    /// Stored fluid
    public class_3611 getFluid() {
        return this.isEmpty() ? class_3612.field_15906 : this.fluid;
    }
    /// Stored fluid id
    public String getFluidId() {
        return this.isEmpty() ? "" : FluidRegistry.getId(this.getFluid()).toString();
    }
    public int getFluidRawId() {
        return this.isEmpty() ? -1 : FluidRegistry.getRawId(this.getFluid());
    }
    /// Stored fluid amount (mB)
    public int getAmount() {
        return this.isEmpty() ? 0 : this.amount;
    }

    public long getFabricAmount() {
        return (long) this.getAmount() * (FluidConstants.BUCKET / 1000L);
    }

    public boolean isOf(class_3611 fluid) {
        return this.getFluid().method_15780(fluid);
    }
    public boolean isOf(FluidType type) {
        return type != null && this.isOf(type.getFluid());
    }
    public boolean isOf(FluidReference<?> fluid) {
        return fluid != null && fluid.isOf(this.fluid);
    }
    public boolean isIn(class_6862<class_3611> tag) {
        return this.getFluid().method_15791(tag);
    }

    public boolean matches(Predicate<class_3611> predicate) {
        return predicate.test(this.fluid);
    }

    /**
     * Serialize this to a compound tag
     */
    public class_2487 asNbt() {
        class_2487 nbt = new class_2487();
        if (!this.isEmpty()) {
            nbt.method_10582("id", this.getFluidId());
            nbt.method_10569("amount", this.amount);
        }
        return nbt;
    }

    /**
     * @see class_1799#method_7972()
     */
    public FluidType copy() {
        if (this.isEmpty()) return EMPTY;
        return new FluidType(this.fluid, this.amount);
    }

    /**
     * @see class_1799#method_46651(int)
     */
    public FluidType copyWithCount(int i) {
        if (this.isEmpty()) return EMPTY;
        return this.copy().setAmount(i);
    }

    /**
     * @see class_1799#method_51164()
     */
    public FluidType copyAndEmpty() {
        if (this.isEmpty()) return EMPTY;
        FluidType newType = this.copy();
        this.setAmount(0);
        return newType;
    }

    /**
     * @see class_1799#method_7971(int)
     */
    public FluidType split(int i) {
        int amount = Math.min(this.getAmount(), i);
        FluidType remain = this.copyWithCount(amount);
        this.decrease(amount);
        return remain;
    }

    /**
     * @see class_1799#method_7939(int)
     */
    public FluidType setAmount(int amount) {
        this.amount = Math.max(0, amount);
        return this;
    }

    /**
     * @see class_1799#method_7933(int)
     */
    public FluidType increase(int amount) {
        return this.setAmount(this.getAmount() + amount);
    }

    /**
     * @see class_1799#method_7934(int)
     */
    public FluidType decrease(int amount) {
        return this.increase(-amount);
    }
}
