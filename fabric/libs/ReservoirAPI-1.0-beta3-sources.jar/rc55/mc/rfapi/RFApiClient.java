package rc55.mc.rfapi;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.class_1755;
import net.minecraft.class_2561;
import rc55.mc.rfapi.fluid.FluidSettings;
import rc55.mc.rfapi.item.ExtendedBucketItem;

import java.util.function.Consumer;

public class RFApiClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, tooltipContext, list) -> {
            if (stack.method_7909() instanceof class_1755 bucket) {
                if (!tooltipContext.method_8035()) return;
                if (ExtendedBucketItem.isEmpty(stack)) {
                    if (ExtendedBucketItem.getMaxTemperature(stack) >= 0) {
                        displayTemperature(list::add, "tooltip.reservoir-api.bucket.max_temperature", ExtendedBucketItem.getMaxTemperature(stack));
                    } else {
                        list.add(class_2561.method_43471("tooltip.reservoir-api.bucket.unlimited_max_temperature"));
                    }
                } else {
                    displayTemperature(list::add, "tooltip.reservoir-api.bucket.temperature", FluidSettings.get(bucket.field_7905).getTemperature());
                }
            }
        });
    }

    public static void displayTemperature(Consumer<class_2561> text, String translationKey, int temperature) {
        text.accept(class_2561.method_43469(translationKey, temperature, temperature - 273));
    }
}
