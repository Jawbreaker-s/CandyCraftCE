package rc55.mc.rfapi.entity;

import org.jetbrains.annotations.ApiStatus;

import java.util.function.Predicate;
import net.minecraft.class_3611;

/**
 * Provides entity collision for fluids
 * Will be automatically injected to {@link net.minecraft.class_1297}
 */
@ApiStatus.NonExtendable
public interface IFluidCollidable {
    default boolean isTouchingFluid(Predicate<class_3611> predicate) {
        return false;
    }
}
