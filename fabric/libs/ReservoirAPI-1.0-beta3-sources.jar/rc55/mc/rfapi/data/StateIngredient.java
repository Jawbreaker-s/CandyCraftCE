package rc55.mc.rfapi.data;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2688;
import net.minecraft.class_3610;
import net.minecraft.class_3611;

public class StateIngredient implements Predicate<class_2688<?, ?>> {
    private final BlockIngredient validBlocks;
    private final FluidIngredient validFluids;

    protected StateIngredient(@NotNull BlockIngredient validBlocks, @NotNull FluidIngredient validFluids) {
        this.validBlocks = validBlocks;
        this.validFluids = validFluids;
    }

    public StateIngredient(Optional<@Nullable BlockIngredient> validBlocks, Optional<@Nullable FluidIngredient> validFluids) {
        this(validBlocks.orElse(BlockIngredient.EMPTY), validFluids.orElse(FluidIngredient.EMPTY));
    }

    public static StateIngredient fromBlocks(@Nullable BlockIngredient validBlocks) {
        return new StateIngredient(Optional.ofNullable(validBlocks), Optional.empty());
    }

    public static StateIngredient fromBlocks(@NotNull BlockIngredient.Builder builder) {
        return fromBlocks(builder.build());
    }

    public static StateIngredient fromBlocks(class_2248... blocks) {
        return fromBlocks(BlockIngredient.of(blocks));
    }

    public static StateIngredient fromFluids(@Nullable FluidIngredient validFluids) {
        return new StateIngredient(Optional.empty(), Optional.ofNullable(validFluids));
    }

    public static StateIngredient fromFluids(@NotNull FluidIngredient.Builder builder) {
        return fromFluids(builder.build());
    }

    public static StateIngredient fromFluids(class_3611... fluids) {
        return fromFluids(FluidIngredient.of(fluids));
    }

    public static final StateIngredient EMPTY = new StateIngredient(BlockIngredient.EMPTY, FluidIngredient.EMPTY);

    public static final Codec<StateIngredient> CODEC = RecordCodecBuilder.create(i -> i.group(
            BlockIngredient.CODEC.optionalFieldOf("block", BlockIngredient.EMPTY).forGetter(si -> si.validBlocks),
            FluidIngredient.CODEC.optionalFieldOf("fluid", FluidIngredient.EMPTY).forGetter(si -> si.validFluids)
    ).apply(i, StateIngredient::new));

    @Override
    public boolean test(class_2688<?, ?> state) {
        if (state instanceof class_2680 blockState) {
            return this.validBlocks.test(blockState) || this.validFluids.test(blockState.method_26227());
        } else if (state instanceof class_3610 fluidState) {
            return this.validFluids.test(fluidState);
        }
        return false;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        } else if (obj == null) {
            return false;
        } else if (obj instanceof StateIngredient) {
            return this.getValidBlocks().equals(((StateIngredient) obj).getValidBlocks())
                    && this.getValidFluids().equals(((StateIngredient) obj).getValidFluids());
        } else return false;
    }

    @Override
    public int hashCode() {
        return this.getValidBlocks().hashCode() ^ this.getValidFluids().hashCode();
    }

    public BlockIngredient getValidBlocks() {
        return validBlocks;
    }

    public FluidIngredient getValidFluids() {
        return validFluids;
    }
}
