package rc55.mc.rfapi.data;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import io.netty.handler.codec.DecoderException;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_156;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.RFApiMain;

import java.io.InputStreamReader;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class ResourceReloadListenerImpl<T> implements SimpleSynchronousResourceReloadListener {
    private final class_3264 type;
    private final class_2960 id;
    private final String path;
    private final ResourceMap<?, T> resourceMap;

    private final @Nullable Codec<T> codec;
    private final @Nullable Function<JsonElement, T> parser;

    public ResourceReloadListenerImpl(class_3264 type, class_2960 id, String path, @NotNull Codec<T> resourceCodec, ResourceMap<?, T> resourceMap) {
        this.id = id;
        this.path = path;
        this.codec = resourceCodec;
        this.parser = null;
        this.resourceMap = resourceMap;
        this.type = type;
    }

    public ResourceReloadListenerImpl(class_3264 type, class_2960 id, String path, ResourceMap<?, T> resourceMap, @NotNull Function<JsonElement, T> resourceParser) {
        this.id = id;
        this.path = path;
        this.codec = null;
        this.parser = resourceParser;
        this.resourceMap = resourceMap;
        this.type = type;
    }

    /**
     * Register resource loaded on server
     * @param id Fabric ID || Path - {@code /data/NAMESPACE/{id.getPath()}/}
     * @param codec Resource Codec
     * @param cache Resource cache
     * @return Listener instance
     * @param <T> Resource type
     */
    public static <T> ResourceReloadListenerImpl<T> ofServer(class_2960 id, Codec<T> codec, ResourceMap<?, T> cache) {
        return new ResourceReloadListenerImpl<>(class_3264.field_14190, id, id.method_12832(), codec, cache).register();
    }

    public ResourceReloadListenerImpl<T> register() {
        ResourceManagerHelper.get(this.type).registerReloadListener(this);
        return this;
    }

    public class_3264 getType() {
        return type;
    }

    public String getPath() {
        return path;
    }

    @Override
    public class_2960 getFabricId() {
        return this.id;
    }

    @Override
    public void method_14491(class_3300 manager) {
        final Map<class_2960, T> resources = new HashMap<>();
        for (Map.Entry<class_2960, class_3298> entry : manager.method_14488(this.path, id -> id.method_12832().endsWith("json")).entrySet()) {
            final class_2960 id = entry.getKey();
            try (Reader reader = new InputStreamReader(entry.getValue().method_14482())) {
                final JsonElement json = JsonParser.parseReader(reader);
                final T result;
                if (this.codec != null) {
                    result = class_156.method_47526(this.codec.parse(JsonOps.INSTANCE, json), DecoderException::new);
                } else if (this.parser != null) {
                    result = this.parser.apply(json);
                } else {
                    throw new IllegalStateException("How");
                }
                // Remove prefix & extension for the resource id
                resources.put(id.method_45134(s -> s.matches("\\w+/[\\w/.]+") ? s.substring(s.indexOf('/') + 1, s.length() - 5) : s), result);
            } catch (Throwable e) {
                RFApiMain.LOGGER.error("Failed to load resource {}: {}", entry.getKey(), e);
            }
        }
        this.resourceMap.reload(resources);
        RFApiMain.LOGGER.info("Loaded {}x {} from enabled data packs.", resources.size(), this.getFabricId());
    }
}
