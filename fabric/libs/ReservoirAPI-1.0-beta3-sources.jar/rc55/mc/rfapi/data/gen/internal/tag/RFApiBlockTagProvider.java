package rc55.mc.rfapi.data.gen.internal.tag;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2246;
import net.minecraft.class_7225;
import rc55.mc.rfapi.block.RFApiBlockTags;

import java.util.concurrent.CompletableFuture;

public class RFApiBlockTagProvider extends FabricTagProvider.BlockTagProvider {
    public RFApiBlockTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> registriesFuture) {
        super(output, registriesFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        method_10512(RFApiBlockTags.FLUID).add(class_2246.field_10382, class_2246.field_10164);
    }
}
