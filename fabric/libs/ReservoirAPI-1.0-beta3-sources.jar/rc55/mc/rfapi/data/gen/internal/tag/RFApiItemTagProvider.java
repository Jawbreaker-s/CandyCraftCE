package rc55.mc.rfapi.data.gen.internal.tag;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalItemTags;
import net.minecraft.class_1802;
import net.minecraft.class_7225;
import rc55.mc.rfapi.item.RFApiItemTags;

import java.util.concurrent.CompletableFuture;

public class RFApiItemTagProvider extends FabricTagProvider.ItemTagProvider {
    public RFApiItemTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    @Override
    protected void method_10514(class_7225.class_7874 arg) {
        method_10512(RFApiItemTags.BUCKETS_EMPTY).add(class_1802.field_8550);
        method_10512(RFApiItemTags.BUCKETS_FILLED)
                .add(class_1802.field_8705, class_1802.field_8187)
                .forceAddTag(ConventionalItemTags.WATER_BUCKETS)
                .forceAddTag(ConventionalItemTags.LAVA_BUCKETS)
                .forceAddTag(ConventionalItemTags.ENTITY_WATER_BUCKETS)
                .forceAddTag(ConventionalItemTags.MILK_BUCKETS);

        method_10512(RFApiItemTags.BUCKETS)
                .method_26792(RFApiItemTags.BUCKETS_EMPTY)
                .method_26792(RFApiItemTags.BUCKETS_FILLED);

        method_10512(ConventionalItemTags.EMPTY_BUCKETS).method_26792(RFApiItemTags.BUCKETS_EMPTY);
    }
}
