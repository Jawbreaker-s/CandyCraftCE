package rc55.mc.rfapi.data.gen;

import net.minecraft.class_1755;
import net.minecraft.class_2404;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4915;
import net.minecraft.class_4941;
import net.minecraft.class_4942;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.data.client.*;
import rc55.mc.rfapi.RFApiMain;
import rc55.mc.rfapi.fluid.FluidReference;

import java.util.Arrays;
import java.util.Optional;

public final class RFApiModelGenerationHelper {
    private RFApiModelGenerationHelper(){}

    public static final class_2960 BUCKET_BASE = new class_2960(RFApiMain.MODID, "item/bucket_base");
    public static final class_2960 BUCKET_OVERLAY = new class_2960(RFApiMain.MODID, "item/bucket_overlay");
    public static final class_2960 BUCKET_INV_BASE = new class_2960(RFApiMain.MODID, "item/bucket_upside_down_base");
    public static final class_2960 BUCKET_INV_OVERLAY = new class_2960(RFApiMain.MODID, "item/bucket_upside_down_overlay");

    private static final class_4942 FLUID_BLOCK_MODEL = new class_4942(Optional.empty(), Optional.empty(), class_4945.field_23012);

    public static void createVanillaBucketItemModel(class_4915 generator, class_1755... buckets) {
        for (class_1755 item : buckets) {
            if (item.field_7905.getSettings().flowsUp()) {
                createCustomBucketItemModel(generator, BUCKET_INV_BASE, BUCKET_INV_OVERLAY, item);
            } else {
                createCustomBucketItemModel(generator, BUCKET_BASE, BUCKET_OVERLAY, item);
            }
        }
    }

    public static void createCustomBucketItemModel(class_4915 generator, class_2960 baseTexture, class_2960 overlayTexture, class_1755... items) {
        for (class_1755 item : items) {
            class_4943.field_42232.method_25852(
                    class_4941.method_25840(item),
                    class_4944.method_48529(baseTexture, overlayTexture),
                    generator.field_22844
            );
        }
    }

    public static void createFluidBlockModel(class_4910 generator, FluidReference<?>... fluids) {
        createFluidBlockModel(generator, new class_2960("block/water_still"), fluids);
    }

    public static void createFluidBlockModel(class_4910 generator, class_2960 particleId, FluidReference<?>... fluids) {
        createFluidBlockModel(generator, particleId, Arrays.stream(fluids).map(fluid -> (class_2404) fluid.getBlock()).toArray(class_2404[]::new));
    }

    public static void createFluidBlockModel(class_4910 generator, class_2404... blocks) {
        createFluidBlockModel(generator, new class_2960("block/water_still"), blocks);
    }

    public static void createFluidBlockModel(class_4910 generator, class_2960 particleId, class_2404... blocks) {
        for (class_2404 block : blocks) {
            generator.method_25681(block);
            FLUID_BLOCK_MODEL.method_25852(
                    class_4941.method_25842(block),
                    class_4944.method_25891(particleId),
                    generator.field_22831
            );
        }
    }
}
