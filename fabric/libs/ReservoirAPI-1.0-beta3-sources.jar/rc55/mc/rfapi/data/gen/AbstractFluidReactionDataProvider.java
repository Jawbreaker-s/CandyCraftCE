package rc55.mc.rfapi.data.gen;

import com.mojang.serialization.JsonOps;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_2405;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7403;
import net.minecraft.class_7784;
import net.minecraft.class_7923;
import org.jetbrains.annotations.ApiStatus;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.RFApiMain;
import rc55.mc.rfapi.data.FluidIngredient;
import rc55.mc.rfapi.data.StateIngredient;
import rc55.mc.rfapi.fluid.FluidReference;
import rc55.mc.rfapi.fluid.reaction.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

public abstract class AbstractFluidReactionDataProvider implements class_2405 {
    protected final FabricDataOutput dataOutput;

    public AbstractFluidReactionDataProvider(FabricDataOutput dataOutput) {
        this.dataOutput = dataOutput;
    }

    @Override
    public final CompletableFuture<?> method_10319(class_7403 writer) {
        final List<CompletableFuture<?>> features = new ArrayList<>();

        this.generate((id, reaction) ->
            IFluidReaction.BASE_CODEC.encodeStart(JsonOps.INSTANCE, reaction).promotePartial(RFApiMain.LOGGER::error).result().ifPresentOrElse(json ->
                features.add(class_2405.method_10320(writer, json,
                        this.dataOutput.method_45973(class_7784.class_7490.field_39367, IFluidReaction.RELOAD_LISTENER.getPath()).method_44108(id, "json")
                ))
            , () -> RFApiMain.LOGGER.error("Failed to generate data for provided reaction with id {}!", id))
        );

        return CompletableFuture.allOf(features.toArray(CompletableFuture[]::new));
    }

    @Override
    public String method_10321() {
        return String.format("%s / %s", IFluidReaction.RELOAD_LISTENER.getFabricId(), this.dataOutput.getModId());
    }

    public abstract void generate(ReactionBuilder builder);

    @ApiStatus.NonExtendable
    @FunctionalInterface
    public interface ReactionBuilder {
        void append(class_2960 id, IFluidReaction<?> reaction);

        /**
         * Generate a fluid reaction data with defaulted name
         * @param reaction The reaction instance
         * @see #createDefaultId(IFluidReaction) Default id format
         */
        default void append(IFluidReaction<?> reaction) {
            this.append(this.createDefaultId(reaction), reaction);
        }

        default void ofReaction(
                class_2960 id,
                FluidIngredient source,
                @Nullable StateIngredient surroundingIngredient,
                @Nullable StateIngredient verticalIngredient,
                float chance,
                class_2680 result
        ) {
            this.append(id, new SimpleFluidReaction(source, chance, Optional.ofNullable(surroundingIngredient), Optional.ofNullable(verticalIngredient), result));
        }

        default void ofReaction(
                FluidIngredient source,
                @Nullable StateIngredient surroundingIngredient,
                @Nullable StateIngredient verticalIngredient,
                float chance,
                class_2680 result
        ) {
            this.ofReaction(this.createDefaultId(result), source, surroundingIngredient, verticalIngredient, chance, result);
        }

        default void ofReaction(
                class_2960 id,
                FluidIngredient source,
                @Nullable StateIngredient surroundingIngredient,
                @Nullable StateIngredient verticalIngredient,
                float chance,
                class_2680 stillResult,
                class_2680 flowingResult
        ) {
            this.append(id, new SimpleFlowableFluidReaction(
                    source, chance, Optional.ofNullable(surroundingIngredient), Optional.ofNullable(verticalIngredient), stillResult, flowingResult
            ));
        }

        default void ofFlowIn(
                class_2960 id, FluidIngredient source, FluidIngredient ingredient, float chance, class_2680 result
        ) {
            this.append(id, new FlowIntoReaction(source, chance, ingredient, result));
        }

        default void ofFlowIn(
                FluidIngredient source, FluidIngredient ingredient, float chance, class_2680 result
        ) {
            this.ofFlowIn(this.createDefaultId(result), source, ingredient, chance, result);
        }

        default void ofSourceConversion(
                class_2960 id,
                FluidIngredient source,
                FluidIngredient ingredient,
                float chance,
                class_2680 result
        ) {
            this.append(id, new SourceConversionReaction(source, chance, ingredient, result));
        }

        default void ofSourceConversion(
                FluidIngredient source,
                FluidIngredient ingredient,
                float chance,
                class_2680 result
        ) {
            this.ofSourceConversion(this.createDefaultId(result), source, ingredient, chance, result);
        }

        default void ofInfection(
                class_2960 id, FluidReference<?> source, FluidIngredient target, float chance
        ) {
            this.append(id, new InfectionReaction(source.getStill(), target, chance));
        }

        default void ofInfection(
                FluidReference<?> source, FluidIngredient target, float chance
        ) {
            this.ofInfection(source.getBlockId(), source, target, chance);
        }

        default class_2960 createDefaultId(IFluidReaction<?> reaction) {
            return this.createDefaultId(reaction.getResult());
        }

        default class_2960 createDefaultId(class_2680 result) {
            return class_7923.field_41175.method_10221(result.method_26204());
        }
    }
}
