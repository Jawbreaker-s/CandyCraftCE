package rc55.mc.rfapi.data.gen.internal;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.minecraft.class_2246;
import net.minecraft.class_2960;
import net.minecraft.class_3486;
import rc55.mc.rfapi.data.FluidIngredient;
import rc55.mc.rfapi.data.StateIngredient;
import rc55.mc.rfapi.data.gen.AbstractFluidReactionDataProvider;

/**
 * Generates vanilla fluid reaction datas
 */
public class DefaultedFluidReactionDataProvider extends AbstractFluidReactionDataProvider {
    public DefaultedFluidReactionDataProvider(FabricDataOutput dataOutput) {
        super(dataOutput);
    }

    @Override
    public void generate(ReactionBuilder builder) {
        // Vanilla cobblestone/obsidian creation
        builder.ofReaction(
                new class_2960("obsidian_and_cobblestone"),
                FluidIngredient.of(class_3486.field_15518),
                StateIngredient.fromFluids(FluidIngredient.of(class_3486.field_15517)),
                null,
                1f,
                class_2246.field_10540.method_9564(),
                class_2246.field_10445.method_9564()
        );
        // Vanilla stone creation
        builder.ofFlowIn(
                FluidIngredient.of(class_3486.field_15518),
                FluidIngredient.of(class_3486.field_15517),
                1f,
                class_2246.field_10340.method_9564()
        );
        // Vanilla basalt creation
        builder.ofReaction(
                FluidIngredient.of(class_3486.field_15518),
                StateIngredient.fromBlocks(class_2246.field_10384),
                StateIngredient.fromBlocks(class_2246.field_22090),
                1f,
                class_2246.field_22091.method_9564()
        );
    }
}
