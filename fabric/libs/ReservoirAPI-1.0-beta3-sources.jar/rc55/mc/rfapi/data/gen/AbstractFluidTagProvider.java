package rc55.mc.rfapi.data.gen;

import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricTagProvider;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_7225;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.fluid.FluidReference;
import rc55.mc.rfapi.fluid.FluidTags;

import java.util.concurrent.CompletableFuture;
import java.util.function.Function;

public abstract class AbstractFluidTagProvider extends FabricTagProvider.FluidTagProvider {
    public AbstractFluidTagProvider(FabricDataOutput output, CompletableFuture<class_7225.class_7874> completableFuture) {
        super(output, completableFuture);
    }

    /**
     * Add given fluids to their tag(if exists), and add their still/flowing
     * factor to {@link FluidTags#STILL} / {@link FluidTags#FLOWING} tag
     * @param tagMapper Creates tag id for this fluid, null if no tag shall be provided
     */
    protected void createBaseTagsForReference(Function<FluidReference<?>, @Nullable class_2960> tagMapper, FluidReference<?>... fluids) {
        final FabricTagBuilder still = method_10512(FluidTags.STILL);
        final FabricTagBuilder flowing = method_10512(FluidTags.FLOWING);
        for (FluidReference<?> fluid : fluids) {
            still.add(fluid.getStill());
            flowing.add(fluid.getFlowing());
            final class_2960 id = tagMapper.apply(fluid);
            if (id != null) {
                this.createAndAdd(id, fluid);
            }
        }
    }

    protected FabricTagBuilder addToTag(class_6862<class_3611> tag, FluidReference<?>... fluids) {
        final FabricTagBuilder builder = method_10512(tag);
        for (FluidReference<?> fluid : fluids) {
            builder.add(fluid.getFlowing());
            builder.add(fluid.getStill());
        }
        return builder;
    }

    @SafeVarargs
    protected final FabricTagBuilder addSubTags(class_6862<class_3611> tag, class_6862<class_3611>... tags) {
        final FabricTagBuilder builder = method_10512(tag);
        for (class_6862<class_3611> tagKey : tags) {
            builder.forceAddTag(tagKey);
        }
        return builder;
    }

    protected FabricTagBuilder createAndAdd(class_2960 id, FluidReference<?>... fluids) {
        final FabricTagBuilder builder = method_10512(FluidTags.of(id));
        for (FluidReference<?> fluid : fluids) {
            builder.add(fluid.getFlowing());
            builder.add(fluid.getStill());
        }
        return builder;
    }
}
