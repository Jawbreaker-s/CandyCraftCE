package rc55.mc.rfapi.data;

import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2680;
import net.minecraft.class_5699;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class CodecHelper {
    /**
     * A block state codec which will either accepts a simple block name, or full {@code {"Name": "", "Properties": {}}} declaration
     * In the former case, the default state will be used
     * Note that when serializing, this will always use the right side(which is the blockstate based codec)
     */
    public static final Codec<class_2680> BLOCK_STATE = Codec.either(
            class_7923.field_41175.method_39673().xmap(class_2248::method_9564, class_2680::method_26204),
            class_2680.field_24734
    ).xmap(
            e -> e.map(Function.identity(), Function.identity()),
            e -> e == e.method_26204().method_9564() ? Either.left(e) : Either.right(e)
    );

    public static final Codec<Float> CHANCE = rangedFloat(0f, 1f, f -> String.format("Must be a float within 0~1, but found %.4f", f));

    /**
     * Create a codec that accepts a list
     * @param registry
     * @param constructor
     * @param valueGetter
     * @return
     * @param <T>
     * @param <I>
     */
    @Deprecated
    public static <T, I> Codec<I> ingredientCodec(
            class_2378<T> registry,
            Function<Stream<T>, ? extends I> constructor,
            Function<? super I, Stream<T>> valueGetter
    ) {
        return Codec.either(
                registry.method_39673(),
                class_6862.method_40093(registry.method_30517())
        ).listOf().xmap(
                list -> list.stream().flatMap(either -> either
                        .mapBoth(Function.identity(), registry::method_40260)
                        .map(Stream::of, named -> named.method_40239().map(class_6880::comp_349))
                ),
                stream -> stream.map(Either::<T, class_6862<T>>left).collect(Collectors.toList())
        ).xmap(constructor, valueGetter);
    }

    private static Codec<Float> rangedFloat(float min, float max, Function<Float, String> messageFactory) {
        return class_5699.method_48112(
                Codec.FLOAT,
                value -> value.compareTo(min) > 0 && value.compareTo(max) <= 0 ? DataResult.success(value) : DataResult.error(() -> (String)messageFactory.apply(value))
        );
    }
}
