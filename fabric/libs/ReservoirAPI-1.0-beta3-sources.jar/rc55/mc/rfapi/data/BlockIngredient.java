package rc55.mc.rfapi.data;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Codec;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_2248;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class BlockIngredient implements Predicate<class_2248> {
    private final Collection<Entry> matching;

    public BlockIngredient(Collection<Entry> matching) {
        this.matching = matching;
    }

    public BlockIngredient(Stream<Entry> stream) {
        this(stream.collect(Collectors.toUnmodifiableSet()));
    }

    public static BlockIngredient of(class_2248... blocks) {
        return new BlockIngredient(Stream.of(blocks).map(Entry::new));
    }

    public static BlockIngredient of(class_6862<class_2248> tag) {
        return builder().add(tag).build();
    }

    public static Builder builder() {
        return new Builder();
    }

    public static final BlockIngredient EMPTY = new BlockIngredient(ImmutableList.of());
    public static final Codec<BlockIngredient> CODEC = Entry.CODEC.listOf().xmap(BlockIngredient::new, BlockIngredient::list);

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        } else if (obj == null) {
            return false;
        } else if (obj instanceof BlockIngredient) {
            return this.stream().allMatch(e -> ((BlockIngredient) obj).matching.stream().anyMatch(e::equals));
        } else return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.matching.stream().findFirst().orElseGet(() -> new Entry("minecraft:air")));
    }

    @Override
    public boolean test(class_2248 block) {
        return this.matching.stream().anyMatch(entry -> entry.test(block));
    }

    public boolean test(class_2680 state) {
        return this.test(state.method_26204());
    }

    public List<Entry> list() {
        return ImmutableList.copyOf(this.matching);
    }

    public Stream<Entry> stream() {
        return this.matching.stream();
    }

    public static class Entry implements Predicate<class_2248> {
        private final String id;
        private class_2248 block;
        private class_6862<class_2248> tag;

        public static final Codec<Entry> CODEC = Codec.STRING.xmap(Entry::new, Entry::toString);

        public Entry(String id) {
            this.id = id;
            if (id.startsWith("#")) {
                this.tag = class_6862.method_40092(class_7924.field_41254, class_2960.method_12829(id.substring(1)));
            } else {
                this.block = class_7923.field_41175.method_10223(class_2960.method_12829(id));
            }
        }

        public Entry(class_2248 block) {
            this.id = class_7923.field_41175.method_10221(block).toString();
            this.block = block;
        }

        public Entry(class_6862<class_2248> tag) {
            this.id = "#" + tag.comp_327();
            this.tag = tag;
        }

        @Override
        public boolean test(class_2248 block) {
            if (this.tag != null) {
                return block.method_9564().method_26164(this.tag);
            } else {
                return block == this.block;
            }
        }

        @Override
        public String toString() {
            return this.id;
        }

        @Override
        public int hashCode() {
            return this.toString().hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            } else if (obj instanceof Entry) {
                return this.id.equals(((Entry) obj).id);
            } else return false;
        }

        public Stream<class_2248> stream() {
            if (this.tag != null) {
                return class_7923.field_41175.method_40260(this.tag).method_40239().map(class_6880::comp_349);
            } else {
                return Stream.of(this.block);
            }
        }
    }

    public static class Builder {
        private final Collection<Entry> entries = new ArrayList<>();

        public Builder add(class_2248 block) {
            this.entries.add(new Entry(block));
            return this;
        }

        public Builder add(class_6862<class_2248> tag) {
            this.entries.add(new Entry(tag));
            return this;
        }

        public BlockIngredient build() {
            return new BlockIngredient(this.entries);
        }
    }
}
