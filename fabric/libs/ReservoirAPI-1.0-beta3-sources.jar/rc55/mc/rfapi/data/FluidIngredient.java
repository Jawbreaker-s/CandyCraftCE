package rc55.mc.rfapi.data;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.Codec;
import rc55.mc.rfapi.fluid.FluidReference;
import rc55.mc.rfapi.fluid.FluidRegistry;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.minecraft.class_2960;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Util class used to match fluid reactions while touching each other
 */
public class FluidIngredient implements Predicate<class_3611> {
    private final Collection<Entry> matching;

    public FluidIngredient(Collection<Entry> matching) {
        this.matching = matching;
    }

    public FluidIngredient(Stream<Entry> stream) {
        this(stream.collect(Collectors.toUnmodifiableSet()));
    }

    public static FluidIngredient of(class_3611... fluids) {
        return new FluidIngredient(Stream.of(fluids).map(Entry::new));
    }

    public static FluidIngredient of(class_6862<class_3611> tag) {
        return builder().add(tag).build();
    }

    public static FluidIngredient of(FluidReference<?> fluid) {
        return of(fluid.getFlowing(), fluid.getStill());
    }

    /**
     * @return A builder for FluidIngredient used for data generation
     */
    public static Builder builder() {
        return new Builder();
    }

    public static final FluidIngredient EMPTY = new FluidIngredient(ImmutableList.of());
    public static final Codec<FluidIngredient> CODEC = Entry.CODEC.listOf().xmap(FluidIngredient::new, FluidIngredient::list);

    @Override
    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        } else if (obj == null) {
            return false;
        } else if (obj instanceof FluidIngredient) {
            return this.stream().allMatch(e -> ((FluidIngredient) obj).matching.stream().anyMatch(e::equals));
        } else return false;
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.matching.stream().findFirst().orElseGet(() -> new Entry("minecraft:empty")));
    }

    @Override
    public boolean test(class_3611 fluid) {
        return this.matching.stream().anyMatch(entry -> entry.test(fluid));
    }

    public boolean test(class_3610 state) {
        return this.test(state.method_15772());
    }

    public List<Entry> list() {
        return ImmutableList.copyOf(this.matching);
    }

    public Stream<Entry> stream() {
        return this.matching.stream();
    }

    public static class Entry implements Predicate<class_3611> {
        private final String id;
        private class_3611 fluid;
        private class_6862<class_3611> tag;

        public static final Codec<Entry> CODEC = Codec.STRING.xmap(Entry::new, Entry::toString);

        public Entry(String id) {
            this.id = id;
            if (id.startsWith("#")) {
                this.tag = class_6862.method_40092(class_7924.field_41270, class_2960.method_12829(id.substring(1)));
            } else {
                this.fluid = FluidRegistry.get(id);
            }
        }

        public Entry(class_3611 fluid) {
            this.id = FluidRegistry.getId(fluid).toString();
            this.fluid = fluid;
        }

        public Entry(class_6862<class_3611> tag) {
            this.id = "#" + tag.comp_327();
            this.tag = tag;
        }

        @Override
        public boolean test(class_3611 fluid) {
            if (this.tag != null) {
                return fluid.method_15791(this.tag);
            } else {
                return fluid == this.fluid;
            }
        }

        @Override
        public String toString() {
            return this.id;
        }

        @Override
        public int hashCode() {
            return this.toString().hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            } else if (obj instanceof Entry) {
                return this.id.equals(((Entry) obj).id);
            } else return false;
        }

        public Stream<class_3611> stream() {
            if (this.tag != null) {
                return class_7923.field_41173.method_40260(this.tag).method_40239().map(class_6880::comp_349);
            } else {
                return Stream.of(this.fluid);
            }
        }
    }

    public static class Builder {
        private final Collection<Entry> entries = new ArrayList<>();

        public Builder add(class_3611 fluid) {
            this.entries.add(new Entry(fluid));
            return this;
        }

        public Builder add(class_6862<class_3611> tag) {
            this.entries.add(new Entry(tag));
            return this;
        }

        public FluidIngredient build() {
            return new FluidIngredient(this.entries);
        }
    }
}
