package rc55.mc.rfapi.data;

import com.mojang.serialization.Codec;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_2540;

/**
 * A util interface for (de)serializing objects from/to {@link class_2540}
 * @param <T> Object type
 */
public interface ByteBufSerializer<T> {
    class_2540 toByteBuf(T obj);

    T fromByteBuf(class_2540 buf);

    static <T> ByteBufSerializer<T> fromCodec(Codec<T> codec) {
        return new ByteBufSerializer<>() {
            @Override
            public class_2540 toByteBuf(T obj) {
                class_2540 buf = PacketByteBufs.create();
                buf.method_49395(codec, obj);
                return buf;
            }

            @Override
            public T fromByteBuf(class_2540 buf) {
                return buf.method_49394(codec);
            }
        };
    }
}
