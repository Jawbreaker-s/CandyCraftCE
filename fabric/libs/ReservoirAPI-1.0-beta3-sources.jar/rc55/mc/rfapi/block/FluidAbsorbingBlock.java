package rc55.mc.rfapi.block;

import net.minecraft.block.*;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import rc55.mc.rfapi.fluid.FluidRegistry;

import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * A sponge like block that allows customizing acceptable fluids
 */
public class FluidAbsorbingBlock extends class_2248 {
    private final class_2680 wetState;
    private final Predicate<class_3611> acceptableFluids;
    private final int maxAbsorptionDistance, maxAbsorptionAmount;

    public FluidAbsorbingBlock(Predicate<class_3611> acceptableFluids, int maxAbsorptionDistance, int maxAbsorptionAmount, class_2680 wetState, class_2251 settings) {
        super(settings);
        this.wetState = wetState;
        this.acceptableFluids = acceptableFluids;
        this.maxAbsorptionDistance = maxAbsorptionDistance;
        this.maxAbsorptionAmount = maxAbsorptionAmount;
    }

    public FluidAbsorbingBlock(Predicate<class_3611> acceptableFluids, class_2680 wetState, class_2251 settings) {
        this(acceptableFluids, 6, 65, wetState, settings);
    }

    public class_2680 getWetState() {
        return wetState;
    }

    public Predicate<class_3611> getFluidPredicate() {
        return this.acceptableFluids;
    }

    public int getMaxAbsorptionDistance() {
        return maxAbsorptionDistance;
    }

    public int getMaxAbsorptionAmount() {
        return maxAbsorptionAmount;
    }

    public Stream<class_3611> getAcceptableFluids() {
        return FluidRegistry.stream(this.acceptableFluids);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void method_9615(class_2680 state, class_1937 world, class_2338 pos, class_2680 oldState, boolean notify) {
        if (!oldState.method_27852(state.method_26204())) {
            this.update(world, pos);
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void method_9612(class_2680 state, class_1937 world, class_2338 pos, class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        this.update(world, pos);
        super.method_9612(state, world, pos, sourceBlock, sourcePos, notify);
    }

    protected void update(class_1937 world, class_2338 pos) {
        if (this.absorbWater(world, pos)) {
            world.method_8652(pos, this.getWetState(), class_2248.field_31028);
            world.method_20290(2001, pos, class_2248.method_9507(class_2246.field_10382.method_9564()));
        }
    }

    private boolean absorbWater(class_1937 world, class_2338 pos) {
        return class_2338.method_49925(pos, this.getMaxAbsorptionDistance(), this.getMaxAbsorptionAmount(), (currentPos, queuer) -> {
            for (class_2350 direction : class_2350.values()) {
                queuer.accept(currentPos.method_10093(direction));
            }
        }, (currentPos) -> {
            if (currentPos.equals(pos)) {
                return true;
            } else {
                class_2680 state = world.method_8320(currentPos);
                class_3610 fluidState = world.method_8316(currentPos);
                if (fluidState.method_15769() || !this.getFluidPredicate().test(fluidState.method_15772())) {
                    return false;
                } else {
                    class_2248 block = state.method_26204();
                    if (block instanceof class_2263) {
                        if (!((class_2263)block).method_9700(world, currentPos, state).method_7960()) {
                            return true;
                        }
                    }

                    if (block instanceof class_2404) {
                        world.method_8652(currentPos, class_2246.field_10124.method_9564(), class_2248.field_31036);
                    } else if (fluidState.method_39360(class_3612.field_15910)) {
                        if (!state.method_27852(class_2246.field_9993) && !state.method_27852(class_2246.field_10463) && !state.method_27852(class_2246.field_10376) && !state.method_27852(class_2246.field_10238)) {
                            return false;
                        }

                        class_2586 blockEntity = state.method_31709() ? world.method_8321(currentPos) : null;
                        method_9610(state, world, currentPos, blockEntity);
                        world.method_8652(currentPos, class_2246.field_10124.method_9564(), class_2248.field_31036);
                    }

                    return true;
                }
            }
        }) > 1;
    }
}
