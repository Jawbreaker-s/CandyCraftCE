package rc55.mc.rfapi.block;

import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class RFApiBlockTags {
    /**
     * Marks blocks that represents a fluid block
     */
    public static final class_6862<class_2248> FLUID = ofConventional("fluids");

    /**
     * Marks blocks like ice, which can convert to a type of fluid
     */
    public static final class_6862<class_2248> ICY = ofConventional("icy");

    /**
     * Marks blocks like sponge, which can absorb certain types of fluid
     */
    public static final class_6862<class_2248> SPONGE_LIKE = ofConventional("sponge_like");

    public static class_6862<class_2248> of(class_2960 id) {
        return class_6862.method_40092(class_7924.field_41254, id);
    }

    public static class_6862<class_2248> ofConventional(String id) {
        return of(class_2960.method_43902("c", id));
    }

    public static class_6862<class_2248> fromFluidTag(class_6862<class_3611> tag) {
        return of(tag.comp_327());
    }
}
