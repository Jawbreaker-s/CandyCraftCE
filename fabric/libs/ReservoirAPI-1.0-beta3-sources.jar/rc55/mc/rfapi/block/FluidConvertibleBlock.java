package rc55.mc.rfapi.block;

import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_1937;
import net.minecraft.class_1944;
import net.minecraft.class_2338;
import net.minecraft.class_2373;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;
import rc55.mc.rfapi.fluid.FluidReference;
import rc55.mc.rfapi.fluid.FluidTags;

/**
 * An ice like block that allows customizing melted state
 */
public class FluidConvertibleBlock extends class_2373 {
    protected final FluidReference<?> fluid;

    public FluidConvertibleBlock(FluidReference<?> fluid, class_2251 settings) {
        super(settings);
        this.fluid = fluid;
    }

    public FluidReference<?> getFluid() {
        return fluid;
    }

    public class_2680 getMeltedState() {
        return this.getFluid().getBlock().method_9564();
    }

    @SuppressWarnings("deprecation")
    @Override
    public void method_9556(class_1937 world, class_1657 player, class_2338 pos, class_2680 state, @Nullable class_2586 blockEntity, class_1799 tool) {
        super.method_9556(world, player, pos, state, blockEntity, tool);
        if (class_1890.method_8225(class_1893.field_9099, tool) == 0) {
            if (world.method_8597().comp_644()) {
                world.method_8650(pos, false);
                return;
            }

            class_2680 blockState = world.method_8320(pos.method_10074());
            if (blockState.method_51366() || blockState.method_51176()) {
                world.method_8501(pos, this.getMeltedState());
            }
        }
    }

    @SuppressWarnings("deprecation")
    @Override
    public void method_9514(class_2680 state, class_3218 world, class_2338 pos, class_5819 random) {
        if (world.method_8314(class_1944.field_9282, pos) > 11 - state.method_26193(world, pos)) {
            this.melt(state, world, pos);
        }
    }

    protected void melt(class_2680 state, class_1937 world, class_2338 pos) {
        if (this.fluid.getStill().method_15791(FluidTags.DISAPPEAR_IN_ULTRAWARM) && world.method_8597().comp_644()) {
            world.method_8650(pos, false);
        } else {
            world.method_8501(pos, this.getMeltedState());
            world.method_8492(pos, this.getFluid().getBlock(), pos);
        }
    }
}
